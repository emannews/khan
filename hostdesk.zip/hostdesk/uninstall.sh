#!/usr/bin/env bash
# HostDesk — remove the panel.
#   sudo bash uninstall.sh           remove the panel, keep its data and all sites
#   sudo bash uninstall.sh --purge   also delete the panel's data (settings, accounts, backups list)
# Sites, their files, databases, Nginx/PHP settings and app services are NEVER removed by this script.
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo "Please run as root: sudo bash uninstall.sh"; exit 1; }
PURGE=0; [[ "${1:-}" == "--purge" ]] && PURGE=1
read -r -p "Remove the HostDesk panel? Your sites keep running. [y/N] " a; [[ "$a" =~ ^[Yy]$ ]] || exit 0
systemctl disable --now hostdesk 2>/dev/null || true
rm -f /etc/systemd/system/hostdesk.service /usr/local/bin/hostdesk
systemctl daemon-reload
rm -rf /opt/hostdesk/app
if [[ $PURGE == 1 ]]; then
  rm -rf /etc/hostdesk/config.json /var/lib/hostdesk
  echo "Panel data removed. Backups in /var/backups/hostdesk and runtimes in /opt/hostdesk/runtimes were kept."
fi
echo "HostDesk removed. Sites, files and databases were not touched."
