#!/usr/bin/env bash
# =============================================================
#  Remove aaPanel / BT-Panel completely.
#    sudo bash remove-aapanel.sh
#  - SSH and Cloudflare Tunnel (cloudflared) are never touched.
#  - Website files in /www/wwwroot and /www/backup are moved to
#    /root/aapanel-backup-<date> instead of being deleted.
# =============================================================
set -uo pipefail

b=$'\e[1m'; g=$'\e[32m'; y=$'\e[33m'; r=$'\e[31m'; n=$'\e[0m'
say()  { echo "${g}==>${n} ${b}$*${n}"; }
info() { echo "    $*"; }

[[ $EUID -eq 0 ]] || { echo "Please run as root:  sudo bash remove-aapanel.sh"; exit 1; }

# MySQL settings written by aaPanel (/etc/my.cnf points to /www/server/data) stop Ubuntu's
# MySQL / MariaDB from starting. They are moved aside, never deleted.
clean_mycnf() {
  local dest="$1"
  for f in /etc/my.cnf /etc/my.cnf.d; do
    if [[ -e "$f" ]] && ! dpkg -S "$f" >/dev/null 2>&1; then
      mkdir -p "$dest" && mv "$f" "$dest/" && info "moved $f to $dest/ (it stops MySQL from starting)"
    fi
  done
}

if [[ ! -d /www/server && ! -f /etc/init.d/bt && ! -x /usr/bin/bt ]]; then
  echo "aaPanel is not installed."
  clean_mycnf "/root/aapanel-backup-$(date +%Y%m%d-%H%M%S)"
  echo "Nothing else to do."; exit 0
fi

echo
echo "${b}This removes aaPanel and everything it installed in /www/server${n}"
echo "(its Nginx, PHP, MySQL, FTP, Redis …). SSH and Cloudflare Tunnel stay running."
echo
read -r -p "Type YES to continue: " ans
[[ "$ans" == "YES" ]] || { echo "Cancelled."; exit 0; }

# ---------- Safety: remember SSH and tunnel state ----------
say "Checking SSH and Cloudflare Tunnel"
for s in ssh sshd cloudflared; do
  systemctl list-unit-files "$s.service" --no-legend 2>/dev/null | grep -q . && info "$s: $(systemctl is-active "$s" 2>/dev/null) (not touched)"
done

# Panel port (to close it in the firewall later)
PANEL_PORT="$(cat /www/server/panel/data/port.pl 2>/dev/null | tr -dc '0-9')"

# ---------- 1. Stop the panel ----------
say "Stopping aaPanel"
[[ -x /usr/bin/bt ]] && /usr/bin/bt stop >/dev/null 2>&1
[[ -x /etc/init.d/bt ]] && /etc/init.d/bt stop >/dev/null 2>&1
for u in bt btpanel; do systemctl disable --now "$u" >/dev/null 2>&1; done

# ---------- 2. Stop and remove services that live in /www/server ----------
say "Removing services installed by aaPanel"
for f in /etc/init.d/*; do
  [[ -f "$f" ]] || continue
  name="$(basename "$f")"
  case "$name" in ssh|sshd|cloudflared) continue ;; esac
  if [[ "$name" == "bt" ]] || grep -q '/www/server' "$f" 2>/dev/null; then
    info "stop $name"
    "$f" stop >/dev/null 2>&1
    systemctl disable "$name" >/dev/null 2>&1
    update-rc.d -f "$name" remove >/dev/null 2>&1
    rm -f "$f"
  fi
done
for d in /etc/systemd/system /usr/lib/systemd/system /lib/systemd/system; do
  for f in "$d"/*.service; do
    [[ -f "$f" ]] || continue
    name="$(basename "$f")"
    case "$name" in ssh*|sshd*|cloudflared*) continue ;; esac
    if [[ "$name" == btpanel.service || "$name" == bt.service ]] || grep -q '/www/server' "$f" 2>/dev/null; then
      info "remove $name"
      systemctl disable --now "$name" >/dev/null 2>&1
      rm -f "$f"
    fi
  done
done
systemctl daemon-reload
systemctl reset-failed >/dev/null 2>&1

# Anything still running from /www/server
if pgrep -f '/www/server' >/dev/null 2>&1; then
  pkill -f '/www/server' >/dev/null 2>&1; sleep 3
  pkill -9 -f '/www/server' >/dev/null 2>&1; sleep 1
fi

# ---------- 3. Scheduled tasks ----------
say "Removing aaPanel scheduled tasks"
if crontab -l 2>/dev/null | grep -q '/www/server'; then
  crontab -l 2>/dev/null | grep -v '/www/server' | crontab -
  info "cleaned root crontab"
fi
for f in /etc/cron.d/*; do
  [[ -f "$f" ]] && grep -q '/www/server' "$f" 2>/dev/null && { rm -f "$f"; info "removed $f"; }
done

# ---------- 4. Files ----------
say "Removing aaPanel files"
chattr -R -i /www >/dev/null 2>&1          # aaPanel locks some files (.user.ini) as immutable
KEEP="/root/aapanel-backup-$(date +%Y%m%d-%H%M%S)"
for d in /www/wwwroot /www/backup /www/server/data; do
  if [[ -d "$d" ]] && [[ -n "$(find "$d" -mindepth 1 -maxdepth 2 ! -name default ! -name '.user.ini' ! -name index.html ! -name 404.html 2>/dev/null | head -n1)" ]]; then
    mkdir -p "$KEEP" && mv "$d" "$KEEP/" && info "kept $d in $KEEP/"
  fi
done
rm -rf /www
rm -f /usr/bin/bt /etc/init.d/bt
clean_mycnf "$KEEP"
if id www >/dev/null 2>&1; then userdel www >/dev/null 2>&1 && info "removed user www"; fi
getent group www >/dev/null 2>&1 && groupdel www >/dev/null 2>&1

# ---------- 5. Firewall: close the ports aaPanel opened ----------
if command -v ufw >/dev/null 2>&1; then
  say "Closing aaPanel firewall ports (SSH rules are kept)"
  for p in $PANEL_PORT 888 14049 7800 8888 20 21 33501 39000:40000; do
    for proto in tcp udp; do ufw --force delete allow "$p/$proto" >/dev/null 2>&1 && info "closed $p/$proto"; done
    ufw --force delete allow "$p" >/dev/null 2>&1 && info "closed $p"
  done
fi

# ---------- 6. Result ----------
say "Done"
for s in ssh sshd cloudflared; do
  systemctl list-unit-files "$s.service" --no-legend 2>/dev/null | grep -q . && info "$s: $(systemctl is-active "$s" 2>/dev/null)"
done
P80="$(ss -ltnpH 'sport = :80' 2>/dev/null)"
if [[ -n "$P80" ]]; then echo "${y}!!${n}  Port 80 is still in use:"; echo "$P80"; else info "port 80 is free"; fi
[[ -d "$KEEP" ]] && info "your old site files are in $KEEP"
echo
echo "Next:  ${b}sudo bash install.sh${n}"
