'use strict';
/** All API endpoints. Every handler checks that the account may touch the domain it works on. */
const path = require('path');
const fs = require('fs');
const cfg = require('./lib/config');
const store = require('./lib/store');
const auth = require('./lib/auth');
const sys = require('./lib/sys');
const rt = require('./lib/runtimes');
const metrics = require('./lib/metrics');
const hosting = require('./lib/hosting');
const files = require('./lib/files');
const dbs = require('./lib/databases');
const appstore = require('./lib/appstore');
const backups = require('./lib/backups');
const cron = require('./lib/cron');
const system = require('./lib/system');
const traffic = require('./lib/traffic');
const usage = require('./lib/usage');
const doctor = require('./lib/doctor');
const update = require('./lib/update');
const { route, setCookie, send } = require('./lib/http');
const { HttpError, bad, notFound, forbidden, RE, password: genPassword } = require('./lib/util');

const S = () => store.state;
const admin = { admin: true };
const canDomain = dbs.canDomain;
const needDomain = (user, id) => { const d = hosting.findDomain(id); if (!d) throw notFound('Domain not found'); if (!canDomain(user, d.id)) throw forbidden(); return d; };
const needApp = (user, id) => { const a = S().apps.find((x) => x.id === id); if (!a) throw notFound('Application not found'); needDomain(user, a.domainId); return a; };
const me = (ctx) => ctx.user.username;
const LANGS = ['en', 'ps'];
/** Domain names this account may see (null = all, for administrators). */
const scopeNames = (user) => (user.role === 'admin' ? null : S().domains.filter((d) => canDomain(user, d.id)).map((d) => d.name));

/* ---------- Health & branding (public) ---------- */
route('GET', '/api/health', () => ({ ok: true, version: cfg.version }), { auth: false });
route('GET', '/api/branding', () => { const s = S().settings; return { panelName: s.panelName, logo: s.logo, accent: s.accent, theme: s.theme, language: s.language || 'en', hostname: require('os').hostname() }; }, { auth: false });

/* ---------- Auth ---------- */
route('POST', '/api/auth/login', async (req, res, ctx) => {
  const { token, user } = await auth.login(String(ctx.body.username || ''), String(ctx.body.password || ''), req);
  setCookie(res, 'hd_session', token, { secure: req.secure, maxAge: ctx.body.remember === false ? undefined : 30 * 86400 });
  return { user: auth.publicUser(user) };
}, { auth: false });
route('POST', '/api/auth/logout', (req, res, ctx) => { auth.destroySession(ctx.cookies.hd_session); setCookie(res, 'hd_session', '', { maxAge: 0, secure: req.secure }); return { ok: true }; }, { auth: false });
route('GET', '/api/auth/me', (req, res, ctx) => ({ user: auth.publicUser(ctx.user) }));
route('PUT', '/api/auth/prefs', (req, res, ctx) => {
  if ('lang' in ctx.body) { if (!LANGS.includes(ctx.body.lang)) throw bad('Unknown language'); ctx.user.lang = ctx.body.lang; }
  store.save();
  return { user: auth.publicUser(ctx.user) };
});
route('GET', '/api/me/usage', (req, res, ctx) => usage.accountUsage(ctx.user));
route('POST', '/api/auth/password', (req, res, ctx) => {
  if (!auth.verifyPassword(String(ctx.body.old || ''), ctx.user.password)) throw bad('Current password is wrong');
  auth.checkPasswordStrength(ctx.body.new);
  ctx.user.password = auth.hashPassword(ctx.body.new); store.save();
  auth.destroyUserSessions(ctx.user.id, ctx.sessionKey);
  store.log(me(ctx), 'Changed password', me(ctx), 'lock');
  return { ok: true };
});

/* ---------- System ---------- */
route('GET', '/api/system/info', () => system.info(), admin);
route('GET', '/api/system/metrics', () => metrics.snapshot(), admin);
route('GET', '/api/system/services', () => system.services(), admin);
route('POST', '/api/system/services/:id/:action', async (req, res, ctx) => { await system.serviceAction(ctx.params.id, ctx.params.action, me(ctx)); return system.services(); }, admin);
route('GET', '/api/system/storage', (req, res, ctx) => system.storage(ctx.user));
route('GET', '/api/system/timezones', () => system.timezones(), admin);
route('PUT', '/api/system/timezone', (req, res, ctx) => system.setTimezone(String(ctx.body.timezone || ''), me(ctx)), admin);
route('GET', '/api/system/overview', async (req, res, ctx) => {
  const doms = S().domains.filter((d) => canDomain(ctx.user, d.id));
  const ids = new Set(doms.map((d) => d.id));
  const apps = await hosting.listApps();
  const mine = apps.filter((a) => ids.has(a.domainId));
  await dbs.discoverSqlite();
  const myDbs = S().databases.filter((d) => ids.has(d.domainId));
  const last = S().backups.find((b) => ctx.user.role === 'admin' || ids.has(b.scope));
  const today = traffic.todayTotals(scopeNames(ctx.user));
  const t = Object.values(today).reduce((s, x) => ({ out: s.out + x.out, req: s.req + x.req, uv: s.uv + x.uv, pv: s.pv + x.pv }), { out: 0, req: 0, uv: 0, pv: 0 });
  return { domains: doms.filter((d) => !d.parentId).length, subdomains: doms.filter((d) => d.parentId).length, apps: mine.length, running: mine.filter((a) => a.live.state === 'running').length, databases: myDbs.length, lastBackup: last || null, today: t, usage: usage.accountUsage(ctx.user) };
});

/* ---------- Settings ---------- */
route('GET', '/api/settings', () => ({ ...S().settings, wwwRoot: cfg.wwwRoot, panelPort: cfg.port, runtimes: { node: rt.nodeVersions(), php: rt.phpVersions() } }), admin);
route('PUT', '/api/settings', (req, res, ctx) => {
  const b = ctx.body, s = S().settings, next = {};
  if (b.panelName != null) { const n = String(b.panelName).trim(); if (!n || n.length > 32) throw bad('Panel name: 1–32 characters'); next.panelName = n; }
  if (b.logo !== undefined) { if (b.logo !== null && !(typeof b.logo === 'string' && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(b.logo) && b.logo.length < 300000)) throw bad('Logo must be a PNG, JPG or WEBP image under 200 KB'); next.logo = b.logo; }
  if (b.accent != null) { if (!/^#[0-9a-fA-F]{6}$/.test(b.accent)) throw bad('Invalid color'); next.accent = b.accent; }
  if (b.theme != null) { if (!['light', 'dark', 'system'].includes(b.theme)) throw bad('Invalid theme'); next.theme = b.theme; }
  if (b.nodePortStart != null) { const p = Number(b.nodePortStart); if (!(p >= 1024 && p <= 65000)) throw bad('First Node.js port must be between 1024 and 65000'); next.nodePortStart = p; }
  if (b.defaultNode != null) { if (!rt.NODE_MAJORS.includes(String(b.defaultNode))) throw bad('Invalid Node.js version'); next.defaultNode = String(b.defaultNode); }
  if (b.defaultPhp != null) { if (!rt.PHP_VERSIONS.includes(String(b.defaultPhp))) throw bad('Invalid PHP version'); next.defaultPhp = String(b.defaultPhp); }
  if (b.backupEnabled != null) next.backupEnabled = !!b.backupEnabled;
  if (b.backupTime != null) { if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(b.backupTime)) throw bad('Time must look like 03:00'); next.backupTime = b.backupTime; }
  if (b.backupKeep != null) { const k = Number(b.backupKeep); if (!(k >= 1 && k <= 90)) throw bad('Keep between 1 and 90 days'); next.backupKeep = k; }
  if (b.backupExcludeNodeModules != null) next.backupExcludeNodeModules = !!b.backupExcludeNodeModules;
  if (b.sessionTimeout != null) { const t = Number(b.sessionTimeout); if (![15, 30, 60, 240, 480, 1440].includes(t)) throw bad('Invalid session time'); next.sessionTimeout = t; }
  if (b.language != null) { if (!LANGS.includes(b.language)) throw bad('Unknown language'); next.language = b.language; }
  Object.assign(s, next); store.save();
  store.log(me(ctx), 'Updated settings', Object.keys(next).join(', '), 'settings');
  return { ...s, wwwRoot: cfg.wwwRoot, panelPort: cfg.port, runtimes: { node: rt.nodeVersions(), php: rt.phpVersions() } };
}, admin);
route('POST', '/api/settings/reapply', (req, res, ctx) => ({ job: sys.startJob({ title: 'Re-apply all site configuration', user: me(ctx), task: async (log) => { await hosting.reapplyAll(log); await cron.sync(); } }) }), admin);

/* ---------- Domains ---------- */
const withStats = (d, today) => ({ ...hosting.decorate(d), size: usage.sizeOf(d.id), today: today[d.name] || null });
route('GET', '/api/domains', (req, res, ctx) => { const today = traffic.todayTotals(scopeNames(ctx.user)); return S().domains.filter((d) => canDomain(ctx.user, d.id)).map((d) => withStats(d, today)); });
route('POST', '/api/domains', async (req, res, ctx) => hosting.createDomain(ctx.body, me(ctx)), admin);
route('GET', '/api/domains/:id', (req, res, ctx) => hosting.decorate(needDomain(ctx.user, ctx.params.id)));
route('PATCH', '/api/domains/:id', async (req, res, ctx) => {
  needDomain(ctx.user, ctx.params.id);
  const patch = {};
  if ('enabled' in ctx.body) patch.enabled = !!ctx.body.enabled;
  if ('accountId' in ctx.body) { if (ctx.user.role !== 'admin') throw forbidden('Only administrators can change the account'); patch.accountId = ctx.body.accountId || null; }
  return hosting.updateDomain(ctx.params.id, patch, me(ctx));
});
route('DELETE', '/api/domains/:id', async (req, res, ctx) => hosting.deleteDomain(ctx.params.id, { deleteFiles: !!ctx.body.deleteFiles, deleteDatabases: !!ctx.body.deleteDatabases }, me(ctx)).then(() => ({ ok: true })), admin);

/* ---------- Applications ---------- */
route('GET', '/api/apps', async (req, res, ctx) => (await hosting.listApps()).filter((a) => canDomain(ctx.user, a.domainId)));
route('GET', '/api/apps-meta', async () => {
  const node = await Promise.all(rt.nodeVersions().map(async (m) => ({ major: m, version: await rt.nodeFullVersion(m) })));
  return { nextPort: await hosting.nextPort(), node, php: rt.phpVersions(), composer: cfg.dev ? rt.dev.has('composer') : !!sys.which('composer'), ports: S().apps.filter((a) => a.runtime === 'node').map((a) => ({ port: a.port, app: a.name, id: a.id })).sort((a, b) => a.port - b.port), defaults: { node: S().settings.defaultNode, php: S().settings.defaultPhp, phpPort: 80, nodePortStart: S().settings.nodePortStart } };
});
route('POST', '/api/apps', async (req, res, ctx) => { needDomain(ctx.user, ctx.body.domainId); usage.checkCount(ctx.user, 'apps'); return hosting.createApp(ctx.body, me(ctx)); });
route('GET', '/api/apps/:id', async (req, res, ctx) => { needApp(ctx.user, ctx.params.id); return hosting.getApp(ctx.params.id); });
route('PATCH', '/api/apps/:id', async (req, res, ctx) => { needApp(ctx.user, ctx.params.id); return hosting.updateApp(ctx.params.id, ctx.body, me(ctx)); });
route('DELETE', '/api/apps/:id', async (req, res, ctx) => { needApp(ctx.user, ctx.params.id); await hosting.deleteApp(ctx.params.id, me(ctx)); return { ok: true }; });
route('POST', '/api/apps/:id/action/:action', async (req, res, ctx) => { needApp(ctx.user, ctx.params.id); return hosting.appAction(ctx.params.id, ctx.params.action, me(ctx)); });
route('GET', '/api/apps/:id/logs', async (req, res, ctx) => { needApp(ctx.user, ctx.params.id); return hosting.appLogs(ctx.params.id, ctx.query.lines); });

/* ---------- Routes (Cloudflare Tunnel) ---------- */
route('GET', '/api/routes', () => S().domains.map(hosting.routeOf), admin);
route('GET', '/api/routes/config', () => {
  const lines = ['ingress:'];
  for (const d of S().domains.filter((x) => x.enabled)) {
    const r = hosting.routeOf(d);
    for (const h of [r.hostname, ...r.aliases]) lines.push(`  - hostname: ${h}`, `    service: ${r.service}`);
  }
  lines.push('  - service: http_status:404');
  return { yaml: lines.join('\n') + '\n' };
}, admin);

/* ---------- Files ---------- */
route('GET', '/api/files/roots', (req, res, ctx) => {
  const doms = S().domains.filter((d) => canDomain(ctx.user, d.id));
  return { wwwRoot: cfg.wwwRoot, domains: doms.map((d) => ({ id: d.id, name: d.name, parentId: d.parentId, folder: d.folder })) };
});
route('GET', '/api/files/list', (req, res, ctx) => files.list(ctx.user, ctx.query.path));
route('GET', '/api/files/read', (req, res, ctx) => files.read(ctx.user, ctx.query.path));
route('PUT', '/api/files/write', (req, res, ctx) => files.write(ctx.user, ctx.query.path, ctx.body.content, ctx.body.mtime), { limit: 4 * 1024 * 1024 });
route('POST', '/api/files/mkdir', (req, res, ctx) => files.mkdir(ctx.user, ctx.body.path, ctx.body.name));
route('POST', '/api/files/create', (req, res, ctx) => files.createFile(ctx.user, ctx.body.path, ctx.body.name));
route('POST', '/api/files/rename', (req, res, ctx) => files.rename(ctx.user, ctx.body.path, ctx.body.name));
route('POST', '/api/files/delete', (req, res, ctx) => files.remove(ctx.user, ctx.body.paths).then(() => ({ ok: true })));
route('PUT', '/api/files/upload', async (req, res, ctx) => { const r = await files.upload(ctx.user, req, ctx.query.dir, ctx.query.name); return r; }, { raw: true });
route('GET', '/api/files/download', async (req, res, ctx) => { await files.download(ctx.user, ctx.query.path, res); return undefined; });
route('POST', '/api/files/extract', (req, res, ctx) => files.extract(ctx.user, ctx.body.path).then(() => ({ ok: true })));
route('POST', '/api/files/compress', (req, res, ctx) => files.compress(ctx.user, ctx.body.paths, ctx.body.name));
route('POST', '/api/files/move', (req, res, ctx) => files.transfer(ctx.user, ctx.body.paths, ctx.body.dest, { copy: false }));
route('POST', '/api/files/copy', (req, res, ctx) => files.transfer(ctx.user, ctx.body.paths, ctx.body.dest, { copy: true }));

/* ---------- Databases ---------- */
route('GET', '/api/db/engines', () => dbs.engines());
route('GET', '/api/db', (req, res, ctx) => dbs.list(ctx.user));
route('POST', '/api/db/scan', async (req, res, ctx) => { await dbs.discoverSqlite(true); return dbs.list(ctx.user); });
route('POST', '/api/db', (req, res, ctx) => { usage.checkCount(ctx.user, 'databases'); usage.checkStorage(ctx.user); return dbs.create(ctx.user, ctx.body); });
route('GET', '/api/db/:id', (req, res, ctx) => dbs.detail(ctx.user, ctx.params.id));
route('DELETE', '/api/db/:id', (req, res, ctx) => dbs.drop(ctx.params.id, me(ctx), ctx.user).then(() => ({ ok: true })));
route('GET', '/api/db/:id/rows', (req, res, ctx) => dbs.rows(ctx.user, ctx.params.id, ctx.query.table, ctx.query.offset, ctx.query.limit));
route('GET', '/api/db/:id/schema', (req, res, ctx) => dbs.schema(ctx.user, ctx.params.id, ctx.query.table));
route('POST', '/api/db/:id/query', (req, res, ctx) => dbs.query(ctx.user, ctx.params.id, ctx.body), { limit: 1024 * 1024 });
route('POST', '/api/db/:id/password', (req, res, ctx) => dbs.resetPassword(ctx.user, ctx.params.id, ctx.body.password));
route('GET', '/api/db/:id/export', async (req, res, ctx) => { await dbs.exportTo(ctx.user, ctx.params.id, res); return undefined; });

/* ---------- App Store & jobs ---------- */
route('GET', '/api/store', () => appstore.list(), admin);
route('POST', '/api/store/:id/:action', (req, res, ctx) => appstore.act(ctx.params.id, ctx.params.action, me(ctx)), admin);
route('GET', '/api/jobs', (req, res, ctx) => sys.listJobs().filter((j) => ctx.user.role === 'admin' || j.user === ctx.user.username).slice(0, 30));
route('GET', '/api/jobs/:id', async (req, res, ctx) => {
  const j = sys.getJob(ctx.params.id); if (!j) throw notFound('Job not found');
  if (ctx.user.role !== 'admin' && j.user !== ctx.user.username) throw forbidden();
  const chunk = await sys.readJobLog(j.id, Number(ctx.query.offset) || 0);
  return { job: j, ...chunk };
});

/* ---------- Backups ---------- */
const backupAccess = (user, b) => { if (user.role !== 'admin' && (b.scope === 'all' || !canDomain(user, b.scope))) throw forbidden(); };
route('GET', '/api/backups', async (req, res, ctx) => (await backups.list()).filter((b) => ctx.user.role === 'admin' || (b.scope !== 'all' && canDomain(ctx.user, b.scope))));
route('POST', '/api/backups', (req, res, ctx) => { const scope = String(ctx.body.scope || 'all'); if (scope === 'all' && ctx.user.role !== 'admin') throw forbidden(); if (scope !== 'all') needDomain(ctx.user, scope); return { job: backups.create(scope, me(ctx)) }; });
route('POST', '/api/backups/:id/restore', (req, res, ctx) => { const b = S().backups.find((x) => x.id === ctx.params.id); if (!b) throw notFound(); backupAccess(ctx.user, b); return { job: backups.restore(b.id, me(ctx)) }; });
route('DELETE', '/api/backups/:id', (req, res, ctx) => { const b = S().backups.find((x) => x.id === ctx.params.id); if (!b) throw notFound(); backupAccess(ctx.user, b); return backups.remove(b.id, me(ctx)).then(() => ({ ok: true })); });
route('GET', '/api/backups/:id/download', (req, res, ctx) => {
  const b = S().backups.find((x) => x.id === ctx.params.id); if (!b) throw notFound(); backupAccess(ctx.user, b);
  const st = fs.statSync(b.file);
  res.writeHead(200, { 'Content-Type': 'application/gzip', 'Content-Length': st.size, 'Content-Disposition': `attachment; filename="${path.basename(b.file)}"`, 'Cache-Control': 'no-store' });
  fs.createReadStream(b.file).pipe(res);
  return undefined;
});

/* ---------- Cron ---------- */
route('GET', '/api/cron', (req, res, ctx) => cron.list(ctx.user));
route('POST', '/api/cron', (req, res, ctx) => cron.create(ctx.user, ctx.body));
route('PATCH', '/api/cron/:id', (req, res, ctx) => cron.update(ctx.user, ctx.params.id, ctx.body));
route('DELETE', '/api/cron/:id', (req, res, ctx) => cron.remove(ctx.user, ctx.params.id).then(() => ({ ok: true })));
route('POST', '/api/cron/:id/run', (req, res, ctx) => ({ job: cron.runNow(ctx.user, ctx.params.id) }));
route('GET', '/api/cron/:id/log', (req, res, ctx) => cron.readLog(ctx.user, ctx.params.id));

/* ---------- Activity ---------- */
route('GET', '/api/activity', (req, res, ctx) => {
  const limit = Math.min(Number(ctx.query.limit) || 300, 2000);
  const all = store.activity(2000);
  return (ctx.user.role === 'admin' ? all : all.filter((a) => a.user === ctx.user.username)).slice(0, limit);
});

/* ---------- Accounts ---------- */
const domainNames = (u) => (u.domains || []).map((id) => S().domains.find((d) => d.id === id)?.name).filter(Boolean);
route('GET', '/api/accounts', () => S().accounts.map((u) => ({ ...auth.publicUser(u), domainNames: domainNames(u), usage: usage.accountUsage(u) })), admin);
route('POST', '/api/accounts', (req, res, ctx) => {
  const u = auth.createAccount({ username: String(ctx.body.username || '').trim(), password: String(ctx.body.password || ''), role: ctx.body.role, domains: Array.isArray(ctx.body.domains) ? ctx.body.domains : [], limits: auth.readLimits(ctx.body) });
  u.domains.forEach((id) => { const d = hosting.findDomain(id); if (d && !d.accountId) d.accountId = u.id; });
  store.save(); store.log(me(ctx), 'Created account', u.username, 'user');
  return auth.publicUser(u);
}, admin);
route('PATCH', '/api/accounts/:id', (req, res, ctx) => {
  const u = S().accounts.find((x) => x.id === ctx.params.id); if (!u) throw notFound('Account not found');
  const b = ctx.body;
  if (b.status != null) {
    if (!['active', 'disabled'].includes(b.status)) throw bad('Invalid status');
    if (u.id === ctx.user.id && b.status === 'disabled') throw bad('You cannot disable your own account');
    if (u.role === 'admin' && b.status === 'disabled' && S().accounts.filter((a) => a.role === 'admin' && a.status === 'active').length < 2) throw bad('At least one administrator must stay active');
    u.status = b.status; if (b.status === 'disabled') auth.destroyUserSessions(u.id);
  }
  if (b.role != null) {
    if (!['admin', 'domain'].includes(b.role)) throw bad('Invalid role');
    if (u.id === ctx.user.id && b.role !== 'admin') throw bad('You cannot remove your own administrator role');
    u.role = b.role;
  }
  const limits = auth.readLimits(b);
  if (u.role === 'admin') { delete u.quotaMB; delete u.maxDatabases; delete u.maxApps; } else Object.assign(u, limits);
  if (Array.isArray(b.domains)) {
    u.domains = u.role === 'admin' ? [] : b.domains.filter((id) => hosting.findDomain(id));
    S().domains.forEach((d) => { if (d.accountId === u.id && !u.domains.includes(d.id)) d.accountId = null; if (u.domains.includes(d.id) && !d.accountId) d.accountId = u.id; });
  }
  store.save(); store.log(me(ctx), 'Updated account', u.username, 'user');
  return { ...auth.publicUser(u), domainNames: domainNames(u), usage: usage.accountUsage(u) };
}, admin);
route('POST', '/api/accounts/:id/password', (req, res, ctx) => {
  const u = S().accounts.find((x) => x.id === ctx.params.id); if (!u) throw notFound('Account not found');
  const pw = ctx.body.password ? String(ctx.body.password) : genPassword(14);
  auth.checkPasswordStrength(pw);
  u.password = auth.hashPassword(pw); store.save();
  auth.destroyUserSessions(u.id, u.id === ctx.user.id ? ctx.sessionKey : undefined);
  store.log(me(ctx), 'Reset password', u.username, 'key');
  return { password: pw };
}, admin);
route('DELETE', '/api/accounts/:id', (req, res, ctx) => {
  const u = S().accounts.find((x) => x.id === ctx.params.id); if (!u) throw notFound('Account not found');
  if (u.id === ctx.user.id) throw bad('You cannot delete your own account');
  if (u.role === 'admin' && S().accounts.filter((a) => a.role === 'admin').length < 2) throw bad('At least one administrator must remain');
  S().accounts = S().accounts.filter((x) => x.id !== u.id);
  S().domains.forEach((d) => { if (d.accountId === u.id) d.accountId = null; });
  auth.destroyUserSessions(u.id); store.save();
  store.log(me(ctx), 'Deleted account', u.username, 'trash');
  return { ok: true };
}, admin);

/* ---------- Security ---------- */
route('GET', '/api/security', () => system.security(), admin);
route('POST', '/api/security/firewall', (req, res, ctx) => system.addRule(ctx.body, me(ctx)), admin);
route('DELETE', '/api/security/firewall/:num', (req, res, ctx) => system.deleteRule(ctx.params.num, me(ctx), !!ctx.body.force), admin);
route('POST', '/api/security/unban', (req, res, ctx) => system.unban(String(ctx.body.jail || ''), String(ctx.body.ip || ''), me(ctx)), admin);

/* ---------- Traffic: bandwidth and visitors ---------- */
route('GET', '/api/traffic/live', (req, res, ctx) => traffic.liveRates(scopeNames(ctx.user)));
route('GET', '/api/traffic/report', (req, res, ctx) => traffic.report({ from: ctx.query.from, to: ctx.query.to, names: scopeNames(ctx.user), domain: ctx.query.domain || null }));

/* ---------- Troubleshooter ---------- */
route('GET', '/api/doctor', () => doctor.checks(), admin);
route('POST', '/api/doctor/fix', (req, res, ctx) => doctor.fix(String(ctx.body.id || ''), me(ctx)), admin);
route('GET', '/api/doctor/logs', (req, res, ctx) => doctor.logs(ctx.query.unit, ctx.query.lines), admin);

/* ---------- Panel update ---------- */
route('GET', '/api/update', () => update.status(), admin);
route('PUT', '/api/update/upload', async (req, res, ctx) => ({ job: await update.fromUpload(req, me(ctx)) }), { admin: true, raw: true });
route('POST', '/api/update/url', (req, res, ctx) => ({ job: update.fromUrl(ctx.body.url, me(ctx)) }), admin);
route('POST', '/api/update/rollback', async (req, res, ctx) => ({ job: await update.rollback(me(ctx)) }), admin);

module.exports = {};
