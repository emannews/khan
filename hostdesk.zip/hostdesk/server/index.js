'use strict';
/**
 * HostDesk server panel — entry point.
 * Runs as root under systemd (hostdesk.service). No npm dependencies: Node.js built-ins only.
 */
process.removeAllListeners('warning');
process.on('warning', (w) => { if (w.name !== 'ExperimentalWarning') console.warn(w.name + ': ' + w.message); });

const http = require('http');
const cfg = require('./lib/config');
const { ensureDir } = require('./lib/util');
const store = require('./lib/store');
const auth = require('./lib/auth');
const metrics = require('./lib/metrics');
const web = require('./lib/webserver');
const cron = require('./lib/cron');
const backups = require('./lib/backups');
const { createHandler } = require('./lib/http');
require('./routes');

async function main() {
  if (!cfg.dev && process.getuid && process.getuid() !== 0) { console.error('HostDesk must run as root (it manages Nginx, PHP-FPM, systemd and users).'); process.exit(1); }
  for (const d of [cfg.dataDir, cfg.backupDir, cfg.etcDir]) await ensureDir(d, 0o700);
  for (const d of [cfg.wwwRoot, cfg.logDir, cfg.nginxLogDir]) await ensureDir(d, 0o755);

  if (cfg.dev && !store.state.accounts.length) {
    auth.createAccount({ username: 'admin', password: 'admin1234', role: 'admin' });
    console.log('[dev] created account admin / admin1234');
  }
  if (!store.state.accounts.some((a) => a.role === 'admin')) console.warn('No administrator account yet. Create one with:  hostdesk passwd admin');

  try { await web.ensureBaseConf(); } catch (e) { console.error('[nginx] base config:', e.message); }
  try { await cron.sync(); } catch (e) { console.error('[cron] sync:', e.message); }
  metrics.start();
  backups.startScheduler();

  const handler = createHandler({ publicDir: cfg.publicDir, authenticate: auth.getSession });
  const server = http.createServer(handler);
  server.requestTimeout = 0;          // uploads can be long
  server.headersTimeout = 60000;
  server.keepAliveTimeout = 65000;
  server.listen(cfg.port, cfg.host, () => console.log(`HostDesk ${cfg.version} listening on http://${cfg.host}:${cfg.port}${cfg.dev ? ' (dev mode — system commands are not executed)' : ''}`));

  const shutdown = (sig) => {
    console.log(`${sig} received, saving state`);
    store.saveNow();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('uncaughtException', (e) => { console.error('[uncaught]', e.stack || e); store.saveNow(); });
  process.on('unhandledRejection', (e) => console.error('[unhandled]', e && e.stack ? e.stack : e));
}

main().catch((e) => { console.error(e.stack || e); process.exit(1); });
