#!/usr/bin/env node
'use strict';
/**
 * hostdesk — command-line helper
 *   hostdesk passwd <username> [password]   create an administrator, or reset its password
 *   hostdesk info                           show the panel address
 *   hostdesk status                         show service status
 */
process.removeAllListeners('warning');
const { execFileSync } = require('child_process');
const os = require('os');

const [cmd, ...args] = process.argv.slice(2);
const isActive = () => { try { return execFileSync('systemctl', ['is-active', 'hostdesk'], { encoding: 'utf8' }).trim() === 'active'; } catch { return false; } };
const svc = (a) => { try { execFileSync('systemctl', [a, 'hostdesk'], { stdio: 'ignore' }); } catch {} };

function passwd(username, pw) {
  if (!username) { console.error('Usage: hostdesk passwd <username> [password]'); process.exit(1); }
  const wasActive = !process.env.HOSTDESK_DEV && isActive();
  if (wasActive) svc('stop');                     // the running panel would overwrite our change
  try {
    const store = require('./lib/store');
    const auth = require('./lib/auth');
    const { password: gen } = require('./lib/util');
    const generated = !pw; pw = pw || gen(16);
    auth.checkPasswordStrength(pw);
    let u = store.state.accounts.find((a) => a.username.toLowerCase() === username.toLowerCase());
    if (u) { u.password = auth.hashPassword(pw); u.status = 'active'; if (u.role !== 'admin' && process.env.HOSTDESK_MAKE_ADMIN) u.role = 'admin'; }
    else u = auth.createAccount({ username, password: pw, role: 'admin' });
    store.log('cli', 'Set password', u.username, 'key');
    store.saveNow();
    console.log(`Account:  ${u.username} (${u.role})`);
    if (generated) console.log(`Password: ${pw}`);
    else console.log('Password updated.');
  } finally { if (wasActive) svc('start'); }
}

function info() {
  const cfg = require('./lib/config');
  const ips = Object.values(os.networkInterfaces()).flat().filter((x) => x && x.family === 'IPv4' && !x.internal).map((x) => x.address);
  console.log(`HostDesk ${cfg.version}`);
  ips.forEach((ip) => console.log(`  http://${ip}:${cfg.port}`));
  console.log(`  http://localhost:${cfg.port}`);
  console.log('\nTo open it from anywhere, add a public hostname in your Cloudflare Tunnel');
  console.log(`(for example panel.yourdomain.com) with the service http://localhost:${cfg.port}`);
  console.log('and protect it with Cloudflare Access.');
}

switch (cmd) {
  case 'passwd': passwd(args[0], args[1]); break;
  case 'info': info(); break;
  case 'has-admin': { const store = require('./lib/store'); process.exit(store.state.accounts.some((a) => a.role === 'admin' && a.status === 'active') ? 0 : 1); }
  case 'status': try { process.stdout.write(execFileSync('systemctl', ['status', 'hostdesk', '--no-pager', '-n', '20'], { encoding: 'utf8' })); } catch (e) { process.stdout.write(e.stdout || String(e)); } break;
  default:
    console.log('HostDesk command-line helper\n\n  hostdesk passwd <username> [password]   create an administrator or reset a password\n  hostdesk info                           show the panel address\n  hostdesk status                         show the service status\n');
}
