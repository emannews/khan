/* HostDesk — app shell, router, command palette */
(function () {
  'use strict';
  const HD = window.HD;
  const { esc, icon, $, $$ } = HD;

  /* ---------- Event bus ---------- */
  const listeners = {};
  HD.on = (ev, fn) => { (listeners[ev] = listeners[ev] || []).push(fn); return () => (listeners[ev] = listeners[ev].filter((f) => f !== fn)); };
  HD.emit = (ev, data) => (listeners[ev] || []).slice().forEach((f) => f(data));

  /* ---------- Scope (domain accounts only see their domains) ---------- */
  HD.scope = () => { const s = HD.api.session(); return !s || s.role === 'admin' ? null : s.domains; };
  HD.inScope = (domainId) => { const sc = HD.scope(); return !sc || sc.includes(domainId); };
  HD.isAdmin = () => HD.api.session()?.role === 'admin';

  /* ---------- Branding ---------- */
  HD.settings = {};
  HD.applyBranding = (s) => {
    HD.settings = { ...HD.settings, ...s };
    s = HD.settings;
    try { localStorage.setItem('hd_brand', JSON.stringify({ accent: s.accent, theme: s.theme })); } catch {}
    const root = document.documentElement;
    root.style.setProperty('--accent', s.accent || '#4F46E5');
    const theme = s.theme === 'system' ? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : s.theme || 'light';
    root.setAttribute('data-theme', theme);
    const letter = esc((s.panelName || 'H').trim()[0] || 'H').toUpperCase();
    const fav = s.logo || 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="${s.accent}"/><text x="32" y="43" font-family="Arial,sans-serif" font-size="32" font-weight="700" fill="#fff" text-anchor="middle">${letter}</text></svg>`);
    let link = document.querySelector('link[rel="icon"]');
    if (!link) { link = document.createElement('link'); link.rel = 'icon'; document.head.appendChild(link); }
    link.href = fav;
    $$('[data-brand-name]').forEach((e) => (e.textContent = s.panelName || 'HostDesk'));
    $$('[data-brand-logo]').forEach((e) => (e.innerHTML = HD.logoHtml()));
  };
  HD.logoHtml = () => HD.settings.logo ? `<img src="${esc(HD.settings.logo)}" alt="">` : esc((HD.settings.panelName || 'H').trim()[0] || 'H').toUpperCase();

  /* ---------- Navigation ---------- */
  const NAV = [
    { label: 'Overview', items: [['dashboard', 'Dashboard', 'dashboard', '#/dashboard'], ['reports', 'Reports', 'chart', '#/reports']] },
    { label: 'Hosting', items: [['domains', 'Domains', 'globe', '#/domains'], ['apps', 'Applications', 'box', '#/apps'], ['files', 'File manager', 'folder', '#/files'], ['databases', 'Databases', 'database', '#/databases']] },
    { label: 'Network', items: [['routes', 'Routes', 'route', '#/routes']], admin: true },
    { label: 'Maintenance', items: [['backups', 'Backups', 'archive', '#/backups'], ['cron', 'Cron jobs', 'clock', '#/cron'], ['activity', 'Activity', 'activity', '#/activity']] },
    { label: 'Administration', items: [['store', 'App Store', 'layers', '#/store'], ['doctor', 'Troubleshoot', 'stethoscope', '#/doctor'], ['security', 'Security', 'shield', '#/security'], ['accounts', 'Accounts', 'users', '#/accounts'], ['settings', 'Settings', 'settings', '#/settings']], admin: true },
  ];
  HD.NAV = NAV;

  function shellHtml(session) {
    const groups = NAV.filter((g) => !g.admin || session.role === 'admin').map((g) => `
      <div class="nav-group"><div class="nav-label">${g.label}</div>
        ${g.items.map(([key, label, ic, href]) => `<a href="${href}" data-nav="${key}">${icon(ic)}<span>${label}</span><span class="count" data-count="${key}" hidden></span></a>`).join('')}
      </div>`).join('');
    return `
    <div class="app" id="app">
      <aside class="sidebar" aria-label="Sidebar">
        <div class="brand">
          <div class="brand-logo" data-brand-logo>${HD.logoHtml()}</div>
          <div><div class="brand-name" data-brand-name>${esc(HD.settings.panelName)}</div><div class="brand-sub" data-hostname>Server panel</div></div>
        </div>
        <nav class="nav" aria-label="Main">${groups}</nav>
        <div class="sidebar-foot">
          ${session.role === 'admin' ? `<div class="server-mini">
            <div class="host"><span class="status-dot on"></span><span data-hostname-full translate="no">Server</span></div>
            <div class="mini-bars">
              <div class="mini-bar"><div class="row-between"><span>CPU</span><span data-mini="cpu">–</span></div><div class="track"><div class="fill" data-mini-bar="cpu" style="width:0"></div></div></div>
              <div class="mini-bar"><div class="row-between"><span>RAM</span><span data-mini="mem">–</span></div><div class="track"><div class="fill" data-mini-bar="mem" style="width:0"></div></div></div>
            </div>
          </div>` : `<div class="server-mini" data-usage-mini>
            <div class="host"><span class="status-dot on"></span><span>Your storage</span></div>
            <div class="mini-bars"><div class="mini-bar"><div class="row-between"><span data-usage-text>–</span><span data-usage-pct></span></div><div class="track"><div class="fill" data-usage-bar style="width:0"></div></div></div></div>
          </div>`}
        </div>
      </aside>
      <div class="backdrop" data-close-nav></div>
      <div class="main">
        <header class="topbar">
          <button class="icon-btn menu-btn" data-open-nav aria-label="Open menu">${icon('menu')}</button>
          <button class="search-trigger" data-palette>${icon('search', 'i-sm')}<span>Search or jump to…</span><kbd>Ctrl K</kbd></button>
          <div class="topbar-actions">
            <button class="lang-btn" data-lang-toggle title="${HD.lang === 'en' ? 'پښتو' : 'English'}" aria-label="Language" translate="no">${icon('language', 'i-sm')}<span>${HD.lang === 'en' ? 'پښتو' : 'EN'}</span></button>
            <button class="icon-btn" data-theme-toggle aria-label="Switch light or dark mode">${icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon')}</button>
            <div class="user-chip"><span class="avatar">${esc(HD.initials(session.username))}</span><div class="who"><div class="name" translate="no">${esc(session.username)}</div><div class="role">${session.role === 'admin' ? 'Administrator' : 'Domain account'}</div></div></div>
            <button class="icon-btn" data-logout aria-label="Sign out" title="Sign out">${icon('logout')}</button>
          </div>
        </header>
        <main class="content" id="view" tabindex="-1"></main>
      </div>
    </div>`;
  }

  /* ---------- Router ---------- */
  const ROUTES = [
    ['login', 'login'], ['', 'dashboard'], ['dashboard', 'dashboard'],
    ['domains', 'domains'], ['domains/:name', 'domain'], ['domains/:name/:tab', 'domain'],
    ['apps', 'apps'], ['apps/new', 'appNew'], ['apps/:id', 'app'], ['apps/:id/:tab', 'app'],
    ['files', 'files'], ['databases', 'databases'], ['databases/:id', 'database'],
    ['routes', 'routes'], ['backups', 'backups'], ['cron', 'cron'], ['activity', 'activity'],
    ['accounts', 'accounts'], ['settings', 'settings'], ['store', 'store'], ['security', 'security'],
    ['reports', 'reports'], ['doctor', 'doctor'],
  ];
  function match(hash) {
    const raw = hash.replace(/^#\/?/, '');
    const [pathStr, qs = ''] = raw.split('?');
    const parts = pathStr.split('/').filter(Boolean).map(decodeURIComponent);
    const query = Object.fromEntries(new URLSearchParams(qs));
    for (const [pat, page] of ROUTES) {
      const pp = pat.split('/').filter(Boolean);
      if (pp.length !== parts.length) continue;
      const params = {}; let okk = true;
      pp.forEach((p, i) => { if (p.startsWith(':')) params[p.slice(1)] = parts[i]; else if (p !== parts[i]) okk = false; });
      if (okk) return { page, params, query, path: pathStr };
    }
    return { page: 'notFound', params: {}, query, path: pathStr };
  }

  let current = null, shellOn = false, renderId = 0;
  HD.go = (path) => { if (location.hash === '#' + path) HD.rerender(); else location.hash = path; };
  HD.rerender = () => route(true);

  async function route(keepScroll) {
    const ctx = match(location.hash || '#/dashboard');
    const session = HD.api.session();
    if (!session && ctx.page !== 'login') { location.hash = '#/login'; return; }
    if (session && ctx.page === 'login') { location.hash = '#/dashboard'; return; }
    const page = HD.pages[ctx.page] || HD.pages.notFound;
    if (page.admin && !HD.isAdmin()) { location.hash = '#/dashboard'; return; }

    HD.closeModals('route');
    current?.page.unmount && current.page.unmount();
    const id = ++renderId;
    const scrollY = keepScroll ? window.scrollY : 0;

    if (ctx.page === 'login') {
      shellOn = false;
      document.body.innerHTML = await page.render(ctx);
      page.mount && page.mount(document.body, ctx);
      current = { page, ctx };
      document.title = HD.t('Sign in') + ' · ' + (HD.settings.panelName || 'HostDesk');
      return;
    }
    if (!shellOn) {
      document.body.innerHTML = shellHtml(session); bindShell(); shellOn = true;
      clearInterval(metricsTimer);
      if (session.role === 'admin') { refreshMeta(); setTimeout(pollMetrics, 50); metricsTimer = setInterval(pollMetrics, 5000); }
      else { refreshUsage(); metricsTimer = setInterval(refreshUsage, 60000); }
    }

    let html;
    try { html = await page.render(ctx); }
    catch (err) { html = errorHtml(err); }
    if (id !== renderId) return;
    const old = $('#view');
    const view = old.cloneNode(false);
    view.innerHTML = html;
    old.replaceWith(view);
    current = { page, ctx };
    try { page.mount && page.mount(view, ctx); } catch (e) { console.error(e); }
    $$('[data-nav]').forEach((a) => a.classList.toggle('active', a.dataset.nav === (page.nav || ctx.page)));
    $('#app').classList.remove('nav-open');
    document.title = (typeof page.title === 'function' ? page.title(ctx) : HD.t(page.title || 'Panel')) + ' · ' + (HD.settings.panelName || 'HostDesk');
    window.scrollTo(0, scrollY);
    if (!keepScroll) view.focus({ preventScroll: true });
    refreshCounts();
  }

  function errorHtml(err) {
    return `<div class="card">${HD.empty('alert', 'Something went wrong', err.message || String(err), '<a class="btn" href="#/dashboard">Back to dashboard</a>')}</div>`;
  }

  HD.pages.notFound = {
    title: 'Not found',
    render: () => `<div class="card">${HD.empty('search', 'Page not found', 'The page you opened does not exist.', '<a class="btn" href="#/dashboard">Go to dashboard</a>')}</div>`,
  };

  async function refreshUsage() {
    if (!HD.api.session() || document.hidden) return;
    let u; try { u = await HD.api.myUsage(); } catch { return; }
    const t = $('[data-usage-text]'), p = $('[data-usage-pct]'), b = $('[data-usage-bar]');
    if (t) t.textContent = HD.fmtBytes(u.used) + (u.quota ? ' / ' + HD.fmtBytes(u.quota) : '');
    if (p) p.textContent = u.quota ? Math.round(Math.min(100, u.percent)) + '%' : '';
    if (b) b.style.width = (u.quota ? Math.min(100, u.percent) : 0) + '%';
  }
  async function refreshMeta() {
    let srv; try { srv = await HD.api.server(); } catch { return; }
    HD.serverInfo = srv;
    $$('[data-hostname-full]').forEach((e) => (e.textContent = srv.hostname));
    $$('[data-hostname]').forEach((e) => (e.textContent = srv.hostname));
  }
  async function refreshCounts() {
    try {
      const c = await HD.api.overview();
      const set = (k, v) => { const el = $(`[data-count="${k}"]`); if (el) { el.textContent = v; el.hidden = !v; } };
      set('domains', c.domains + c.subdomains); set('apps', c.apps);
    } catch {}
  }
  HD.refreshCounts = refreshCounts;

  /* ---------- Live metrics (sidebar + dashboard) ---------- */
  let metricsTimer;
  async function pollMetrics() {
    if (!HD.api.session() || document.hidden) return;
    let m; try { m = await HD.api.metrics(); } catch { return; }
    HD.lastMetrics = m;
    const memPct = Math.round((m.memUsed / (m.memTotal || 1)) * 100);
    const set = (k, txt, pct) => { const t = $(`[data-mini="${k}"]`), b = $(`[data-mini-bar="${k}"]`); if (t) t.textContent = txt; if (b) b.style.width = pct + '%'; };
    set('cpu', Math.round(m.cpu) + '%', m.cpu); set('mem', memPct + '%', memPct);
    HD.emit('metrics', m);
  }

  /* ---------- Shell events ---------- */
  function bindShell() {
    const app = $('#app');
    app.addEventListener('click', async (e) => {
      if (e.target.closest('[data-open-nav]')) app.classList.add('nav-open');
      if (e.target.closest('[data-close-nav]')) app.classList.remove('nav-open');
      if (e.target.closest('[data-palette]')) openPalette();
      if (e.target.closest('[data-theme-toggle]')) toggleTheme();
      if (e.target.closest('[data-lang-toggle]')) switchLang(HD.lang === 'en' ? 'ps' : 'en');
      if (e.target.closest('[data-logout]')) { await HD.api.logout(); shellOn = false; clearInterval(metricsTimer); HD.go('/login'); }
    });
  }
  async function toggleTheme() {
    const dark = document.documentElement.dataset.theme === 'dark';
    const theme = dark ? 'light' : 'dark';
    if (HD.isAdmin()) { try { await HD.api.saveSettings({ theme }); } catch {} }
    HD.applyBranding({ theme });
    const b = $('[data-theme-toggle]'); if (b) b.innerHTML = icon(dark ? 'moon' : 'sun');
    HD.emit('theme');
  }
  HD.toggleTheme = toggleTheme;

  /* ---------- Language ---------- */
  async function switchLang(lang) {
    HD.setLang(lang);
    if (HD.api.session()) { try { await HD.api.savePrefs({ lang }); HD._session.lang = lang; } catch {} }
  }
  HD.switchLang = switchLang;
  // Draw everything again in the new language
  HD.on('lang', () => { shellOn = false; route(true); });

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k' && shellOn) { e.preventDefault(); openPalette(); }
  });

  /* ---------- Command palette ---------- */
  async function openPalette() {
    if ($('.palette')) return;
    const [domains, apps] = await Promise.all([HD.api.listDomains().catch(() => []), HD.api.listApps().catch(() => [])]);
    const admin = HD.isAdmin();
    const items = [];
    const T = HD.t;
    NAV.filter((g) => !g.admin || admin).forEach((g) => g.items.forEach(([, label, ic, href]) => items.push({ group: T('Pages'), label: T(label), ic, href })));
    if (admin) items.push({ group: T('Actions'), label: T('Add domain'), ic: 'plus', href: '#/domains?new=1' });
    items.push({ group: T('Actions'), label: T('Create application'), ic: 'plus', href: '#/apps/new' });
    items.push({ group: T('Actions'), label: T('Upload files'), ic: 'upload', href: '#/files' });
    items.push({ group: T('Actions'), label: T('Switch light / dark mode'), ic: 'moon', run: toggleTheme });
    items.push({ group: T('Actions'), label: HD.lang === 'en' ? 'پښتو ژبه' : 'English', ic: 'language', run: () => switchLang(HD.lang === 'en' ? 'ps' : 'en') });
    if (admin) items.push({ group: T('Actions'), label: T('Find and fix problems'), ic: 'stethoscope', href: '#/doctor' });
    items.push({ group: T('Actions'), label: T('Sign out'), ic: 'logout', run: async () => { await HD.api.logout(); shellOn = false; HD.go('/login'); } });
    domains.forEach((d) => items.push({ group: T('Domains'), label: d.name, ic: d.parentId ? 'layers' : 'globe', href: '#/domains/' + encodeURIComponent(d.name), meta: d.app ? (d.app.runtime === 'node' ? ':' + d.app.port : 'PHP') : T('Static'), raw: true }));
    apps.forEach((a) => items.push({ group: T('Applications'), label: a.name, ic: 'box', href: '#/apps/' + a.id, meta: a.domain, raw: true }));

    let sel = 0, list = items;
    const m = HD.modal({
      bare: true, size: 'palette',
      body: `<div class="palette-input">${icon('search')}<input type="text" placeholder="Search pages, domains, applications…" aria-label="Search"></div>
             <div class="palette-list" role="listbox"></div>
             <div class="palette-foot"><span><kbd>↑</kbd> <kbd>↓</kbd> move</span><span><kbd>Enter</kbd> open</span><span><kbd>Esc</kbd> close</span></div>`,
      onMount(el) {
        el.classList.add('palette');
        const input = el.querySelector('input'), box = el.querySelector('.palette-list');
        const draw = () => {
          let g = '', html = '';
          list.forEach((it, i) => {
            if (it.group !== g) { g = it.group; html += `<div class="palette-group">${g}</div>`; }
            html += `<button class="palette-item ${i === sel ? 'on' : ''}" data-i="${i}" role="option">${icon(it.ic)}<span ${it.raw ? 'translate="no"' : ''}>${esc(it.label)}</span>${it.meta ? `<span class="meta" translate="no">${esc(it.meta)}</span>` : ''}</button>`;
          });
          box.innerHTML = html || `<div class="empty" style="padding:28px">No results</div>`;
          box.querySelector('.on')?.scrollIntoView({ block: 'nearest' });
        };
        const run = (it) => { if (!it) return; m.close(); if (it.run) it.run(); else location.hash = it.href.slice(1); };
        input.addEventListener('input', () => { const q = input.value.toLowerCase().trim(); list = items.filter((it) => !q || it.label.toLowerCase().includes(q) || (it.meta || '').toLowerCase().includes(q)); sel = 0; draw(); });
        input.addEventListener('keydown', (e) => {
          if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(sel + 1, list.length - 1); draw(); }
          if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(sel - 1, 0); draw(); }
          if (e.key === 'Enter') { e.preventDefault(); run(list[sel]); }
        });
        box.addEventListener('click', (e) => { const b = e.target.closest('[data-i]'); if (b) run(list[+b.dataset.i]); });
        draw();
      },
    });
  }
  HD.openPalette = openPalette;

  /* ---------- Boot ---------- */
  async function boot() {
    try { HD.applyBranding(await HD.api.branding()); } catch { HD.applyBranding({ panelName: 'HostDesk', accent: '#4F46E5', theme: 'light' }); }
    try { const b = JSON.parse(localStorage.getItem('hd_brand') || '{}'); if (b.theme) HD.applyBranding({ theme: b.theme }); } catch {}
    const me = await HD.api.me();
    let saved = null; try { saved = localStorage.getItem('hd_lang'); } catch {}
    HD.setLang((me && me.lang) || saved || HD.settings.language || 'en', { persist: !!(me && me.lang) || !!saved });
    matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => HD.settings.theme === 'system' && HD.applyBranding(HD.settings));
    window.addEventListener('hashchange', () => route(false));
    document.addEventListener('visibilitychange', () => { if (!document.hidden) pollMetrics(); });
    await route(false);
  }
  document.addEventListener('DOMContentLoaded', boot);
})();
