/* HostDesk — languages (English, Pashto).
 *
 * The interface is written in English. When another language is chosen:
 *  - HD.t(text, params) translates strings built in code (with {placeholders});
 *  - everything else on screen is translated automatically: text, placeholders, titles and
 *    aria-labels are looked up in the dictionary (exact match, then patterns) whenever they appear.
 * Names, paths, code and logs are never translated: they sit inside code/pre/.mono or translate="no".
 */
(function () {
  'use strict';
  const HD = (window.HD = window.HD || {});
  const LANGS = { en: { name: 'English', dir: 'ltr', locale: 'en-GB' }, ps: { name: 'پښتو', dir: 'rtl', locale: 'ps-AF-u-ca-gregory-nu-latn' } };
  HD.LANGS = LANGS;
  HD.dict = HD.dict || {};          // lang -> { english: translation }
  HD.patterns = HD.patterns || {};  // lang -> [[RegExp, replacement | fn]]
  HD.lang = 'en';

  const fill = (s, p) => (p ? String(s).replace(/\{(\w+)\}/g, (m, k) => (p[k] != null ? p[k] : m)) : String(s));

  // Host names, file names, paths, e-mails and app names (host-app) are never translated
  const NAMEISH = /^[\w-]+(\.[\w-]+)+$|\/|@|^[a-z0-9]+[-_][\w-]*$/;
  let depth = 0;
  const sub = (v) => { depth++; try { return lookup(v); } finally { depth--; } };
  /** Translate one English string (exact match first, then patterns). Returns null when unknown. */
  function lookup(text) {
    const d = HD.dict[HD.lang]; if (!d) return null;
    if (Object.prototype.hasOwnProperty.call(d, text)) return d[text];
    // Same text with a final period / colon / ellipsis
    const m = text.match(/^(.*?)([.:…?!]+)$/);
    if (m && Object.prototype.hasOwnProperty.call(d, m[1])) return d[m[1]] + (m[2] === '?' ? '؟' : m[2]);
    for (const [re, rep] of HD.patterns[HD.lang] || []) {
      const r = text.match(re);
      if (r) {
        if (typeof rep === 'function') return rep(...r);
        return rep.replace(/\$(\d)/g, (_, i) => {
          const v = r[+i] ?? '';
          const t = /[A-Za-z]/.test(v) && !NAMEISH.test(v) && depth < 4 ? sub(v) : null;
          if (t != null) return t;
          // Latin text with numbers (sizes, versions, names) keeps its own direction
          return /[A-Za-z0-9]/.test(v) && !/[\u0600-\u06FF]/.test(v) && !/^\u2066/.test(v) ? '\u2066' + v + '\u2069' : v;
        });
      }
    }
    return null;
  }
  HD.tr = (text) => (HD.lang === 'en' ? null : lookup(text));

  /** Translate a string used in code. Params fill {name} placeholders after translation. */
  HD.t = (key, params) => {
    if (HD.lang === 'en') return fill(key, params);
    const d = HD.dict[HD.lang] || {};
    if (Object.prototype.hasOwnProperty.call(d, key)) return fill(d[key], params);
    const filled = fill(key, params);
    return lookup(filled) ?? filled;
  };
  HD.locale = () => LANGS[HD.lang].locale;

  /* ---------- Automatic translation of the page ---------- */
  const SKIP = 'code, pre, script, style, textarea, kbd, .mono, [translate="no"], [data-no-t]';
  const LATIN = /[A-Za-z]/;
  const ATTRS = ['placeholder', 'title', 'aria-label'];

  function translateText(node) {
    const v = node.nodeValue; if (!v || !LATIN.test(v)) return;
    const p = node.parentElement; if (!p || p.closest(SKIP)) return;
    const trimmed = v.trim(); if (!trimmed) return;
    const tr = lookup(trimmed.replace(/\s+/g, ' '));
    if (tr == null || tr === trimmed) return;
    const lead = v.match(/^\s*/)[0], tail = v.match(/\s*$/)[0];
    node.nodeValue = lead + tr + tail;
  }
  function translateAttrs(el) {
    if (el.closest(SKIP)) return;
    for (const a of ATTRS) {
      const v = el.getAttribute(a); if (!v || !LATIN.test(v)) continue;
      const tr = lookup(v.trim()); if (tr != null && tr !== v) { if (!el.hasAttribute('data-en-' + a)) el.setAttribute('data-en-' + a, v); el.setAttribute(a, tr); }
    }
  }
  function translateTree(root) {
    if (HD.lang === 'en' || !root) return;
    if (root.nodeType === 3) return translateText(root);
    if (root.nodeType !== 1) return;
    if (root.closest && root.closest(SKIP)) return;
    translateAttrs(root);
    root.querySelectorAll('[placeholder],[title],[aria-label]').forEach(translateAttrs);
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = []; while (w.nextNode()) nodes.push(w.currentNode);
    nodes.forEach(translateText);
  }
  HD.translateTree = translateTree;

  let observer = null;
  function observe() {
    if (observer) return;
    observer = new MutationObserver((list) => {
      if (HD.lang === 'en') return;
      for (const m of list) {
        if (m.type === 'characterData') translateText(m.target);
        else if (m.type === 'attributes') translateAttrs(m.target);
        else m.addedNodes.forEach(translateTree);
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }

  function applyDocument() {
    const L = LANGS[HD.lang];
    document.documentElement.lang = HD.lang;
    document.documentElement.dir = L.dir;
  }

  /** Switch language. The shell and page are drawn again by app.js (event "lang"). */
  HD.setLang = (lang, { persist = true } = {}) => {
    if (!LANGS[lang]) lang = 'en';
    const changed = lang !== HD.lang;
    HD.lang = lang;
    try { if (persist) localStorage.setItem('hd_lang', lang); } catch {}
    applyDocument();
    if (lang !== 'en') { observe(); translateTree(document.body); }
    if (changed && HD.emit) HD.emit('lang', lang);
  };

  // Before first paint: use the language this browser chose last time
  try { const saved = localStorage.getItem('hd_lang'); if (saved && LANGS[saved]) { HD.lang = saved; applyDocument(); } } catch {}
  document.addEventListener('DOMContentLoaded', () => { if (HD.lang !== 'en') { observe(); translateTree(document.body); } });
})();
