/* HostDesk — API client. Talks to the panel server (same origin, cookie session). */
(function () {
  'use strict';
  const HD = window.HD;

  async function http(method, url, body) {
    const opts = { method, headers: { 'X-HostDesk': '1' }, credentials: 'same-origin' };
    if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    let r;
    try { r = await fetch(url, opts); }
    catch { throw new Error('Cannot reach the panel. Check your connection.'); }
    const isJson = (r.headers.get('content-type') || '').includes('json');
    const data = isJson ? await r.json() : await r.text();
    if (r.status === 401 && !url.startsWith('/api/auth/login')) {
      HD._session = null;
      if (!location.hash.startsWith('#/login')) location.hash = '#/login';
      throw new Error((data && data.error) || 'Please sign in');
    }
    if (!r.ok) throw new Error((isJson ? data.error : data) || `Request failed (${r.status})`);
    return data;
  }
  const get = (u) => http('GET', u), post = (u, b = {}) => http('POST', u, b), put = (u, b = {}) => http('PUT', u, b), patch = (u, b = {}) => http('PATCH', u, b), del = (u, b) => http('DELETE', u, b);
  const q = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v != null && v !== '')).toString();

  /* Upload one file with progress (XHR gives upload progress, fetch does not). */
  function upload(dir, file, onProgress, url) {
    return new Promise((resolve, reject) => {
      const x = new XMLHttpRequest();
      x.open('PUT', url || '/api/files/upload?' + q({ dir, name: file.name }));
      x.setRequestHeader('X-HostDesk', '1');
      x.setRequestHeader('Content-Type', 'application/octet-stream');
      x.upload.onprogress = (e) => e.lengthComputable && onProgress && onProgress(e.loaded / e.total);
      x.onload = () => { let d = {}; try { d = JSON.parse(x.responseText); } catch {} x.status < 300 ? resolve(d) : reject(new Error(d.error || `Upload failed (${x.status})`)); };
      x.onerror = () => reject(new Error('Upload failed. Check your connection.'));
      x.send(file);
    });
  }

  HD.api = {
    session: () => HD._session || null,
    async me() { try { const r = await get('/api/auth/me'); HD._session = r.user; return r.user; } catch { HD._session = null; return null; } },
    async login(username, password, remember) { const r = await post('/api/auth/login', { username, password, remember }); HD._session = r.user; return r.user; },
    async logout() { try { await post('/api/auth/logout'); } catch {} HD._session = null; },
    changePassword: (old, nw) => post('/api/auth/password', { old, new: nw }),
    savePrefs: (p) => put('/api/auth/prefs', p),
    myUsage: () => get('/api/me/usage'),
    branding: () => get('/api/branding'),

    getSettings: () => get('/api/settings'),
    saveSettings: (s) => put('/api/settings', s),
    reapply: () => post('/api/settings/reapply'),

    server: () => get('/api/system/info'),
    metrics: () => get('/api/system/metrics'),
    services: () => get('/api/system/services'),
    serviceAction: (id, action) => post(`/api/system/services/${encodeURIComponent(id)}/${action}`),
    storage: () => get('/api/system/storage'),
    overview: () => get('/api/system/overview'),
    timezones: () => get('/api/system/timezones'),
    setTimezone: (timezone) => put('/api/system/timezone', { timezone }),

    listDomains: () => get('/api/domains'),
    async getDomainByName(name) { const all = await get('/api/domains'); const d = all.find((x) => x.name === name); if (!d) throw new Error('Domain not found'); return { domain: d, all }; },
    createDomain: (d) => post('/api/domains', d),
    updateDomain: (id, p) => patch(`/api/domains/${id}`, p),
    deleteDomain: (id, opts) => del(`/api/domains/${id}`, opts),

    listApps: () => get('/api/apps'),
    getApp: (id) => get(`/api/apps/${id}`),
    appsMeta: () => get('/api/apps-meta'),
    createApp: (d) => post('/api/apps', d),
    updateApp: (id, p) => patch(`/api/apps/${id}`, p),
    deleteApp: (id) => del(`/api/apps/${id}`),
    appAction: (id, action) => post(`/api/apps/${id}/action/${action}`),
    appLogs: (id, lines) => get(`/api/apps/${id}/logs?` + q({ lines })),

    routes: () => get('/api/routes'),
    routesConfig: () => get('/api/routes/config'),

    fileRoots: () => get('/api/files/roots'),
    listDir: (path) => get('/api/files/list?' + q({ path })),
    readFile: (path) => get('/api/files/read?' + q({ path })),
    writeFile: (path, content, mtime) => put('/api/files/write?' + q({ path }), { content, mtime }),
    mkdir: (path, name) => post('/api/files/mkdir', { path, name }),
    createFile: (path, name) => post('/api/files/create', { path, name }),
    rename: (path, name) => post('/api/files/rename', { path, name }),
    remove: (paths) => post('/api/files/delete', { paths: [].concat(paths) }),
    upload,
    extract: (path) => post('/api/files/extract', { path }),
    compress: (paths, name) => post('/api/files/compress', { paths, name }),
    move: (paths, dest) => post('/api/files/move', { paths: [].concat(paths), dest }),
    copy: (paths, dest) => post('/api/files/copy', { paths: [].concat(paths), dest }),
    downloadUrl: (path) => '/api/files/download?' + q({ path }),

    dbEngines: () => get('/api/db/engines'),
    listDatabases: () => get('/api/db'),
    scanDatabases: () => post('/api/db/scan'),
    getDatabase: (id) => get(`/api/db/${id}`),
    createDatabase: (d) => post('/api/db', d),
    deleteDatabase: (id) => del(`/api/db/${id}`),
    tableRows: (id, table, offset, limit) => get(`/api/db/${id}/rows?` + q({ table, offset, limit })),
    tableSchema: (id, table) => get(`/api/db/${id}/schema?` + q({ table })),
    runQuery: (id, input) => post(`/api/db/${id}/query`, input),
    resetDbPassword: (id, password) => post(`/api/db/${id}/password`, { password }),
    dbExportUrl: (id) => `/api/db/${id}/export`,

    store: () => get('/api/store'),
    storeAction: (id, action) => post(`/api/store/${id}/${action}`),
    jobs: () => get('/api/jobs'),
    job: (id, offset) => get(`/api/jobs/${id}?offset=${offset || 0}`),

    listBackups: () => get('/api/backups'),
    createBackup: (scope) => post('/api/backups', { scope }),
    restoreBackup: (id) => post(`/api/backups/${id}/restore`),
    deleteBackup: (id) => del(`/api/backups/${id}`),
    backupUrl: (id) => `/api/backups/${id}/download`,

    listCron: () => get('/api/cron'),
    createCron: (d) => post('/api/cron', d),
    updateCron: (id, p) => patch(`/api/cron/${id}`, p),
    deleteCron: (id) => del(`/api/cron/${id}`),
    runCron: (id) => post(`/api/cron/${id}/run`),
    cronLog: (id) => get(`/api/cron/${id}/log`),

    listActivity: (limit) => get('/api/activity?' + q({ limit })),

    listAccounts: () => get('/api/accounts'),
    createAccount: (d) => post('/api/accounts', d),
    updateAccount: (id, p) => patch(`/api/accounts/${id}`, p),
    resetAccountPassword: (id) => post(`/api/accounts/${id}/password`),
    deleteAccount: (id) => del(`/api/accounts/${id}`),

    security: () => get('/api/security'),
    addFirewallRule: (r) => post('/api/security/firewall', r),
    deleteFirewallRule: (num, force) => del(`/api/security/firewall/${num}`, { force }),
    unban: (jail, ip) => post('/api/security/unban', { jail, ip }),

    trafficLive: () => get('/api/traffic/live'),
    trafficReport: (from, to, domain) => get('/api/traffic/report?' + q({ from, to, domain })),

    doctor: () => get('/api/doctor'),
    doctorFix: (id) => post('/api/doctor/fix', { id }),
    doctorLogs: (unit, lines) => get('/api/doctor/logs?' + q({ unit, lines })),

    updateStatus: () => get('/api/update'),
    updateUpload: (file, onProgress) => upload(null, file, onProgress, '/api/update/upload'),
    updateFromUrl: (url) => post('/api/update/url', { url }),
    rollback: () => post('/api/update/rollback'),
    health: () => get('/api/health'),
  };
})();
