/* Apply the saved theme and color before the first paint (avoids a flash). */
(function () {
  try {
    var b = JSON.parse(localStorage.getItem('hd_brand') || '{}');
    var t = b.theme === 'system' ? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : (b.theme || 'light');
    document.documentElement.setAttribute('data-theme', t);
    if (b.accent) document.documentElement.style.setProperty('--accent', b.accent);
  } catch (e) {}
})();
