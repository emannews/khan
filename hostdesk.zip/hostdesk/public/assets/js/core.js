/* HostDesk — core helpers: escaping, formatting, icons, toasts, modals */
(function () {
  'use strict';
  const HD = (window.HD = window.HD || {});
  HD.pages = HD.pages || {};

  /* ---------- Basics ---------- */
  const MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  HD.esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => MAP[c]);
  HD.$ = (s, r = document) => r.querySelector(s);
  HD.$$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  HD.uid = () => Math.random().toString(36).slice(2, 10);
  HD.clone = (v) => JSON.parse(JSON.stringify(v));
  HD.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  HD.debounce = (fn, ms = 200) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  HD.fmtBytes = (b) => {
    if (b == null || isNaN(b)) return '—';
    if (b < 1024) return b + ' B';
    const u = ['KB', 'MB', 'GB', 'TB']; let i = -1;
    do { b /= 1024; i++; } while (b >= 1024 && i < u.length - 1);
    return (b >= 100 ? b.toFixed(0) : b >= 10 ? b.toFixed(1) : b.toFixed(1)) + ' ' + u[i];
  };
  HD.fmtNum = (n) => Number(n).toLocaleString('en-US');
  HD.fmtDate = (ts) => new Date(ts).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  HD.fmtDateTime = (ts) => new Date(ts).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  HD.fmtTime = (ts) => new Date(ts).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  HD.timeAgo = (ts) => {
    const s = Math.round((Date.now() - ts) / 1000);
    if (s < 45) return 'just now';
    const m = Math.round(s / 60); if (m < 60) return m + ' min ago';
    const h = Math.round(m / 60); if (h < 24) return h + ' h ago';
    const d = Math.round(h / 24); if (d < 30) return d + (d === 1 ? ' day ago' : ' days ago');
    return HD.fmtDate(ts);
  };
  HD.fmtUptime = (sec) => {
    const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
    if (d) return `${d}d ${h}h`;
    if (h) return `${h}h ${m}m`;
    return `${m}m`;
  };
  HD.initials = (s) => String(s || '?').replace(/[^a-zA-Z0-9]/g, ' ').trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '?';

  /* ---------- Icons (24px stroke) ---------- */
  const I = {
    dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.5 2.7 3.8 5.7 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-5.7-3.8-9S9.5 5.7 12 3z"/>',
    box: '<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
    folder: '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H9l2 2.5h7.5A2.5 2.5 0 0 1 21 10v7.5a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/>',
    folderPlus: '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H9l2 2.5h7.5A2.5 2.5 0 0 1 21 10v7.5a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/><path d="M12 11v6M9 14h6"/>',
    file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
    filePlus: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M12 11v6M9 14h6"/>',
    fileCode: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M10 12l-2 2 2 2M14 12l2 2-2 2"/>',
    database: '<ellipse cx="12" cy="5.5" rx="8" ry="2.5"/><path d="M4 5.5v6c0 1.4 3.6 2.5 8 2.5s8-1.1 8-2.5v-6"/><path d="M4 11.5v7c0 1.4 3.6 2.5 8 2.5s8-1.1 8-2.5v-7"/>',
    route: '<circle cx="6" cy="19" r="2.5"/><circle cx="18" cy="5" r="2.5"/><path d="M8.5 19H16a3.5 3.5 0 0 0 0-7H8a3.5 3.5 0 0 1 0-7h7.5"/>',
    archive: '<rect x="3" y="4" width="18" height="5" rx="1.5"/><path d="M5 9v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9M10 13h4"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    activity: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M21.5 20a6.5 6.5 0 0 0-4-6"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    chevRight: '<path d="M9 6l6 6-6 6"/>',
    chevLeft: '<path d="M15 6l-6 6 6 6"/>',
    chevDown: '<path d="M6 9l6 6 6-6"/>',
    play: '<path d="M7 5v14l11-7z"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
    restart: '<path d="M20 12a8 8 0 1 1-2.34-5.66"/><path d="M20 4v5h-5"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
    edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
    download: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
    external: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    checkCircle: '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.8 2.8L16 10"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
    logout: '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 17l-5-5 5-5M5 12h11"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/>',
    shield: '<path d="M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    server: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01M11 7.5h6M11 16.5h6"/>',
    cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9.5" y="9.5" width="5" height="5" rx="1"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
    memory: '<rect x="3" y="7" width="18" height="10" rx="2"/><path d="M7 7v10M11 7v10M15 7v10M3 20h18M6 17v3M18 17v3"/>',
    disk: '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
    network: '<path d="M7 17V7M4 10l3-3 3 3M17 7v10M14 14l3 3 3-3"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    terminal: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9l3 3-3 3M13 15h4"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1"/><path d="M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14.9-3M4 4v4h4M4 13a8 8 0 0 0 14.9 3M20 20v-4h-4"/>',
    code: '<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>',
    zip: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M11 4h1M11 7h1M11 10h1M11 13h1M10.5 16h2v2.5h-2z"/>',
    alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v4M12 17.5h.01"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.5h.01"/>',
    git: '<circle cx="6" cy="6" r="2.5"/><circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="9" r="2.5"/><path d="M6 8.5v7M18 11.5c0 3-3 3.5-6 4.5-2 .7-4 1-6 2"/>',
    power: '<path d="M12 3v9M6.3 6.3a8 8 0 1 0 11.4 0"/>',
    cloud: '<path d="M7 18a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 9.5a4.3 4.3 0 0 1-.5 8.5z"/>',
    home: '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
    play2: '<circle cx="12" cy="12" r="9"/><path d="M10 8.5v7l6-3.5z"/>',
    more: '<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
    php: '<ellipse cx="12" cy="12" rx="10" ry="6"/><path d="M7 14.5l1-5h2a1.3 1.3 0 0 1 0 2.6H8.4M11.5 9.5l-1 5M11 12h2.3l-.5 2.5M15.5 14.5l1-5h2a1.3 1.3 0 0 1 0 2.6h-1.6"/>',
    node: '<path d="M12 2.5l8.5 4.9v9.2L12 21.5l-8.5-4.9V7.4z"/><path d="M14.8 9.6c-.4-.8-1.4-1.3-2.7-1.3-1.6 0-2.6.7-2.6 1.8 0 2.5 5.6 1.3 5.6 4 0 1.1-1.1 1.9-2.9 1.9-1.4 0-2.5-.6-2.9-1.5"/>',
    bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    filter: '<path d="M4 5h16l-6 8v6l-4-2v-4z"/>',
    gauge: '<path d="M4 18a9 9 0 1 1 16 0"/><path d="M12 14l4-5"/>',
    text: '<path d="M5 7V5h14v2M9 19h6M12 5v14"/>',
    wand: '<path d="M4 20L16 8M14 4v3M18 8h3M17 3l-2 2M19.5 5.5L18 7"/>',
  };
  HD.ICONS = I;
  HD.icon = (name, cls = '') => `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${I[name] || ''}</svg>`;

  /* ---------- UI snippets ---------- */
  HD.badge = (text, kind = '', dot = false) => `<span class="badge ${kind ? 'b-' + kind : ''}">${dot ? '<span class="dot"></span>' : ''}${HD.esc(text)}</span>`;
  HD.runtimeBadge = (rt, ver) => rt === 'node' ? HD.badge(`Node ${ver || ''}`.trim(), 'node') : rt === 'php' ? HD.badge(`PHP ${ver || ''}`.trim(), 'php') : HD.badge('No app');
  HD.statusBadge = (st) => {
    const m = { running: ['Running', 'success'], stopped: ['Stopped', ''], error: ['Error', 'danger'], active: ['Active', 'success'], disabled: ['Disabled', ''], connected: ['Connected', 'success'] };
    const [t, k] = m[st] || [st, ''];
    return HD.badge(t, k, true);
  };
  HD.engineLabel = (e) => ({ sqlite: 'SQLite', mysql: 'MySQL / MariaDB', postgres: 'PostgreSQL', mongodb: 'MongoDB' }[e] || e);
  HD.switchBtn = (on, attrs = '') => `<button type="button" class="switch" role="switch" aria-checked="${on ? 'true' : 'false'}" ${attrs}></button>`;
  HD.empty = (icon, title, text, action = '') => `
    <div class="empty"><div class="empty-ic">${HD.icon(icon, 'i-lg')}</div><h3>${HD.esc(title)}</h3><div>${HD.esc(text)}</div>${action ? `<div style="margin-top:10px">${action}</div>` : ''}</div>`;

  /* ---------- Toasts ---------- */
  HD.toast = (msg, type = 'success') => {
    let box = HD.$('.toasts');
    if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
    const t = document.createElement('div');
    t.className = 'toast ' + type;
    const ic = type === 'error' ? 'alert' : type === 'info' ? 'info' : 'checkCircle';
    t.innerHTML = HD.icon(ic) + `<span>${HD.esc(msg)}</span>`;
    box.appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 220); }, 3200);
  };

  /* ---------- Modal ---------- */
  HD._modals = new Set();
  HD.closeModals = (reason = 'route') => Array.from(HD._modals).forEach((m) => m.close(reason));
  HD.modal = ({ title = '', desc = '', body = '', foot = '', size = '', onMount, onClose, bare = false } = {}) => {
    const wrap = document.createElement('div');
    wrap.className = 'modal-backdrop';
    wrap.innerHTML = bare
      ? `<div class="modal ${size}" role="dialog" aria-modal="true">${body}</div>`
      : `<div class="modal ${size}" role="dialog" aria-modal="true" aria-label="${HD.esc(title)}">
          <div class="modal-head"><div><div class="modal-title">${HD.esc(title)}</div>${desc ? `<div class="modal-desc">${desc}</div>` : ''}</div>
          <button class="icon-btn sm" data-close aria-label="Close">${HD.icon('x')}</button></div>
          <div class="modal-body">${body}</div>
          ${foot ? `<div class="modal-foot">${foot}</div>` : ''}
        </div>`;
    const prevFocus = document.activeElement;
    let isClosed = false;
    const close = (reason) => {
      if (isClosed) return; isClosed = true;
      document.removeEventListener('keydown', onKey);
      wrap.remove(); HD._modals.delete(api);
      onClose && onClose(reason);
      if (reason !== 'route') prevFocus && prevFocus.focus && prevFocus.focus();
    };
    const onKey = (e) => { const all = document.querySelectorAll('.modal-backdrop'); if (e.key === 'Escape' && all[all.length - 1] === wrap) close(); };
    wrap.addEventListener('mousedown', (e) => { if (e.target === wrap) close(); });
    wrap.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) close(); });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(wrap);
    const m = wrap.querySelector('.modal');
    const first = m.querySelector('input:not([type=hidden]):not([readonly]), select, textarea');
    setTimeout(() => (first || m.querySelector('button'))?.focus(), 30);
    const api = { el: m, close };
    HD._modals.add(api);
    onMount && onMount(m, api);
    return api;
  };

  HD.confirm = ({ title = 'Are you sure?', message = '', confirmText = 'Confirm', danger = true } = {}) =>
    new Promise((resolve) => {
      let done = false;
      const m = HD.modal({
        body: `<div class="modal-body" style="padding-top:22px">
                 <div class="confirm-ic" style="${danger ? '' : 'background:var(--accent-soft);color:var(--accent-text)'}">${HD.icon(danger ? 'alert' : 'info')}</div>
                 <div class="modal-title">${HD.esc(title)}</div>
                 <div class="modal-desc" style="margin-top:6px">${message}</div>
               </div>
               <div class="modal-foot"><button class="btn" data-close>Cancel</button>
               <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-ok>${HD.esc(confirmText)}</button></div>`,
        bare: true, size: '',
        onClose: () => { if (!done) resolve(false); },
        onMount: (el, api) => {
          el.style.maxWidth = '440px';
          el.querySelector('[data-ok]').addEventListener('click', () => { done = true; resolve(true); api.close(); });
          setTimeout(() => el.querySelector('[data-ok]').focus(), 40);
        },
      });
    });

  /* Read form values: { name: value } (checkbox → boolean) */
  HD.formData = (root) => {
    const out = {};
    HD.$$('[name]', root).forEach((el) => {
      if (el.type === 'checkbox') out[el.name] = el.checked;
      else if (el.type === 'radio') { if (el.checked) out[el.name] = el.value; }
      else out[el.name] = el.value.trim ? el.value.trim() : el.value;
    });
    return out;
  };

  HD.copy = async (text, label = 'Copied to clipboard') => {
    try { await navigator.clipboard.writeText(text); }
    catch {
      const ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch {} ta.remove();
    }
    HD.toast(label, 'info');
  };

  HD.download = (name, content, type = 'text/plain') => {
    const blob = content instanceof Blob ? content : new Blob([content], { type });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };

  /**
   * Show a background job (install, backup, npm install …) with its live log.
   * Resolves with the final job object when it finishes or the dialog is closed.
   */
  HD.jobModal = (job, { title, onDone } = {}) => new Promise((resolve) => {
    let offset = 0, timer = null, closed = false, last = job;
    const badge = (st) => st === 'success' ? HD.badge('Finished', 'success', true) : st === 'failed' ? HD.badge('Failed', 'danger', true) : HD.badge(st === 'queued' ? 'Waiting' : 'Running…', 'accent', true);
    HD.modal({
      title: title || job.title, size: 'lg',
      desc: 'You can close this window. The task keeps running on the server.',
      body: `<div class="row-between" style="margin-bottom:10px"><span data-st>${badge(job.status)}</span><span class="muted" style="font-size:12.5px" data-time></span></div><pre class="code" data-log style="height:340px"></pre>`,
      foot: `<button class="btn btn-primary" data-close>Close</button>`,
      onClose: () => { closed = true; clearTimeout(timer); resolve(last); },
      onMount(el) {
        const logEl = el.querySelector('[data-log]'), st = el.querySelector('[data-st]'), tm = el.querySelector('[data-time]');
        const poll = async () => {
          if (closed) return;
          try {
            const r = await HD.api.job(job.id, offset);
            last = r.job; offset = r.offset;
            if (r.text) {
              const near = logEl.scrollHeight - logEl.scrollTop - logEl.clientHeight < 60;
              logEl.textContent += r.text;
              if (near) logEl.scrollTop = logEl.scrollHeight;
            }
            st.innerHTML = badge(r.job.status);
            tm.textContent = r.job.endedAt ? `Took ${Math.max(1, Math.round((r.job.endedAt - r.job.startedAt) / 1000))} s` : `Started ${HD.timeAgo(r.job.startedAt)}`;
            if (r.job.status === 'success' || r.job.status === 'failed') {
              if (r.job.status === 'failed') HD.toast(r.job.error || 'Task failed', 'error'); else HD.toast(`${r.job.title}: done`);
              onDone && onDone(r.job);
              return;
            }
          } catch (e) { tm.textContent = e.message; }
          timer = setTimeout(poll, 1000);
        };
        poll();
      },
    });
  });

  /* Field error helper */
  HD.fieldError = (form, name, msg) => {
    const input = form.querySelector(`[name="${name}"]`);
    if (!input) return HD.toast(msg, 'error');
    input.style.borderColor = 'var(--danger)';
    input.focus();
    let h = input.closest('.field')?.querySelector('.err');
    if (!h) { h = document.createElement('div'); h.className = 'hint err'; h.style.color = 'var(--danger)'; input.closest('.field')?.appendChild(h); }
    h.textContent = msg;
    input.addEventListener('input', () => { input.style.borderColor = ''; h.remove(); }, { once: true });
  };
})();
