/* HostDesk — small SVG charts with hover tooltips */
(function () {
  'use strict';
  const HD = window.HD;

  /**
   * Line chart.
   * opts: { series:[{name,color,values,fill?}], times:[ms], max, height, unit, fmtX(ts), fmtTip(ts) }
   */
  function line(el, opts) {
    const { series, times, max = 100, height = 220, unit = '%', fmtX = (t) => HD.fmtTime(t).slice(0, 5), fmtTip = fmtX } = opts;
    const n = times.length, W = 1000, H = height;
    const X = (i) => (i / (n - 1)) * W;
    const Y = (v) => H - (Math.min(v, max) / max) * H;
    const ticks = [0, .25, .5, .75, 1].map((f) => Math.round(max * f));
    const grid = ticks.map((t) => `<path d="M0 ${Y(t).toFixed(1)}H${W}" stroke="var(--border-2)" stroke-width="1" vector-effect="non-scaling-stroke"/>`).join('');
    const gid = 'g' + HD.uid();
    const paths = series.map((s, si) => {
      const pts = s.values.map((v, i) => `${X(i).toFixed(1)},${Y(v).toFixed(1)}`);
      const lineD = 'M' + pts.join('L');
      const area = s.fill ? `<path d="${lineD}L${W},${H}L0,${H}Z" fill="url(#${gid}${si})"/>` : '';
      const defs = s.fill ? `<defs><linearGradient id="${gid}${si}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.color}" stop-opacity=".16"/><stop offset="1" stop-color="${s.color}" stop-opacity="0"/></linearGradient></defs>` : '';
      return defs + area + `<path d="${lineD}" fill="none" stroke="${s.color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>`;
    }).join('');
    const xl = [0, .25, .5, .75, 1].map((f) => `<span>${HD.esc(fmtX(times[Math.round(f * (n - 1))]))}</span>`).join('');
    el.innerHTML = `
      <div class="chart-grid">
        <div class="chart-y" style="height:${H}px;margin:-7px 0">${ticks.slice().reverse().map((t) => `<span>${t}${unit}</span>`).join('')}</div>
        <div class="chart" style="height:${H}px">
          <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="height:${H}px" role="img" aria-label="${HD.esc(series.map((s) => `${s.name} ${Math.min(...s.values)} to ${Math.max(...s.values)}${unit}`).join(', '))}">${grid}<path d="M0 ${H - .5}H${W}" stroke="var(--border)" stroke-width="1" vector-effect="non-scaling-stroke"/>${paths}</svg>
          <div class="chart-cross" style="height:${H}px"></div>
          ${series.map((s) => `<div class="chart-dot" style="position:absolute;width:10px;height:10px;margin:-5px 0 0 -5px;border-radius:50%;background:${s.color};border:2px solid var(--surface);box-shadow:0 0 0 1px ${s.color};opacity:0;pointer-events:none"></div>`).join('')}
          <div class="chart-tip"></div>
        </div>
      </div>
      <div class="chart-x">${xl}</div>`;
    const box = el.querySelector('.chart'), cross = el.querySelector('.chart-cross'), tip = el.querySelector('.chart-tip'), dots = el.querySelectorAll('.chart-dot');
    const show = (on) => { [cross, tip, ...dots].forEach((d) => (d.style.opacity = on ? 1 : 0)); };
    box.addEventListener('mousemove', (e) => {
      const r = box.getBoundingClientRect();
      const i = Math.max(0, Math.min(n - 1, Math.round(((e.clientX - r.left) / r.width) * (n - 1))));
      const px = (i / (n - 1)) * r.width;
      cross.style.left = px + 'px';
      series.forEach((s, si) => { dots[si].style.left = px + 'px'; dots[si].style.top = (Y(s.values[i]) / H) * r.height + 'px'; });
      tip.innerHTML = `<div class="t">${HD.esc(fmtTip(times[i]))}</div>` + series.map((s) => `<div class="r"><span style="display:flex;align-items:center;gap:6px"><i style="width:8px;height:8px;border-radius:2px;background:${s.color}"></i>${HD.esc(s.name)}</span><b>${s.values[i]}${unit}</b></div>`).join('');
      const tw = tip.offsetWidth;
      tip.style.left = (px + 14 + tw > r.width ? px - tw - 14 : px + 14) + 'px';
      tip.style.top = '8px';
      show(true);
    });
    box.addEventListener('mouseleave', () => show(false));
  }

  /** Tiny sparkline (no axes) */
  function spark(values, color = 'var(--accent)', max = 100, h = 36) {
    const n = values.length, W = 200;
    const d = 'M' + values.map((v, i) => `${((i / (n - 1)) * W).toFixed(1)},${(h - (Math.min(v, max) / max) * h).toFixed(1)}`).join('L');
    return `<svg viewBox="0 0 ${W} ${h}" preserveAspectRatio="none" style="width:100%;height:${h}px;display:block" aria-hidden="true"><path d="${d}" fill="none" stroke="${color}" stroke-width="2" vector-effect="non-scaling-stroke" stroke-linejoin="round"/></svg>`;
  }

  HD.chart = { line, spark };
})();
