/* HostDesk — small SVG charts with hover tooltips */
(function () {
  'use strict';
  const HD = window.HD;

  /**
   * Line chart.
   * opts: { series:[{name,color,values,fill?}], times:[ms], max, height, unit, fmtX(ts), fmtTip(ts) }
   */
  /** A round number at or above v, for chart scales (1, 2, 2.5, 5 × 10^n). */
  function niceMax(v) {
    if (!(v > 0)) return 1;
    const p = Math.pow(10, Math.floor(Math.log10(v)));
    for (const m of [1, 2, 2.5, 5, 10]) if (m * p >= v) return m * p;
    return 10 * p;
  }
  /** Bytes scale: round to 1/2/5 × KB/MB/GB so the labels look clean. */
  function niceBytes(v) {
    if (!(v > 0)) return 1024;
    const u = Math.pow(1024, Math.max(0, Math.floor(Math.log(v) / Math.log(1024))));
    return niceMax(v / u) * u;
  }

  function line(el, opts) {
    const { series, times, height = 220, unit = '%', fmtX = (t) => HD.fmtTime(t).slice(0, 5), fmtTip = fmtX } = opts;
    const fmtVal = opts.fmtVal || ((v) => v + unit);
    const max = opts.max || (opts.bytes ? niceBytes(Math.max(1, ...series.flatMap((s) => s.values))) : niceMax(Math.max(1, ...series.flatMap((s) => s.values))));
    const n = times.length, W = 1000, H = height;
    const X = (i) => (n > 1 ? (i / (n - 1)) * W : W / 2);
    const Y = (v) => H - (Math.min(v, max) / max) * H;
    const ticks = [0, .25, .5, .75, 1].map((f) => (opts.bytes ? max * f : Math.round(max * f)));
    const grid = ticks.map((t) => `<path d="M0 ${Y(t).toFixed(1)}H${W}" stroke="var(--border-2)" stroke-width="1" vector-effect="non-scaling-stroke"/>`).join('');
    const gid = 'g' + HD.uid();
    const paths = series.map((s, si) => {
      const pts = s.values.map((v, i) => `${X(i).toFixed(1)},${Y(v).toFixed(1)}`);
      const lineD = 'M' + pts.join('L');
      const area = s.fill ? `<path d="${lineD}L${W},${H}L0,${H}Z" fill="url(#${gid}${si})"/>` : '';
      const defs = s.fill ? `<defs><linearGradient id="${gid}${si}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.color}" stop-opacity=".16"/><stop offset="1" stop-color="${s.color}" stop-opacity="0"/></linearGradient></defs>` : '';
      return defs + area + `<path d="${lineD}" fill="none" stroke="${s.color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>`;
    }).join('');
    const xl = [0, .25, .5, .75, 1].map((f) => `<span>${HD.esc(fmtX(times[Math.round(f * (n - 1))]))}</span>`).join('');
    el.classList.add('chart-wrap');
    el.innerHTML = `
      <div class="chart-grid">
        <div class="chart-y" style="height:${H}px;margin:-7px 0">${ticks.slice().reverse().map((t) => `<span>${HD.esc(opts.fmtTick ? opts.fmtTick(t) : fmtVal(t))}</span>`).join('')}</div>
        <div class="chart" style="height:${H}px">
          <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="height:${H}px" role="img" aria-label="${HD.esc(series.map((s) => `${s.name} ${fmtVal(Math.min(...s.values))} – ${fmtVal(Math.max(...s.values))}`).join(', '))}">${grid}<path d="M0 ${H - .5}H${W}" stroke="var(--border)" stroke-width="1" vector-effect="non-scaling-stroke"/>${paths}</svg>
          <div class="chart-cross" style="height:${H}px"></div>
          ${series.map((s) => `<div class="chart-dot" style="position:absolute;width:10px;height:10px;margin:-5px 0 0 -5px;border-radius:50%;background:${s.color};border:2px solid var(--surface);box-shadow:0 0 0 1px ${s.color};opacity:0;pointer-events:none"></div>`).join('')}
          <div class="chart-tip"></div>
        </div>
      </div>
      <div class="chart-grid"><span></span><div class="chart-x">${xl}</div></div>`;
    const box = el.querySelector('.chart'), cross = el.querySelector('.chart-cross'), tip = el.querySelector('.chart-tip'), dots = el.querySelectorAll('.chart-dot');
    const show = (on) => { [cross, tip, ...dots].forEach((d) => (d.style.opacity = on ? 1 : 0)); };
    box.addEventListener('mousemove', (e) => {
      const r = box.getBoundingClientRect();
      const i = Math.max(0, Math.min(n - 1, Math.round(((e.clientX - r.left) / r.width) * (n - 1))));
      const px = (i / (n - 1)) * r.width;
      cross.style.left = px + 'px';
      series.forEach((s, si) => { dots[si].style.left = px + 'px'; dots[si].style.top = (Y(s.values[i]) / H) * r.height + 'px'; });
      tip.innerHTML = `<div class="t">${HD.esc(fmtTip(times[i]))}</div>` + series.map((s) => `<div class="r"><span style="display:flex;align-items:center;gap:6px"><i style="width:8px;height:8px;border-radius:2px;background:${s.color}"></i>${HD.esc(s.name)}</span><b>${HD.esc(fmtVal(s.values[i]))}</b></div>`).join('');
      const tw = tip.offsetWidth;
      tip.style.left = (px + 14 + tw > r.width ? px - tw - 14 : px + 14) + 'px';
      tip.style.top = '8px';
      show(true);
    });
    box.addEventListener('mouseleave', () => show(false));
  }

  /** Tiny sparkline (no axes) */
  function spark(values, color = 'var(--accent)', max = 100, h = 36) {
    const n = values.length, W = 200;
    const d = 'M' + values.map((v, i) => `${((i / (n - 1)) * W).toFixed(1)},${(h - (Math.min(v, max) / max) * h).toFixed(1)}`).join('L');
    return `<svg viewBox="0 0 ${W} ${h}" preserveAspectRatio="none" style="width:100%;height:${h}px;display:block" aria-hidden="true"><path d="${d}" fill="none" stroke="${color}" stroke-width="2" vector-effect="non-scaling-stroke" stroke-linejoin="round"/></svg>`;
  }

  /**
   * Bar chart with hover tooltips.
   * opts: { labels:[str], values:[num], color, height, fmtVal(v), tip(i) -> [[label, value]], xEvery }
   */
  function bars(el, opts) {
    const { labels, values, height = 220, color = 'var(--accent)' } = opts;
    const fmtVal = opts.fmtVal || ((v) => HD.fmtNum(v));
    const n = values.length;
    const max = opts.bytes ? niceBytes(Math.max(1, ...values)) : niceMax(Math.max(1, ...values));
    const ticks = [0, .25, .5, .75, 1].map((f) => max * f);
    const every = opts.xEvery || Math.max(1, Math.ceil(n / 8));
    el.classList.add('chart-wrap');
    el.innerHTML = `
      <div class="chart-grid">
        <div class="chart-y" style="height:${height}px;margin:-7px 0">${ticks.slice().reverse().map((t) => `<span>${HD.esc(fmtVal(t))}</span>`).join('')}</div>
        <div class="chart bars" style="height:${height}px">
          ${ticks.map((t) => `<i class="bar-grid" style="bottom:${(t / max) * 100}%"></i>`).join('')}
          <div class="bar-row">${values.map((v, i) => `<span class="bar" data-i="${i}"><span style="height:${Math.max(v > 0 ? 1.5 : 0, (v / max) * 100)}%;background:${color}"></span></span>`).join('')}</div>
          <div class="chart-tip"></div>
        </div>
      </div>
      <div class="chart-grid"><span></span><div class="chart-x bars-x">${labels.map((l, i) => `<span>${i % every === 0 ? HD.esc(l) : ''}</span>`).join('')}</div></div>`;
    const box = el.querySelector('.chart'), tip = el.querySelector('.chart-tip');
    box.addEventListener('mousemove', (e) => {
      const b = e.target.closest('.bar'); if (!b) { tip.style.opacity = 0; return; }
      const i = +b.dataset.i; const r = box.getBoundingClientRect(), br = b.getBoundingClientRect();
      const rows = opts.tip ? opts.tip(i) : [['', fmtVal(values[i])]];
      tip.innerHTML = `<div class="t">${HD.esc(labels[i])}</div>` + rows.map(([k, v]) => `<div class="r"><span>${HD.esc(k)}</span><b>${HD.esc(v)}</b></div>`).join('');
      const px = br.left - r.left + br.width / 2, tw = tip.offsetWidth;
      tip.style.left = Math.max(0, Math.min(r.width - tw, px - tw / 2)) + 'px'; tip.style.top = '6px'; tip.style.opacity = 1;
      HD.$$('.bar.on', box).forEach((x) => x.classList.remove('on')); b.classList.add('on');
    });
    box.addEventListener('mouseleave', () => { tip.style.opacity = 0; HD.$$('.bar.on', box).forEach((x) => x.classList.remove('on')); });
  }

  HD.chart = { line, spark, bars, niceMax, niceBytes };
})();
