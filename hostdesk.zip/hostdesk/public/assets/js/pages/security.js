/* Security — firewall, Fail2ban, SSH */
(function () {
  const HD = window.HD; const { esc, icon } = HD;
  const OLD_PORTS = /^(20|21|888|33501|39000:40000)(\/|$)/;

  HD.pages.security = {
    title: 'Security', nav: 'security', admin: true,
    async render() {
      const s = await HD.api.security();
      const fw = s.firewall, f2b = s.fail2ban, ssh = s.ssh;
      const tips = [];
      if (fw.installed && !fw.active) tips.push(['danger', 'The firewall (UFW) is off.']);
      if (!f2b.installed) tips.push(['warn', 'Fail2ban is not installed. It blocks people who try many SSH passwords.']);
      if (ssh.permitRootLogin === 'yes') tips.push(['warn', 'Root can sign in over SSH with a password. Use a normal user with sudo, or keys only.']);
      if (fw.rules.some((r) => OLD_PORTS.test(r.to))) tips.push(['warn', 'Some open ports look like they belong to an older panel or FTP. HostDesk does not need them; you can delete those rules.']);
      const sshRow = (k, v, good) => `<div class="list-row"><span class="muted">${k}</span><span class="row" style="gap:8px"><span class="mono">${esc(v ?? '—')}</span>${good == null ? '' : good ? HD.badge('Good', 'success') : HD.badge('Check', 'warn')}</span></div>`;
      return `
      <div class="page-head"><div><h1 class="page-title">Security</h1><p class="page-sub">Firewall, login protection and SSH</p></div></div>
      ${tips.length ? `<div class="stack-sm" style="margin-bottom:16px">${tips.map(([k, t]) => `<div class="callout ${k === 'danger' || k === 'warn' ? 'warn' : ''}">${icon('alert', 'i-sm')}<div>${esc(t)}</div></div>`).join('')}</div>` : `<div class="callout" style="margin-bottom:16px">${icon('shield', 'i-sm')}<div>No problems found.</div></div>`}
      <div class="grid g-main" style="align-items:start">
        <section class="card">
          <div class="card-head"><div><div class="card-title">${icon('shield', 'i-sm')}Firewall (UFW)</div><div class="card-sub">Incoming connections. Cloudflare Tunnel needs no open ports.</div></div>${!fw.installed ? HD.badge('Not installed', '') : fw.active ? HD.badge('On', 'success', true) : HD.badge('Off', 'danger', true)}</div>
          ${fw.rules.length ? `<div class="table-wrap"><table class="table">
            <thead><tr><th>#</th><th>Port</th><th>Action</th><th>From</th><th>Used for</th><th><span class="sr-only">Delete</span></th></tr></thead>
            <tbody>${fw.rules.map((r) => `<tr>
              <td class="muted">${r.num}</td>
              <td class="mono cell-title">${esc(r.to)}</td>
              <td>${r.action === 'ALLOW' ? HD.badge('Allow', 'success') : r.action === 'LIMIT' ? HD.badge('Limit', 'accent') : HD.badge(r.action[0] + r.action.slice(1).toLowerCase(), 'danger')}</td>
              <td class="mono">${esc(r.from)}</td>
              <td>${r.service ? esc(r.service) : '<span class="muted">Unknown</span>'}${OLD_PORTS.test(r.to) ? ' ' + HD.badge('Not needed', 'warn') : ''}</td>
              <td class="actions"><button class="icon-btn danger" data-delrule="${r.num}" data-label="${esc(r.to + ' from ' + r.from)}" aria-label="Delete rule ${r.num}">${icon('trash', 'i-sm')}</button></td>
            </tr>`).join('')}</tbody></table></div>` : `<div class="card-body muted">${fw.installed ? 'No rules.' : 'UFW is not installed.'}</div>`}
          ${fw.installed ? `<form class="card-foot" data-addrule style="flex-wrap:wrap;justify-content:flex-start;gap:10px" novalidate>
            <input class="input mono" name="port" placeholder="Port, e.g. 8080" style="width:150px" aria-label="Port">
            <select class="select" name="proto" style="width:100px" aria-label="Protocol"><option>tcp</option><option>udp</option><option>any</option></select>
            <input class="input mono" name="from" placeholder="From: any or 192.168.0.0/24" style="width:230px" aria-label="Source">
            <select class="select" name="action" style="width:110px" aria-label="Action"><option value="allow">Allow</option><option value="deny">Deny</option></select>
            <button class="btn btn-primary" type="submit">${icon('plus', 'i-sm')}Add rule</button>
          </form>` : ''}
        </section>
        <div class="stack">
          <section class="card">
            <div class="card-head"><div class="card-title">${icon('lock', 'i-sm')}Fail2ban</div>${!f2b.installed ? HD.badge('Not installed', '') : f2b.running ? HD.badge('Running', 'success', true) : HD.badge('Stopped', 'warn', true)}</div>
            <div class="card-body">
              ${!f2b.installed ? `<p class="muted" style="margin:0 0 12px;font-size:13.5px">Blocks an IP for one hour after 5 failed SSH logins in 10 minutes. Your local network is never blocked.</p><a class="btn btn-sm btn-primary" href="#/store">${icon('download', 'i-sm')}Install from App Store</a>`
                : f2b.jails?.length ? f2b.jails.map((j) => `<div class="list-row" style="align-items:flex-start"><div><div class="title mono">${esc(j.name)}</div><div class="sub">${j.banned} blocked now · ${j.total} in total</div></div><div style="text-align:end">${j.ips.map((ip) => `<div class="row" style="gap:4px;justify-content:flex-end"><span class="mono" style="font-size:12.5px">${esc(ip)}</span><button class="btn btn-sm btn-ghost" data-unban="${esc(ip)}" data-jail="${esc(j.name)}">Unblock</button></div>`).join('') || '<span class="muted" style="font-size:13px">Nobody blocked</span>'}</div></div>`).join('') : '<span class="muted">No active jails.</span>'}
            </div>
          </section>
          <section class="card">
            <div class="card-head"><div class="card-title">${icon('terminal', 'i-sm')}SSH</div></div>
            <div class="card-body tight">
              ${sshRow('Port', ssh.port, null)}
              ${sshRow('Root login', ssh.permitRootLogin, ssh.permitRootLogin ? ssh.permitRootLogin !== 'yes' : null)}
              ${sshRow('Password login', ssh.passwordAuth, null)}
            </div>
            <div class="card-foot" style="justify-content:flex-start"><span class="hint">${HD.t('Changed in {file}. Read only here, so a mistake cannot lock you out.', { file: '<span class="mono">/etc/ssh/sshd_config</span>' })}</span></div>
          </section>
          <section class="card">
            <div class="card-head"><div class="card-title">${icon('globe', 'i-sm')}Panel access</div></div>
            <div class="card-body" style="font-size:13.5px">
              <p style="margin:0 0 8px">${HD.t('The panel listens on port {port}.', { port: `<b class="mono">${s.panelPort}</b>` })}</p>
              <p class="muted" style="margin:0">${HD.t('To open it from anywhere, add a hostname such as {host} to your Cloudflare Tunnel with the service {svc}, and protect it with Cloudflare Access (Zero Trust → Access → Applications).', { host: '<span class="mono">panel.your-domain</span>', svc: `<span class="mono">http://localhost:${s.panelPort}</span>` })}</p>
            </div>
          </section>
        </div>
      </div>`;
    },
    mount(el) {
      el.querySelector('[data-addrule]')?.addEventListener('submit', async (e) => {
        e.preventDefault(); const f = e.target; const d = HD.formData(f); if (!d.from) d.from = 'any';
        try { await HD.api.addFirewallRule(d); HD.toast('Rule added'); HD.rerender(); } catch (ex) { HD.fieldError(f, /source/i.test(ex.message) ? 'from' : 'port', ex.message); }
      });
      el.addEventListener('click', async (e) => {
        const del = e.target.closest('[data-delrule]');
        if (del && (await HD.confirm({ title: `Delete rule ${del.dataset.delrule}?`, message: `${esc(del.dataset.label)} will no longer be allowed.`, confirmText: 'Delete rule' }))) {
          try { await HD.api.deleteFirewallRule(del.dataset.delrule); HD.toast('Rule deleted'); HD.rerender(); }
          catch (ex) {
            if (/lock you out/.test(ex.message) && (await HD.confirm({ title: 'Delete the SSH rule anyway?', message: esc(ex.message) + ' Only do this if you have another way into the server.', confirmText: 'Delete anyway' }))) {
              try { await HD.api.deleteFirewallRule(del.dataset.delrule, true); HD.toast('Rule deleted'); HD.rerender(); } catch (x) { HD.toast(x.message, 'error'); }
            } else if (!/lock you out/.test(ex.message)) HD.toast(ex.message, 'error');
          }
        }
        const ub = e.target.closest('[data-unban]');
        if (ub) { try { await HD.api.unban(ub.dataset.jail, ub.dataset.unban); HD.toast(`${ub.dataset.unban} unblocked`); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); } }
      });
    },
  };
})();
