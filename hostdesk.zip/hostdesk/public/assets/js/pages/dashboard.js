/* Dashboard — server overview for administrators, "my sites" overview for domain accounts */
(function () {
  const HD = window.HD; const { esc, icon } = HD;
  let off = null, range = 'hour', liveTimer = null;
  const meterCls = (p) => (p >= 90 ? 'danger' : p >= 75 ? 'warn' : '');
  const rate = HD.fmtRate;
  const svcIcon = (s) => s.icon || 'server';
  const greet = () => { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'; };
  const NO_RESTART = ['ssh', 'cloudflared'];

  /* ---------- Shared cards ---------- */
  function liveCard(live, domains) {
    return `<section class="card" data-live-card>
      <div class="card-head">
        <div><div class="card-title"><span class="live-dot"></span>Live bandwidth</div><div class="card-sub">Per domain · last 15 seconds</div></div>
        <div class="live-total"><b data-live-total>${rate(live.total.out)}</b><span class="muted">${HD.fmtNum(live.total.rps)} req/s</span></div>
      </div>
      <div class="card-body tight" data-live-list>${liveRows(live, domains)}</div>
      <div class="card-foot" style="justify-content:flex-start"><a class="link-btn" href="#/reports">${icon('chart', 'i-sm')}Bandwidth and visitor reports</a></div>
    </section>`;
  }
  function liveRows(live, domains) {
    if (!live.domains.length) return `<div class="empty" style="padding:26px 10px"><div class="empty-ic">${icon('network', 'i-lg')}</div><h3>No visitors right now</h3><div>Traffic shows here as soon as someone opens one of your sites.</div></div>`;
    const max = Math.max(1, ...live.domains.map((d) => d.out));
    return live.domains.slice(0, 8).map((d) => {
      const dm = domains.find((x) => x.name === d.name);
      return `<div class="live-row">
        <div class="live-name"><span class="d-ic sm">${icon(dm?.parentId ? 'layers' : 'globe', 'i-xs')}</span>${dm ? `<a href="#/domains/${encodeURIComponent(d.name)}" class="truncate">${esc(d.name)}</a>` : `<span class="truncate">${esc(d.name)}</span>`}</div>
        <div class="live-bar"><span style="width:${Math.max(2, (d.out / max) * 100)}%"></span></div>
        <div class="live-val"><b>${rate(d.out)}</b><span>${HD.fmtNum(d.rps)} req/s</span></div>
      </div>`;
    }).join('');
  }
  function todayCard(t, sub) {
    return `<section class="card">
      <div class="card-head"><div><div class="card-title">${icon('calendar', 'i-sm')}Today</div><div class="card-sub">${esc(sub)}</div></div><a class="btn btn-sm" href="#/reports">Reports</a></div>
      <div class="card-body today-grid">
        <div><span class="k">Visitors</span><span class="v">${HD.fmtNum(t.uv)}</span></div>
        <div><span class="k">Page views</span><span class="v">${HD.fmtNum(t.pv)}</span></div>
        <div><span class="k">Bandwidth</span><span class="v">${HD.fmtBytes(t.out)}</span></div>
        <div><span class="k">Requests</span><span class="v">${HD.fmtNum(t.req)}</span></div>
      </div>
    </section>`;
  }
  function appsCard(apps) {
    return `<section class="card">
      <div class="card-head"><div class="card-title">Applications</div><a href="#/apps" class="link-btn" style="font-size:13px">View all</a></div>
      <div class="card-body tight">
        ${apps.length ? apps.slice(0, 7).map((a) => `
          <div class="list-row">
            <div class="row" style="gap:10px;min-width:0"><span class="status-dot ${a.live.state === 'running' ? 'on' : a.live.state === 'error' ? 'err' : 'off'}"></span>
              <div style="min-width:0"><a class="title" style="color:var(--text)" href="#/apps/${a.id}">${esc(a.name)}</a><div class="sub truncate">${esc(a.domain)}</div></div></div>
            <div style="text-align:end"><div class="mono" style="font-weight:600">:${a.port}</div><div class="sub" data-appres="${a.id}">${resText(a)}</div></div>
          </div>`).join('') : HD.empty('box', 'No applications yet', 'Create one for a domain.', `<a class="btn btn-sm btn-primary" href="#/apps/new">${icon('plus', 'i-sm')}Create</a>`)}
      </div>
    </section>`;
  }
  function activityCard(act) {
    return `<section class="card">
      <div class="card-head"><div class="card-title">Recent activity</div><a href="#/activity" class="link-btn" style="font-size:13px">View all</a></div>
      <div class="card-body tight timeline">
        ${act.length ? act.map((a) => `
          <div class="tl-item"><span class="ic">${icon(a.icon || 'activity', 'i-xs')}</span>
            <div style="min-width:0"><div class="txt"><b translate="no">${esc(a.user)}</b> <span data-act>${esc(a.action)}</span> <b translate="no">${esc(a.target)}</b></div><div class="when">${HD.timeAgo(a.time)}</div></div></div>`).join('') : '<div class="muted" style="padding:16px 0;font-size:13px">Nothing yet.</div>'}
      </div>
    </section>`;
  }
  function startLive(el, getDomains) {
    clearInterval(liveTimer);
    liveTimer = setInterval(async () => {
      if (document.hidden) return;
      const live = await HD.api.trafficLive().catch(() => null); if (!live) return;
      const list = el.querySelector('[data-live-list]'); if (!list) return;
      list.innerHTML = liveRows(live, getDomains());
      const t = el.querySelector('[data-live-total]'); if (t) t.textContent = rate(live.total.out);
    }, 5000);
  }

  /* ---------- Domain account ---------- */
  async function renderAccount() {
    const [ov, domains, apps, live, act] = await Promise.all([HD.api.overview(), HD.api.listDomains(), HD.api.listApps(), HD.api.trafficLive(), HD.api.listActivity(6)]);
    HD._dashDomains = domains;
    const u = ov.usage, quota = u.quota;
    const pct = quota ? Math.min(100, (u.used / quota) * 100) : null;
    const lim = (n, max) => (max ? `${n} / ${max}` : String(n));
    return `
    <div class="page-head">
      <div><h1 class="page-title">${greet()}, ${esc(HD.api.session().username)}</h1><p class="page-sub">Your domains, applications and usage</p></div>
      <div class="page-actions"><a class="btn" href="#/files">${icon('upload', 'i-sm')}Upload files</a><a class="btn btn-primary" href="#/apps/new">${icon('plus', 'i-sm')}Create application</a></div>
    </div>
    <section class="grid g-4">
      <div class="card stat">
        <div class="stat-top"><span class="stat-label">Storage</span><span class="stat-ic">${icon('hdd', 'i-sm')}</span></div>
        <div class="stat-value">${HD.fmtBytes(u.used)}${quota ? ` <small>/ ${HD.fmtBytes(quota)}</small>` : ''}</div>
        ${quota ? `<div class="meter ${meterCls(pct)}"><span style="width:${pct.toFixed(1)}%"></span></div>` : ''}
        <div class="stat-foot"><span>${quota ? `${Math.round(pct)}% used` : 'No limit'}</span><span>Files ${HD.fmtBytes(u.files)}</span></div>
      </div>
      <div class="card stat"><div class="stat-top"><span class="stat-label">Visitors today</span><span class="stat-ic">${icon('users2', 'i-sm')}</span></div><div class="stat-value">${HD.fmtNum(ov.today.uv)}</div><div class="stat-foot"><span>${HD.fmtNum(ov.today.pv)} page views</span></div></div>
      <div class="card stat"><div class="stat-top"><span class="stat-label">Bandwidth today</span><span class="stat-ic">${icon('network', 'i-sm')}</span></div><div class="stat-value">${HD.fmtBytes(ov.today.out)}</div><div class="stat-foot"><span>${HD.fmtNum(ov.today.req)} requests</span></div></div>
      <div class="card stat"><div class="stat-top"><span class="stat-label">Applications</span><span class="stat-ic">${icon('box', 'i-sm')}</span></div><div class="stat-value">${lim(ov.apps, u.limits.maxApps)}</div><div class="stat-foot"><span>${ov.running} running</span><span>${lim(ov.databases, u.limits.maxDatabases)} databases</span></div></div>
    </section>
    <div class="grid g-main mt">
      ${liveCard(live, domains)}
      <section class="card">
        <div class="card-head"><div class="card-title">My domains</div><a href="#/domains" class="link-btn" style="font-size:13px">Manage</a></div>
        <div class="card-body tight">${domains.map((d) => `
          <div class="list-row">
            <div class="row" style="gap:10px;min-width:0"><span class="d-ic sm">${icon(d.parentId ? 'layers' : 'globe', 'i-xs')}</span><div style="min-width:0"><a class="title truncate" style="display:block;color:var(--text)" href="#/domains/${encodeURIComponent(d.name)}">${esc(d.name)}</a><div class="sub">${d.size != null ? HD.fmtBytes(d.size) : '—'} · ${d.enabled ? 'On' : 'Off'}</div></div></div>
            <div style="text-align:end"><div style="font-weight:600">${HD.fmtNum(d.today?.uv || 0)}</div><div class="sub">visitors today</div></div>
          </div>`).join('') || '<div class="muted" style="padding:14px 0">No domains yet.</div>'}</div>
      </section>
    </div>
    <div class="grid g-2 mt">${appsCard(apps)}${activityCard(act)}</div>`;
  }

  HD.pages.dashboard = {
    title: 'Dashboard', nav: 'dashboard',
    async render() {
      if (!HD.isAdmin()) return renderAccount();
      const [srv, ov, services, apps, storage, act, m, live, domains] = await Promise.all([
        HD.api.server(), HD.api.overview(), HD.api.services(), HD.api.listApps(), HD.api.storage(), HD.api.listActivity(6), HD.lastMetrics ? Promise.resolve(HD.lastMetrics) : HD.api.metrics(), HD.api.trafficLive(), HD.api.listDomains(),
      ]);
      HD.lastMetrics = m; HD._dashDomains = domains;
      const memPct = (m.memUsed / m.memTotal) * 100, diskPct = (m.diskUsed / m.diskTotal) * 100;
      const store = storage.items || []; const totalStore = store.reduce((s, x) => s + x.size, 0) || 1;
      const palette = ['var(--accent)', '#0E9384', '#DC6803', '#7A5AF8', '#667085'];
      const down = services.filter((s) => s.status !== 'active');

      return `
      <div class="page-head">
        <div>
          <h1 class="page-title">${greet()}, ${esc(HD.api.session().username)}</h1>
          <p class="page-sub"><span translate="no">${esc(srv.hostname)} · ${esc(srv.os)}</span> · <span>up</span> ${HD.fmtUptime(srv.uptime)}</p>
        </div>
        <div class="page-actions">
          <a class="btn" href="#/domains?new=1">${icon('globe', 'i-sm')}Add domain</a>
          <a class="btn btn-primary" href="#/apps/new">${icon('plus', 'i-sm')}Create application</a>
        </div>
      </div>

      <section class="grid g-4" aria-label="Server resources">
        ${tile('cpu', 'CPU', 'cpu', `<span data-v="cpu">${Math.round(m.cpu)}</span><small>%</small>`, m.cpu, `<span data-v="load">Load ${m.load.join(' · ')}</span><span>${srv.threads} threads</span>`)}
        ${tile('mem', 'Memory', 'memory', `<span data-v="mem">${(m.memUsed / 1073741824).toFixed(1)}</span> <small>/ ${(m.memTotal / 1073741824).toFixed(0)} GB</small>`, memPct, `<span data-v="memPct">${Math.round(memPct)}% used</span>${m.swapTotal ? `<span>Swap ${HD.fmtBytes(m.swapUsed)}</span>` : ''}`)}
        ${tile('disk', 'Storage', 'disk', `${Math.round(m.diskUsed / 1e9)} <small>/ ${Math.round(m.diskTotal / 1e9)} GB</small>`, diskPct, `<span>${HD.fmtBytes(m.diskTotal - m.diskUsed)} free</span>`)}
        <div class="card stat">
          <div class="stat-top"><span class="stat-label">Network</span><span class="stat-ic">${icon('network', 'i-sm')}</span></div>
          <div class="stack-sm" style="gap:4px">
            <div class="row-between"><span class="muted">↓ In</span><b data-v="rx" style="font-variant-numeric:tabular-nums">${rate(m.rx)}</b></div>
            <div class="row-between"><span class="muted">↑ Out</span><b data-v="tx" style="font-variant-numeric:tabular-nums">${rate(m.tx)}</b></div>
          </div>
          <div class="stat-foot"><span translate="no">${esc((srv.ips[0] || {}).address || '')}</span><span class="row" style="gap:6px"><span class="status-dot on"></span>Online</span></div>
        </div>
      </section>

      <section class="grid g-4 mt" aria-label="Totals">
        ${count('#/domains', 'globe', 'Domains', ov.domains, `${ov.subdomains} subdomains`)}
        ${count('#/apps', 'box', 'Applications', ov.apps, `${ov.running} running`)}
        ${count('#/databases', 'database', 'Databases', ov.databases, 'all engines')}
        ${count('#/reports', 'users2', 'Visitors today', HD.fmtNum(ov.today.uv), HD.fmtBytes(ov.today.out))}
      </section>

      <div class="grid g-main mt">
        ${liveCard(live, domains)}
        ${todayCard(ov.today, 'All domains')}
      </div>

      <div class="grid g-main mt">
        <section class="card">
          <div class="card-head">
            <div><div class="card-title">CPU and memory</div><div class="card-sub">Percent of total</div></div>
            <div class="seg" role="group" aria-label="Range">
              <button data-range="hour" class="${range === 'hour' ? 'on' : ''}">1 hour</button>
              <button data-range="day" class="${range === 'day' ? 'on' : ''}">24 hours</button>
            </div>
          </div>
          <div class="card-body">
            <div class="chart-legend" style="margin-bottom:16px">
              <span><i style="background:var(--accent)"></i>CPU <b data-v="cpu2">${Math.round(m.cpu)}%</b></span>
              <span><i style="background:#DC6803"></i>Memory <b data-v="mem2">${Math.round(memPct)}%</b></span>
            </div>
            <div data-chart></div>
          </div>
        </section>

        <section class="card">
          <div class="card-head"><div class="card-title">Services</div>${down.length ? HD.badge(`${down.length} not running`, 'warn', true) : HD.badge('All running', 'success', true)}</div>
          <div class="card-body tight">
            ${services.map((s) => `
              <div class="list-row">
                <div class="row" style="gap:12px;min-width:0"><span class="svc-ic">${icon(svcIcon(s), 'i-sm')}</span>
                  <div style="min-width:0"><div class="title">${esc(s.name)}</div><div class="sub truncate">${esc(s.desc)}</div></div></div>
                <div class="row" style="gap:6px">
                  ${s.status === 'active' ? '<span class="status-dot on" title="Running"></span>' : HD.badge(s.status === 'inactive' ? 'Stopped' : s.status === 'failed' ? 'Failed' : s.status, s.status === 'failed' ? 'danger' : 'warn')}
                  ${s.status === 'active' && NO_RESTART.includes(s.id) ? '' : `<button class="icon-btn sm" data-svc="${esc(s.id)}" data-act="${s.status === 'active' ? 'restart' : 'start'}" aria-label="${s.status === 'active' ? 'Restart' : 'Start'} ${esc(s.name)}" title="${s.status === 'active' ? 'Restart' : 'Start'}">${icon(s.status === 'active' ? 'restart' : 'play', 'i-sm')}</button>`}
                </div>
              </div>`).join('')}
          </div>
          ${down.length ? `<div class="card-foot" style="justify-content:flex-start"><a class="link-btn" href="#/doctor">${icon('stethoscope', 'i-sm')}Find and fix problems</a></div>` : ''}
        </section>
      </div>

      <div class="grid g-3 mt">
        ${appsCard(apps)}
        <section class="card">
          <div class="card-head"><div><div class="card-title">Storage by domain</div><div class="card-sub">${storage.updatedAt ? `Updated ${HD.timeAgo(storage.updatedAt)}` : 'Calculating…'}</div></div></div>
          <div class="card-body stack">
            ${store.length ? `
              <div class="stackbar" role="img" aria-label="${esc(store.map((s) => s.name + ' ' + HD.fmtBytes(s.size)).join(', '))}">${store.map((s, i) => `<span style="width:${(s.size / totalStore) * 100}%;background:${palette[i % palette.length]}"></span>`).join('')}</div>
              ${store.slice(0, 6).map((s, i) => `<div class="hbar"><div class="top"><span class="row" style="gap:8px"><i style="width:8px;height:8px;border-radius:2px;background:${palette[i % palette.length]}"></i><span translate="no">${esc(s.name)}</span></span><b>${HD.fmtBytes(s.size)}</b></div><div class="meter"><span style="width:${(s.size / totalStore) * 100}%;background:${palette[i % palette.length]}"></span></div></div>`).join('')}`
              : `<div class="muted" style="font-size:13px">${storage.updatedAt ? 'No domains yet.' : 'Sizes appear in a minute.'}</div>`}
            <div class="divider"></div>
            <div class="row-between" style="font-size:13px"><span class="muted">Disk free</span><b>${HD.fmtBytes(m.diskTotal - m.diskUsed)}</b></div>
          </div>
        </section>
        ${activityCard(act)}
      </div>`;

      function tile(key, label, ic, value, pct, foot) {
        return `<div class="card stat">
          <div class="stat-top"><span class="stat-label">${label}</span><span class="stat-ic">${icon(ic, 'i-sm')}</span></div>
          <div class="stat-value">${value}</div>
          <div class="meter ${meterCls(pct)}" data-meter="${key}"><span style="width:${pct.toFixed(1)}%"></span></div>
          <div class="stat-foot">${foot}</div>
        </div>`;
      }
      function count(href, ic, label, value, sub) {
        return `<a class="card stat count-card" href="${href}">
          <span class="stat-ic" style="width:40px;height:40px;border-radius:10px">${icon(ic)}</span>
          <span style="display:flex;flex-direction:column;min-width:0"><span class="stat-label">${label}</span><span style="font-size:19px;font-weight:650;letter-spacing:-.01em">${esc(value)}</span></span>
          <span class="muted count-sub">${esc(sub)}</span>
        </a>`;
      }
    },

    mount(el) {
      startLive(el, () => HD._dashDomains || []);
      if (!HD.isAdmin()) { off = () => {}; return; }
      const draw = () => {
        const m = HD.lastMetrics; if (!m) return;
        const src = range === 'hour' ? m.hour : m.day;
        const box = el.querySelector('[data-chart]'); if (!box || !src || src.t.length < 2) return;
        HD.chart.line(box, {
          series: [{ name: HD.t('CPU'), color: getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#4F46E5', values: src.cpu, fill: true }, { name: HD.t('Memory'), color: '#DC6803', values: src.mem }],
          times: src.t, max: 100, height: 230, unit: '%',
          fmtX: (t) => HD.fmtTime(t).slice(0, 5),
          fmtTip: (t) => (range === 'hour' ? HD.fmtTime(t) : HD.fmtDateTime(t)),
        });
      };
      draw();
      el.addEventListener('click', async (e) => {
        const r = e.target.closest('[data-range]');
        if (r) { range = r.dataset.range; el.querySelectorAll('[data-range]').forEach((b) => b.classList.toggle('on', b === r)); draw(); }
        const s = e.target.closest('[data-svc]');
        if (s) {
          s.disabled = true; s.innerHTML = icon('refresh', 'i-sm');
          try { await HD.api.serviceAction(s.dataset.svc, s.dataset.act); HD.toast(HD.t('Done')); HD.rerender(); }
          catch (ex) { HD.toast(ex.message, 'error'); s.disabled = false; s.innerHTML = icon('restart', 'i-sm'); }
        }
      });
      let n = 0;
      const offM = HD.on('metrics', async (m) => {
        const set = (k, v) => { const x = el.querySelector(`[data-v="${k}"]`); if (x) x.textContent = v; };
        const memPct = Math.round((m.memUsed / m.memTotal) * 100);
        set('cpu', Math.round(m.cpu)); set('mem', (m.memUsed / 1073741824).toFixed(1)); set('memPct', HD.t('{n}% used', { n: memPct })); set('rx', rate(m.rx)); set('tx', rate(m.tx));
        set('load', HD.t('Load') + ' ' + m.load.join(' · ')); set('cpu2', Math.round(m.cpu) + '%'); set('mem2', memPct + '%');
        const mt = (k, p) => { const x = el.querySelector(`[data-meter="${k}"]`); if (x) { x.className = 'meter ' + meterCls(p); x.firstElementChild.style.width = p + '%'; } };
        mt('cpu', m.cpu); mt('mem', memPct);
        if (range === 'hour') draw();
        if (++n % 2 === 0) {
          const apps = await HD.api.listApps().catch(() => []);
          apps.forEach((a) => { const x = el.querySelector(`[data-appres="${a.id}"]`); if (x) x.textContent = resText(a); });
        }
      });
      const offT = HD.on('theme', draw);
      off = () => { offM(); offT(); };
    },
    unmount() { off && off(); off = null; clearInterval(liveTimer); liveTimer = null; },
  };

  function resText(a) {
    if (a.live.state !== 'running') return HD.t(a.live.state === 'error' ? 'Crashed' : a.live.state === 'starting' ? 'Starting…' : 'Stopped');
    if (a.runtime === 'php') return 'PHP-FPM';
    return HD.ltr([a.live.cpu != null ? a.live.cpu + '%' : null, a.live.mem != null ? a.live.mem + ' MB' : null].filter(Boolean).join(' · ')) || HD.t('Running');
  }
  HD.appResText = resText;
})();
