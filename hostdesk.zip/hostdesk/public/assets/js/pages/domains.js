/* Domains — list (expandable), detail, add and delete dialogs */
(function () {
  const HD = window.HD; const { esc, icon } = HD;
  const OPEN_KEY = 'hd_open_domains';
  const openSet = () => { try { return new Set(JSON.parse(localStorage.getItem(OPEN_KEY) || '[]')); } catch { return new Set(); } };
  const saveOpen = (s) => { try { localStorage.setItem(OPEN_KEY, JSON.stringify([...s])); } catch {} };

  const appBadge = (d) => d.app ? HD.runtimeBadge(d.app.runtime, d.app.version) : HD.badge('Static', 'outline');
  const stateBadge = (d) => !d.enabled ? HD.badge('Off', '', true) : d.app && d.app.status === 'stopped' ? HD.badge('Stopped', 'warn', true) : HD.badge('Active', 'success', true);

  /* ---------- Add domain ---------- */
  HD.openAddDomain = async (opts = {}) => {
    const all = await HD.api.listDomains();
    const roots = all.filter((d) => !d.parentId);
    let type = opts.parentId ? 'sub' : opts.type || (roots.length ? 'sub' : 'main');
    if (!roots.length) type = 'main';
    HD.modal({
      title: 'Add domain', desc: 'Each domain and subdomain gets its own folder and Linux user. Files and an application can be added after.', size: 'lg',
      body: `
        <form class="stack" novalidate>
          <div class="choice-grid" role="radiogroup" aria-label="Type">
            <button type="button" class="choice" data-type="main" role="radio"><span class="choice-ic" style="background:var(--accent-soft);color:var(--accent-text)">${icon('globe')}</span><span><span class="ttl">Main domain</span><br><span class="dsc">For example takal.net</span></span></button>
            <button type="button" class="choice" data-type="sub" role="radio" ${roots.length ? '' : 'disabled'}><span class="choice-ic" style="background:var(--surface-3);color:var(--text-2)">${icon('layers')}</span><span><span class="ttl">Subdomain</span><br><span class="dsc">${roots.length ? 'For example host.takal.net' : 'Add a main domain first'}</span></span></button>
          </div>
          <div class="field" data-main><label for="dn">Domain name</label><input id="dn" class="input" name="name" placeholder="takal.net" autocomplete="off" spellcheck="false" autocapitalize="off"><span class="hint">www.<i>domain</i> is included automatically.</span></div>
          <div class="field" data-sub>
            <label for="sp">Subdomain</label>
            <div class="input-group">
              <input id="sp" class="input" name="prefix" placeholder="host" autocomplete="off" spellcheck="false" autocapitalize="off" style="flex:1">
              <span class="addon" style="border-radius:0;border-left:none;border-right:none">.</span>
              <select class="select" name="parentId" style="border-radius:0 8px 8px 0;width:auto;min-width:180px">${roots.map((r) => `<option value="${r.id}" ${r.id === opts.parentId ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}</select>
            </div>
          </div>
          <div class="field"><label>Folder</label><div class="copy-row">${icon('folder', 'i-sm fic-dir')}<code data-folder>…</code></div><span class="hint">Created automatically. Upload your project files here.</span></div>
          <hr class="divider">
          <label class="check"><input type="checkbox" name="withAccount"><span><span class="t">Create a separate account for this domain</span><br><span class="d">Optional. This account can sign in and manage only this domain.</span></span></label>
          <div class="form-grid" data-account hidden>
            <div class="field"><label for="au">Username</label><input id="au" class="input" name="account" autocomplete="off" spellcheck="false"></div>
            <div class="field"><label for="ap">Password</label><div class="input-group"><input id="ap" class="input" name="password" type="text" autocomplete="new-password"><button type="button" class="btn addon" data-gen style="height:40px;box-shadow:none">${icon('wand', 'i-sm')}New</button></div></div>
          </div>
        </form>`,
      foot: `<button class="btn" data-close>Cancel</button><button class="btn btn-primary" data-submit>${icon('plus', 'i-sm')}Create domain</button>`,
      onMount(el, m) {
        const f = el.querySelector('form');
        const fullName = () => { const d = HD.formData(f); if (type === 'main') return d.name.toLowerCase(); const p = roots.find((r) => r.id === d.parentId); return d.prefix ? `${d.prefix.toLowerCase()}.${p?.name}` : ''; };
        const preview = () => {
          const d = HD.formData(f); const base = (roots[0]?.folder || '/var/www/x/www').split('/').slice(0, -2).join('/') || '/var/www';
          el.querySelector('[data-folder]').textContent = type === 'main' ? `${base}/${d.name.toLowerCase() || '…'}/www` : `${base}/${roots.find((r) => r.id === d.parentId)?.name}/${(d.prefix || '…').toLowerCase().replace(/\./g, '-')}`;
        };
        const setType = (t) => {
          type = t;
          el.querySelectorAll('[data-type]').forEach((b) => { b.classList.toggle('on', b.dataset.type === t); b.setAttribute('aria-checked', b.dataset.type === t); });
          el.querySelector('[data-main]').hidden = t !== 'main'; el.querySelector('[data-sub]').hidden = t !== 'sub';
          preview(); setTimeout(() => el.querySelector(t === 'main' ? '#dn' : '#sp').focus(), 10);
        };
        el.querySelectorAll('[data-type]').forEach((b) => b.addEventListener('click', () => !b.disabled && setType(b.dataset.type)));
        f.addEventListener('input', preview);
        const gen = () => { f.querySelector('[name=password]').value = Array.from(crypto.getRandomValues(new Uint8Array(14))).map((b) => 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 56]).join(''); };
        const acc = f.querySelector('[name=withAccount]');
        acc.addEventListener('change', () => {
          el.querySelector('[data-account]').hidden = !acc.checked;
          if (acc.checked) { const n = fullName().split('.')[0]; const u = f.querySelector('[name=account]'); if (!u.value && n) u.value = n.replace(/[^a-z0-9]/g, '') + '_user'; if (!f.querySelector('[name=password]').value) gen(); }
        });
        el.querySelector('[data-gen]').addEventListener('click', gen);
        const submit = async () => {
          const d = HD.formData(f); const name = fullName();
          if (!name) return HD.fieldError(f, type === 'main' ? 'name' : 'prefix', 'Enter a name');
          const btn = el.querySelector('[data-submit]'); btn.disabled = true; btn.textContent = 'Creating…';
          try {
            const res = await HD.api.createDomain({ name, parentId: type === 'sub' ? d.parentId : null, account: d.withAccount ? d.account : null, password: d.withAccount ? d.password : null });
            m.close(); HD.toast(`${res.name} created`); HD.refreshCounts();
            if (res.parentId) { const s = openSet(); s.add(res.parentId); saveOpen(s); }
            HD.go('/domains/' + encodeURIComponent(res.name));
          } catch (ex) { btn.disabled = false; btn.innerHTML = icon('plus', 'i-sm') + 'Create domain'; HD.fieldError(f, /username|password|account/i.test(ex.message) ? (/password/i.test(ex.message) ? 'password' : 'account') : type === 'main' ? 'name' : 'prefix', ex.message); }
        };
        el.querySelector('[data-submit]').addEventListener('click', submit);
        f.addEventListener('submit', (e) => { e.preventDefault(); submit(); });
        f.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.tagName === 'INPUT') { e.preventDefault(); submit(); } });
        setType(type);
      },
    });
  };

  /* ---------- Delete domain ---------- */
  HD.deleteDomainDialog = (d, all) => new Promise((resolve) => {
    const subs = all.filter((x) => x.parentId === d.id);
    const dbCount = d.dbCount + subs.reduce((s, x) => s + x.dbCount, 0);
    let done = false;
    HD.modal({
      title: `Delete ${d.name}?`, size: 'lg',
      body: `<div class="stack">
        <div class="callout warn">${icon('alert', 'i-sm')}<div>This removes ${d.parentId ? 'the subdomain' : 'the domain'}${subs.length ? `, its <b>${subs.length} subdomain${subs.length > 1 ? 's' : ''}</b> (${subs.map((s) => esc(s.name)).join(', ')})` : ''}${d.app || subs.some((s) => s.app) ? ', its applications' : ''} and its web server settings.</div></div>
        <label class="check"><input type="checkbox" name="files"><span><span class="t">Also delete the files</span><br><span class="d mono">${esc(d.folder)}${subs.length ? ' and subdomain folders' : ''}</span></span></label>
        <label class="check"><input type="checkbox" name="dbs" ${dbCount ? '' : 'disabled'}><span><span class="t">Also delete the databases</span><br><span class="d">${dbCount ? `${dbCount} database${dbCount > 1 ? 's' : ''} belong to it` : 'No databases'}</span></span></label>
        <div class="field"><label for="cf">Type <b class="mono">${esc(d.name)}</b> to confirm</label><input id="cf" class="input" autocomplete="off" spellcheck="false" autocapitalize="off"></div>
      </div>`,
      foot: `<button class="btn" data-close>Cancel</button><button class="btn btn-danger" data-ok disabled>${icon('trash', 'i-sm')}Delete</button>`,
      onClose: () => !done && resolve(false),
      onMount(el, m) {
        const inp = el.querySelector('#cf'), ok = el.querySelector('[data-ok]');
        inp.addEventListener('input', () => { ok.disabled = inp.value.trim().toLowerCase() !== d.name; });
        ok.addEventListener('click', async () => {
          ok.disabled = true; ok.textContent = 'Deleting…';
          try {
            await HD.api.deleteDomain(d.id, { deleteFiles: el.querySelector('[name=files]').checked, deleteDatabases: el.querySelector('[name=dbs]').checked });
            done = true; m.close(); HD.toast(`${d.name} deleted`); HD.refreshCounts(); resolve(true);
          } catch (ex) { HD.toast(ex.message, 'error'); ok.disabled = false; ok.innerHTML = icon('trash', 'i-sm') + 'Delete'; }
        });
      },
    });
  });

  /* ---------- List ---------- */
  let filter = '';
  const row = (d, isSub, admin) => `
    <div class="drow ${isSub ? 'sub' : 'root'} ${d.enabled ? '' : 'disabled'}">
      <div class="dname">
        ${isSub ? `<svg class="tree-line" viewBox="0 0 18 22" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3 0v11a4 4 0 0 0 4 4h11"/></svg>` : ''}
        <div style="min-width:0"><a href="#/domains/${encodeURIComponent(d.name)}" class="truncate" style="display:block">${esc(d.name)}</a><span class="path">${esc(d.folder.split('/').slice(-2).join('/'))}</span></div>
      </div>
      <div class="dmeta rt"><div class="row">${appBadge(d)}${stateBadge(d)}</div>${d.app ? `<a href="#/apps/${d.app.id}" class="truncate" style="font-size:12.5px">${esc(d.app.name)}</a>` : `<a href="#/apps/new?domain=${d.id}" style="font-size:12.5px">Create application</a>`}</div>
      <div class="dmeta"><span class="row">${icon('route', 'i-xs')}<span class="mono truncate" style="color:var(--text-2)">${esc(d.route.service.replace('http://', ''))}</span></span></div>
      <div class="dmeta acc"><span class="row">${icon('database', 'i-xs')}${d.dbCount} database${d.dbCount === 1 ? '' : 's'}</span><span class="row">${icon('user', 'i-xs')}${d.accountName ? esc(d.accountName) : 'Admin only'}</span></div>
      <div class="dactions">
        <a class="icon-btn sm" href="#/files?path=${encodeURIComponent(d.folder)}" title="Files" aria-label="Files of ${esc(d.name)}">${icon('folder', 'i-sm')}</a>
        <a class="icon-btn sm" href="https://${esc(d.name)}" target="_blank" rel="noopener" title="Open site" aria-label="Open ${esc(d.name)}">${icon('external', 'i-sm')}</a>
        ${admin ? `<button class="icon-btn sm danger" data-del="${d.id}" title="Delete" aria-label="Delete ${esc(d.name)}">${icon('trash', 'i-sm')}</button>` : ''}
        <span style="width:6px"></span>${HD.switchBtn(d.enabled, `data-toggle="${d.id}" aria-label="${d.enabled ? 'Turn off' : 'Turn on'} ${esc(d.name)}" title="${d.enabled ? 'On' : 'Off'}"`)}
      </div>
    </div>`;

  HD.pages.domains = {
    title: 'Domains', nav: 'domains',
    async render() {
      const all = await HD.api.listDomains();
      const admin = HD.isAdmin();
      const roots = all.filter((d) => !d.parentId || !all.some((r) => r.id === d.parentId));
      const subsOf = (id) => all.filter((d) => d.parentId === id);
      const q = filter.toLowerCase();
      const shown = roots.filter((r) => !q || r.name.includes(q) || subsOf(r.id).some((s) => s.name.includes(q)));
      const opened = openSet();
      return `
      <div class="page-head">
        <div><h1 class="page-title">Domains</h1><p class="page-sub">${roots.length} domain${roots.length === 1 ? '' : 's'} · ${all.length - roots.length} subdomain${all.length - roots.length === 1 ? '' : 's'}</p></div>
        <div class="page-actions">
          <div class="input-icon" style="width:240px;max-width:100%">${icon('search', 'i-sm')}<input class="input" type="search" placeholder="Filter domains" value="${esc(filter)}" data-filter aria-label="Filter domains"></div>
          ${roots.length > 1 ? `<button class="btn" data-expand>${icon('chevDown', 'i-sm')}${roots.every((r) => opened.has(r.id)) ? 'Collapse all' : 'Expand all'}</button>` : ''}
          ${admin ? `<button class="btn btn-primary" data-add>${icon('plus', 'i-sm')}Add domain</button>` : ''}
        </div>
      </div>
      <div class="stack">
        ${shown.length ? shown.map((r) => {
          const subs = subsOf(r.id);
          const isOpen = !!q || opened.has(r.id);
          return `<section class="card dgroup ${isOpen ? 'open' : ''}" data-group="${r.id}">
            <div class="acc-head">
              <button class="acc-toggle" data-open="${r.id}" aria-expanded="${isOpen}" aria-label="${isOpen ? 'Hide' : 'Show'} subdomains of ${esc(r.name)}">
                ${icon('chevRight', 'i-sm chev')}<span class="d-ic">${icon('globe', 'i-sm')}</span>
                <span class="acc-title"><b>${esc(r.name)}</b><span>${subs.length} subdomain${subs.length === 1 ? '' : 's'}</span></span>
              </button>
              <div class="acc-meta">${appBadge(r)}${stateBadge(r)}<span class="mono muted nowrap" style="font-size:12.5px">${esc(r.route.service.replace('http://', ''))}</span></div>
              <div class="dactions">
                <a class="btn btn-sm" href="#/domains/${encodeURIComponent(r.name)}">Manage</a>
                <a class="icon-btn sm" href="#/files?path=${encodeURIComponent(r.folder)}" title="Files" aria-label="Files of ${esc(r.name)}">${icon('folder', 'i-sm')}</a>
                ${admin ? `<button class="icon-btn sm danger" data-del="${r.id}" title="Delete" aria-label="Delete ${esc(r.name)}">${icon('trash', 'i-sm')}</button>` : ''}
                <span style="width:6px"></span>${HD.switchBtn(r.enabled, `data-toggle="${r.id}" aria-label="${r.enabled ? 'Turn off' : 'Turn on'} ${esc(r.name)}"`)}
              </div>
            </div>
            <div class="acc-body" ${isOpen ? '' : 'hidden'}>
              ${subs.length ? subs.filter((s) => !q || s.name.includes(q) || r.name.includes(q)).map((s) => row(s, true, admin)).join('') : '<div class="muted" style="padding:14px 20px 4px 64px;font-size:13px">No subdomains yet.</div>'}
              ${admin ? `<div class="dadd"><button class="link-btn" data-addsub="${r.id}">${icon('plus', 'i-sm')}Add subdomain to ${esc(r.name)}</button></div>` : ''}
            </div>
          </section>`;
        }).join('') : `<div class="card">${q ? HD.empty('search', 'No matches', `No domain matches “${filter}”.`) : HD.empty('globe', 'No domains yet', 'Add your first domain to start hosting.', admin ? `<button class="btn btn-primary" data-add>${icon('plus', 'i-sm')}Add domain</button>` : '')}</div>`}
      </div>`;
    },
    mount(el, ctx) {
      if (ctx.query.new) { history.replaceState(null, '', '#/domains'); HD.openAddDomain(); }
      const inp = el.querySelector('[data-filter]');
      inp?.addEventListener('input', HD.debounce(async () => { filter = inp.value.trim(); const pos = inp.selectionStart; await HD.rerender(); const n = document.querySelector('[data-filter]'); n?.focus(); n?.setSelectionRange(pos, pos); }, 180));
      el.addEventListener('click', async (e) => {
        const t = e.target;
        const op = t.closest('[data-open]');
        if (op) {
          const id = op.dataset.open, s = openSet(), g = el.querySelector(`[data-group="${id}"]`), body = g.querySelector('.acc-body');
          const nowOpen = body.hidden; body.hidden = !nowOpen; g.classList.toggle('open', nowOpen); op.setAttribute('aria-expanded', nowOpen);
          nowOpen ? s.add(id) : s.delete(id); saveOpen(s); return;
        }
        if (t.closest('[data-expand]')) {
          const all = (await HD.api.listDomains()).filter((d) => !d.parentId).map((d) => d.id); const s = openSet();
          const allOpen = all.every((id) => s.has(id)); saveOpen(allOpen ? new Set() : new Set(all)); return HD.rerender();
        }
        if (t.closest('[data-add]')) return HD.openAddDomain();
        const sub = t.closest('[data-addsub]'); if (sub) return HD.openAddDomain({ parentId: sub.dataset.addsub, type: 'sub' });
        const tg = t.closest('[data-toggle]');
        if (tg) {
          const on = tg.getAttribute('aria-checked') !== 'true'; tg.disabled = true;
          try { const d = await HD.api.updateDomain(tg.dataset.toggle, { enabled: on }); HD.toast(`${d.name} turned ${on ? 'on' : 'off'}`, on ? 'success' : 'info'); }
          catch (ex) { HD.toast(ex.message, 'error'); }
          return HD.rerender();
        }
        const del = t.closest('[data-del]');
        if (del) { const all = await HD.api.listDomains(); const d = all.find((x) => x.id === del.dataset.del); if (d && (await HD.deleteDomainDialog(d, all))) HD.rerender(); }
      });
    },
  };

  /* ---------- Detail ---------- */
  HD.pages.domain = {
    title: (ctx) => ctx.params.name, nav: 'domains',
    async render(ctx) {
      const { domain: d, all } = await HD.api.getDomainByName(ctx.params.name);
      const tab = ctx.params.tab || 'overview';
      const admin = HD.isAdmin();
      const [dbs, listing, app, accounts] = await Promise.all([
        HD.api.listDatabases().catch(() => []), HD.api.listDir(d.folder).catch(() => ({ items: [] })),
        d.app ? HD.api.getApp(d.app.id).catch(() => null) : null, admin ? HD.api.listAccounts().catch(() => []) : [],
      ]);
      const files = listing.items || [];
      const parent = all.find((x) => x.id === d.parentId);
      const subs = all.filter((x) => x.parentId === d.id);
      const myDbs = dbs.filter((x) => x.domainId === d.id);
      const base = '#/domains/' + encodeURIComponent(d.name);
      const T = (k, label, count) => `<a href="${base}${k === 'overview' ? '' : '/' + k}" class="${tab === k ? 'on' : ''}">${label}${count != null ? `<span class="count">${count}</span>` : ''}</a>`;
      const st = app?.live.state;

      const appCard = app ? `
        <section class="card">
          <div class="card-head">
            <div class="row wrap" style="gap:10px"><span class="card-title">${esc(app.name)}</span>${HD.runtimeBadge(app.runtime, app.version)}${HD.statusBadge(st === 'running' ? 'running' : st === 'error' ? 'error' : 'stopped')}</div>
            <div class="row">${st === 'running' ? `<button class="btn btn-sm" data-app="restart">${icon('restart', 'i-sm')}Restart</button><button class="btn btn-sm" data-app="stop">${icon('stop', 'i-sm')}Stop</button>` : `<button class="btn btn-sm btn-primary" data-app="start">${icon('play', 'i-sm')}Start</button>`}</div>
          </div>
          <div class="card-body"><dl class="kv">
            <div><dt>Port</dt><dd class="mono">${app.runtime === 'node' ? app.port : '80 (Nginx)'}</dd></div>
            <div><dt>${app.runtime === 'node' ? (app.startMode === 'npm' ? 'npm script' : 'Start file') : 'Public folder'}</dt><dd class="mono">${esc(app.runtime === 'node' ? app.startFile : app.publicDir)}</dd></div>
            <div><dt>Running since</dt><dd>${app.live.since ? HD.timeAgo(app.live.since) : '—'}</dd></div>
            <div><dt>${app.runtime === 'node' ? 'CPU · Memory' : 'Served by'}</dt><dd>${HD.appResText(app)}</dd></div>
          </dl></div>
          <div class="card-foot" style="justify-content:space-between"><span class="muted" style="font-size:13px">Created ${HD.fmtDate(app.createdAt)}</span><a class="btn btn-sm" href="#/apps/${app.id}">Open application ${icon('chevRight', 'i-sm')}</a></div>
        </section>` : `
        <section class="card">
          <div class="card-head"><div class="card-title">Application</div>${HD.badge('Static files', 'outline')}</div>
          <div class="card-body">
            <p class="muted" style="margin:0 0 16px;font-size:13.5px">Right now Nginx serves the files in this folder as a static site. For Node.js or PHP, create an application:</p>
            <ol style="margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:14px">
              <li class="row" style="gap:14px;align-items:flex-start"><span class="avatar" style="background:var(--surface-3);color:var(--text-2)">1</span><div class="grow"><div style="font-weight:600">Upload your project files</div><div class="muted mono" style="font-size:12.5px">${esc(d.folder)}</div></div><a class="btn btn-sm" href="#/files?path=${encodeURIComponent(d.folder)}">${icon('upload', 'i-sm')}Upload</a></li>
              <li class="row" style="gap:14px;align-items:flex-start"><span class="avatar">2</span><div class="grow"><div style="font-weight:600">Create the application</div><div class="muted" style="font-size:13px">Pick the folder and Node.js or PHP. It starts right away.</div></div><a class="btn btn-sm btn-primary" href="#/apps/new?domain=${d.id}">${icon('plus', 'i-sm')}Create</a></li>
            </ol>
          </div>
        </section>`;

      const routeCard = `
        <section class="card">
          <div class="card-head"><div class="card-title">Route</div>${d.enabled ? HD.badge('On', 'success', true) : HD.badge('Off', '', true)}</div>
          <div class="card-body">
            <div class="flow">
              <div class="flow-node"><span class="k">Public address</span><span class="v">https://${esc(d.name)}</span>${d.route.aliases.length ? `<span class="k">also ${d.route.aliases.map(esc).join(', ')}</span>` : ''}</div>
              <div class="flow-arrow">${icon('chevDown', 'i-sm')}</div>
              <div class="flow-node"><span class="k">Cloudflare Tunnel</span><span class="v" style="font-family:var(--font);font-weight:500">HTTPS handled by Cloudflare</span></div>
              <div class="flow-arrow">${icon('chevDown', 'i-sm')}</div>
              <div class="flow-node target"><span class="k">Service on this server</span><span class="v">${esc(d.route.service)}</span></div>
            </div>
            <button class="btn btn-sm btn-block mt" data-copy="${esc(d.route.service)}">${icon('copy', 'i-sm')}Copy service URL</button>
          </div>
        </section>`;

      const detailsCard = `
        <section class="card">
          <div class="card-head"><div class="card-title">Details</div></div>
          <div class="card-body tight">
            <div class="list-row"><span class="muted">Folder</span><span class="row" style="min-width:0"><span class="mono truncate">${esc(d.folder)}</span><button class="icon-btn sm" data-copy="${esc(d.folder)}" aria-label="Copy folder path">${icon('copy', 'i-xs')}</button></span></div>
            <div class="list-row"><span class="muted">Linux user</span><span class="mono">${esc(d.siteUser)}</span></div>
            <div class="list-row"><span class="muted">Created</span><span>${HD.fmtDate(d.createdAt)}</span></div>
            <div class="list-row"><span class="muted">Account</span><span>${d.accountName ? esc(d.accountName) : 'Admin only'}</span></div>
            ${!d.parentId ? `<div class="list-row"><span class="muted">Subdomains</span><span style="text-align:right">${subs.length ? subs.map((s) => `<a href="#/domains/${encodeURIComponent(s.name)}" style="display:block">${esc(s.name)}</a>`).join('') : '—'}</span></div>` : ''}
          </div>
        </section>`;

      const filesCard = (limit) => `
        <section class="card">
          <div class="card-head"><div><div class="card-title">Files</div><div class="card-sub mono">${esc(d.folder)}</div></div><a class="btn btn-sm" href="#/files?path=${encodeURIComponent(d.folder)}">${icon('folder', 'i-sm')}File manager</a></div>
          ${files.length ? `<div class="table-wrap"><table class="table compact"><thead><tr><th>Name</th><th>Size</th><th>Modified</th></tr></thead><tbody>
            ${files.slice(0, limit).map((f) => `<tr><td><a class="fname" href="#/files?path=${encodeURIComponent(f.type === 'dir' ? f.path : d.folder)}">${icon(f.type === 'dir' ? 'folder' : 'file', 'i-sm ' + (f.type === 'dir' ? 'fic-dir' : 'fic-file'))}${esc(f.name)}</a></td><td class="muted nowrap">${f.type === 'dir' ? '—' : HD.fmtBytes(f.size)}</td><td class="muted nowrap">${HD.timeAgo(f.mtime)}</td></tr>`).join('')}
          </tbody></table></div>${files.length > limit ? `<div class="card-foot" style="justify-content:flex-start"><span class="muted" style="font-size:13px">${files.length - limit} more items</span></div>` : ''}` : HD.empty('folder', 'Folder is empty', 'Upload your project files to get started.')}
        </section>`;

      const dbCard = `
        <section class="card">
          <div class="card-head"><div class="card-title">Databases</div><button class="btn btn-sm" data-newdb>${icon('plus', 'i-sm')}New</button></div>
          ${myDbs.length ? `<div class="card-body tight">${myDbs.map((x) => `
            <div class="list-row"><div class="row" style="gap:12px;min-width:0"><span class="svc-ic">${icon('database', 'i-sm')}</span><div style="min-width:0"><a class="title" style="color:var(--text)" href="#/databases/${x.id}">${esc(x.name)}</a><div class="sub">${HD.engineLabel(x.engine)}${x.user ? ' · user ' + esc(x.user) : ''}</div></div></div><span class="muted nowrap" style="font-size:13px">${x.size != null ? HD.fmtBytes(x.size) : '—'}</span></div>`).join('')}</div>`
            : HD.empty('database', 'No databases', 'Create one here. SQLite files in this folder are found automatically.')}
        </section>`;

      let body = '';
      if (tab === 'overview') body = `<div class="grid g-main"><div class="stack">${appCard}${filesCard(6)}</div><div class="stack">${routeCard}${dbCard}${detailsCard}</div></div>`;
      if (tab === 'files') body = filesCard(200);
      if (tab === 'databases') body = dbCard;
      if (tab === 'settings') body = `
        <div class="card">
          ${admin ? `<section class="settings-sec">
            <div><h2>Account</h2><p>The account that may sign in and manage this ${d.parentId ? 'subdomain' : 'domain and its subdomains'}.</p></div>
            <div class="field"><label for="acc">Account</label><select id="acc" class="select" data-acc>
              <option value="">Admin only</option>
              ${accounts.filter((u) => u.role === 'domain').map((u) => `<option value="${u.id}" ${u.id === d.accountId ? 'selected' : ''}>${esc(u.username)}</option>`).join('')}
            </select><span class="hint">Create accounts on the <a href="#/accounts">Accounts</a> page.</span></div>
          </section>` : ''}
          <section class="settings-sec">
            <div><h2>Status</h2><p>When off, visitors see a “Site unavailable” page and a Node.js app is stopped. Files and databases are kept.</p></div>
            <div class="row-between"><div><div style="font-weight:500">${d.enabled ? 'On' : 'Off'}</div><div class="hint">${d.enabled ? 'Visitors can open this site.' : 'Visitors get an error page.'}</div></div>${HD.switchBtn(d.enabled, 'data-enable aria-label="Domain on or off"')}</div>
          </section>
          ${admin ? `<section class="settings-sec">
            <div><h2 style="color:var(--danger)">Delete</h2><p>Remove this ${d.parentId ? 'subdomain' : 'domain'}${subs.length ? ' and its subdomains' : ''}. You choose whether files and databases are deleted too.</p></div>
            <div><button class="btn btn-danger" data-delete>${icon('trash', 'i-sm')}Delete ${esc(d.name)}</button></div>
          </section>` : ''}
        </div>`;

      return `
      <nav class="crumbs" aria-label="Breadcrumb"><a href="#/domains">Domains</a>${parent ? `<span class="sep">/</span><a href="#/domains/${encodeURIComponent(parent.name)}">${esc(parent.name)}</a>` : ''}<span class="sep">/</span><span style="color:var(--text)">${esc(d.name)}</span></nav>
      <div class="page-head">
        <div class="row" style="gap:14px;align-items:center">
          <span class="d-ic" style="width:48px;height:48px;border-radius:12px">${icon(d.parentId ? 'layers' : 'globe', 'i-lg')}</span>
          <div><div class="row wrap" style="gap:10px"><h1 class="page-title">${esc(d.name)}</h1>${stateBadge(d)}</div>
          <p class="page-sub" style="margin-top:2px">${parent ? `Subdomain of ${esc(parent.name)}` : 'Main domain'} · created ${HD.fmtDate(d.createdAt)}</p></div>
        </div>
        <div class="page-actions">
          ${admin && !d.parentId ? `<button class="btn" data-addsub>${icon('plus', 'i-sm')}Add subdomain</button>` : ''}
          <a class="btn" href="https://${esc(d.name)}" target="_blank" rel="noopener">Open site ${icon('external', 'i-sm')}</a>
        </div>
      </div>
      <nav class="tabs" aria-label="Domain sections">${T('overview', 'Overview')}${T('files', 'Files', files.length)}${T('databases', 'Databases', myDbs.length)}${T('settings', 'Settings')}</nav>
      ${body}`;
    },
    mount(el, ctx) {
      const load = async () => (await HD.api.getDomainByName(ctx.params.name));
      el.addEventListener('click', async (e) => {
        const t = e.target;
        const c = t.closest('[data-copy]'); if (c) return HD.copy(c.dataset.copy);
        const { domain: d, all } = await load();
        if (t.closest('[data-addsub]')) HD.openAddDomain({ parentId: d.id, type: 'sub' });
        if (t.closest('[data-newdb]')) HD.openNewDatabase(d.id);
        const a = t.closest('[data-app]');
        if (a) { a.disabled = true; try { await HD.api.appAction(d.app.id, a.dataset.app); HD.toast(`${d.app.name} ${{ start: 'started', stop: 'stopped', restart: 'restarted' }[a.dataset.app]}`); } catch (ex) { HD.toast(ex.message, 'error'); } HD.rerender(); }
        if (t.closest('[data-enable]')) { try { await HD.api.updateDomain(d.id, { enabled: !d.enabled }); HD.toast(`${d.name} turned ${d.enabled ? 'off' : 'on'}`, 'info'); } catch (ex) { HD.toast(ex.message, 'error'); } HD.rerender(); }
        if (t.closest('[data-delete]') && (await HD.deleteDomainDialog(d, all))) HD.go('/domains');
      });
      el.querySelector('[data-acc]')?.addEventListener('change', async (e) => {
        const { domain: d } = await load();
        try { await HD.api.updateDomain(d.id, { accountId: e.target.value || null }); HD.toast('Account updated'); } catch (ex) { HD.toast(ex.message, 'error'); }
        HD.rerender();
      });
    },
  };
})();
