/* Reports — bandwidth and visitors per domain, for any date range */
(function () {
  const HD = window.HD; const { esc, icon } = HD;
  let metric = 'out', sortBy = 'out';
  const day = (offset) => { const d = new Date(); d.setDate(d.getDate() + offset); return HD.isoDate(d); };
  const PRESETS = {
    today: () => [day(0), day(0)],
    yesterday: () => [day(-1), day(-1)],
    d7: () => [day(-6), day(0)],
    d30: () => [day(-29), day(0)],
    month: () => { const d = new Date(); return [HD.isoDate(new Date(d.getFullYear(), d.getMonth(), 1)), day(0)]; },
    lastMonth: () => { const d = new Date(); return [HD.isoDate(new Date(d.getFullYear(), d.getMonth() - 1, 1)), HD.isoDate(new Date(d.getFullYear(), d.getMonth(), 0))]; },
  };
  const PRESET_LABEL = { today: 'Today', yesterday: 'Yesterday', d7: 'Last 7 days', d30: 'Last 30 days', month: 'This month', lastMonth: 'Last month' };
  const METRICS = { out: ['Bandwidth', (v) => HD.fmtBytes(v), true], uv: ['Visitors', (v) => HD.fmtNum(v), false], pv: ['Page views', (v) => HD.fmtNum(v), false], req: ['Requests', (v) => HD.fmtNum(v), false] };
  const shortDate = (iso) => HD.fmtDay(iso + 'T12:00:00');

  function presetOf(from, to) { return Object.keys(PRESETS).find((k) => { const [a, b] = PRESETS[k](); return a === from && b === to; }) || 'custom'; }

  HD.pages.reports = {
    title: 'Reports', nav: 'reports',
    async render(ctx) {
      const q = ctx.query;
      const [from, to] = q.from && q.to ? [q.from, q.to] : PRESETS.d7();
      const domain = q.domain || '';
      const [r, domains] = await Promise.all([HD.api.trafficReport(from, to, domain), HD.api.listDomains()]);
      const preset = presetOf(r.from, r.to);
      const nDays = r.days.length;
      const t = r.total;
      const errors = (x) => x.s4 + x.s5;
      const sorted = r.domains.slice().sort((a, b) => b[sortBy] - a[sortBy]);
      const maxShare = Math.max(1, ...sorted.map((d) => d[sortBy]));
      const opts = domains.filter((d) => !d.parentId).flatMap((root) => [root, ...domains.filter((d) => d.parentId === root.id)]).concat(domains.filter((d) => d.parentId && !domains.some((x) => x.id === d.parentId)));
      const statusTotal = Math.max(1, t.s2 + t.s3 + t.s4 + t.s5);
      return `
      <div class="page-head">
        <div><h1 class="page-title">Reports</h1><p class="page-sub">Bandwidth and visitors for each domain and subdomain</p></div>
        <div class="page-actions"><button class="btn" data-csv>${icon('download', 'i-sm')}Export CSV</button></div>
      </div>

      <section class="card filter-bar">
        <div class="pill-tabs" role="group" aria-label="Period">${Object.keys(PRESETS).map((k) => `<button class="${preset === k ? 'on' : ''}" data-preset="${k}">${PRESET_LABEL[k]}</button>`).join('')}</div>
        <form class="filter-fields" data-range novalidate>
          <label class="field-inline"><span>From</span><input class="input" type="date" name="from" value="${esc(r.from)}" max="${day(0)}"></label>
          <label class="field-inline"><span>To</span><input class="input" type="date" name="to" value="${esc(r.to)}" max="${day(0)}"></label>
          <label class="field-inline grow"><span>Domain</span><select class="select" name="domain"><option value="">All domains</option>${opts.map((d) => `<option value="${esc(d.name)}" ${d.name === domain ? 'selected' : ''}>${d.parentId ? '— ' : ''}${esc(d.name)}</option>`).join('')}</select></label>
          <button class="btn btn-primary" type="submit">${icon('filter', 'i-sm')}Show</button>
        </form>
      </section>

      <section class="grid g-4 mt">
        ${stat('network', 'Bandwidth', HD.fmtBytes(t.out), `${HD.fmtBytes(t.out / nDays)} per day`)}
        ${stat('users2', 'Visitors', HD.fmtNum(t.uv), nDays > 1 ? 'Unique per day, added up' : 'Unique visitors')}
        ${stat('eye', 'Page views', HD.fmtNum(t.pv), `${HD.fmtNum(Math.round(t.pv / nDays))} per day`)}
        ${stat('activity', 'Requests', HD.fmtNum(t.req), `${HD.fmtNum(errors(t))} errors · ${HD.fmtNum(t.bots)} bots`)}
      </section>

      <section class="card mt">
        <div class="card-head">
          <div><div class="card-title">${r.hours ? 'By hour' : 'By day'}</div><div class="card-sub"><span translate="no">${esc(domain || '')}</span>${domain ? ' · ' : ''}${shortDate(r.from)}${r.from !== r.to ? ' – ' + shortDate(r.to) : ''}</div></div>
          <div class="seg" role="group" aria-label="Metric">${Object.entries(METRICS).map(([k, [l]]) => `<button data-metric="${k}" class="${metric === k ? 'on' : ''}">${l}</button>`).join('')}</div>
        </div>
        <div class="card-body"><div data-chart></div></div>
      </section>

      <div class="grid g-main mt" style="align-items:start">
        <section class="card">
          <div class="card-head"><div><div class="card-title">Domains</div><div class="card-sub">Which domain used the most</div></div>
            <div class="seg" role="group" aria-label="Sort">${[['out', 'Bandwidth'], ['uv', 'Visitors'], ['req', 'Requests']].map(([k, l]) => `<button data-sort="${k}" class="${sortBy === k ? 'on' : ''}">${l}</button>`).join('')}</div></div>
          ${sorted.length ? `<div class="table-wrap"><table class="table">
            <thead><tr><th>#</th><th>Domain</th><th>${METRICS[sortBy][0]}</th><th>Bandwidth</th><th>Visitors</th><th>Page views</th><th>Requests</th><th>Errors</th></tr></thead>
            <tbody>${sorted.map((d, i) => `<tr>
              <td class="muted">${i + 1}</td>
              <td><button class="link-btn cell-title" data-pick="${esc(d.name)}" translate="no">${esc(d.name)}</button>${domains.some((x) => x.name === d.name) ? '' : '<div class="cell-sub">Deleted</div>'}</td>
              <td style="min-width:140px"><div class="share"><span style="width:${(d[sortBy] / maxShare) * 100}%"></span></div><div class="cell-sub">${sortBy === 'out' ? d.share + '%' : ''}</div></td>
              <td class="nowrap"><b>${HD.fmtBytes(d.out)}</b></td>
              <td class="nowrap">${HD.fmtNum(d.uv)}</td>
              <td class="nowrap">${HD.fmtNum(d.pv)}</td>
              <td class="nowrap">${HD.fmtNum(d.req)}</td>
              <td class="nowrap ${errors(d) ? '' : 'muted'}">${HD.fmtNum(errors(d))}</td>
            </tr>`).join('')}</tbody></table></div>` : HD.empty('chart', 'No traffic in this period', 'Statistics start from the moment HostDesk 1.1 was installed.')}
        </section>
        <section class="card">
          <div class="card-head"><div class="card-title">Responses</div></div>
          <div class="card-body stack">
            ${[['s2', 'Success (2xx)', 'var(--success-dot)'], ['s3', 'Redirects (3xx)', 'var(--accent)'], ['s4', 'Not found and client errors (4xx)', 'var(--warning-dot)'], ['s5', 'Server errors (5xx)', 'var(--danger-dot)']].map(([k, l, c]) => `
              <div class="hbar"><div class="top"><span>${l}</span><b>${HD.fmtNum(t[k])}</b></div><div class="meter"><span style="width:${(100 * t[k]) / statusTotal}%;background:${c}"></span></div></div>`).join('')}
            <div class="divider"></div>
            <div class="row-between" style="font-size:13px"><span class="muted">Data received</span><b>${HD.fmtBytes(t.in)}</b></div>
            <div class="row-between" style="font-size:13px"><span class="muted">Requests from bots</span><b>${HD.fmtNum(t.bots)}</b></div>
            <p class="hint" style="margin:4px 0 0">Visitors are counted once per domain per day by their IP address. Search engines and other bots are not counted as visitors.</p>
          </div>
        </section>
      </div>`;

      function stat(ic, label, value, sub) {
        return `<div class="card stat"><div class="stat-top"><span class="stat-label">${label}</span><span class="stat-ic">${icon(ic, 'i-sm')}</span></div><div class="stat-value">${value}</div><div class="stat-foot"><span>${esc(sub)}</span></div></div>`;
      }
    },
    async mount(el, ctx) {
      const q = ctx.query;
      const [from0, to0] = q.from && q.to ? [q.from, q.to] : PRESETS.d7();
      const r = await HD.api.trafficReport(from0, to0, q.domain || '').catch(() => null);
      const go = (from, to, domain) => HD.go('/reports?' + new URLSearchParams(Object.entries({ from, to, domain }).filter(([, v]) => v)));
      const draw = () => {
        if (!r) return;
        const box = el.querySelector('[data-chart]'); if (!box) return;
        const [label, fmt, bytes] = METRICS[metric];
        if (r.hours) {
          HD.chart.bars(box, { labels: r.hours.map((h) => String(h.hour).padStart(2, '0') + ':00'), values: r.hours.map((h) => (metric === 'uv' ? h.pv : h[metric])), fmtVal: metric === 'uv' ? METRICS.pv[1] : fmt, bytes, xEvery: 3,
            tip: (i) => [[HD.t('Bandwidth'), HD.fmtBytes(r.hours[i].out)], [HD.t('Page views'), HD.fmtNum(r.hours[i].pv)], [HD.t('Requests'), HD.fmtNum(r.hours[i].req)]] });
        } else {
          HD.chart.bars(box, { labels: r.days.map((d) => shortDate(d.date)), values: r.days.map((d) => d[metric]), fmtVal: fmt, bytes,
            tip: (i) => [[HD.t('Bandwidth'), HD.fmtBytes(r.days[i].out)], [HD.t('Visitors'), HD.fmtNum(r.days[i].uv)], [HD.t('Page views'), HD.fmtNum(r.days[i].pv)], [HD.t('Requests'), HD.fmtNum(r.days[i].req)]] });
        }
        if (r.hours && metric === 'uv') box.insertAdjacentHTML('beforeend', `<div class="hint" style="margin-top:8px">${HD.esc(HD.t('Visitors are counted per day; the hourly chart shows page views.'))}</div>`);
      };
      draw();
      el.addEventListener('click', (e) => {
        const p = e.target.closest('[data-preset]'); if (p) { const [a, b] = PRESETS[p.dataset.preset](); return go(a, b, q.domain); }
        const m = e.target.closest('[data-metric]'); if (m) { metric = m.dataset.metric; HD.$$('[data-metric]', el).forEach((b) => b.classList.toggle('on', b === m)); return draw(); }
        const s = e.target.closest('[data-sort]'); if (s) { sortBy = s.dataset.sort; return HD.rerender(); }
        const pk = e.target.closest('[data-pick]'); if (pk && r) return go(r.from, r.to, pk.dataset.pick);
        if (e.target.closest('[data-csv]') && r) {
          const rows = [['date', 'bandwidth_bytes', 'received_bytes', 'visitors', 'page_views', 'requests', 'errors_4xx', 'errors_5xx']].concat(r.days.map((d) => [d.date, d.out, d.in, d.uv, d.pv, d.req, d.s4, d.s5]));
          rows.push([]); rows.push(['domain', 'bandwidth_bytes', 'received_bytes', 'visitors', 'page_views', 'requests', 'errors_4xx', 'errors_5xx']);
          r.domains.forEach((d) => rows.push([d.name, d.out, d.in, d.uv, d.pv, d.req, d.s4, d.s5]));
          HD.download(`traffic-${r.from}_${r.to}${q.domain ? '-' + q.domain : ''}.csv`, rows.map((x) => x.join(',')).join('\n'), 'text/csv');
        }
      });
      el.querySelector('[data-range]').addEventListener('submit', (e) => {
        e.preventDefault(); const d = HD.formData(e.target);
        if (!d.from || !d.to) return HD.toast(HD.t('Choose both dates'), 'error');
        go(d.from <= d.to ? d.from : d.to, d.from <= d.to ? d.to : d.from, d.domain);
      });
      const offT = HD.on('theme', draw); const offL = HD.on('lang', draw);
      HD.pages.reports._off = () => { offT(); offL(); };
    },
    unmount() { HD.pages.reports._off && HD.pages.reports._off(); },
  };
})();
