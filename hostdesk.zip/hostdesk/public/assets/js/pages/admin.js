/* Accounts and Settings */
(function () {
  const HD = window.HD; const { esc, icon } = HD;
  const genPass = () => Array.from(crypto.getRandomValues(new Uint8Array(14))).map((b) => 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 56]).join('');

  function showPassword(username, pw) {
    HD.modal({ title: 'New password', desc: `For <b>${esc(username)}</b>. It is shown only once.`, body: `<div class="copy-row"><code style="font-size:15px">${esc(pw)}</code><button class="btn btn-sm" data-cp>${icon('copy', 'i-xs')}Copy</button></div>`, foot: `<button class="btn btn-primary" data-close>Done</button>`, onMount(m) { m.querySelector('[data-cp]').addEventListener('click', () => HD.copy(pw, 'Password copied')); } });
  }

  /* ---------- Accounts ---------- */
  function accountModal(domains, acc) {
    const edit = !!acc; let role = acc?.role || 'domain';
    HD.modal({
      title: edit ? `Edit ${acc.username}` : 'Add account', size: 'lg',
      desc: edit ? 'Change the role and which domains this account can manage.' : 'A sign-in for you, a teammate or a client.',
      body: `<form class="stack" novalidate>
        ${edit ? '' : `<div class="form-grid">
          <div class="field"><label for="nu">Username</label><input id="nu" class="input" name="username" autocomplete="off" spellcheck="false" autocapitalize="off"></div>
          <div class="field"><label for="np">Password</label><div class="input-group"><input id="np" class="input mono" name="password" value="${genPass()}" autocomplete="new-password"><button type="button" class="btn addon" data-gen style="height:40px;box-shadow:none">${icon('wand', 'i-sm')}New</button></div><span class="hint">At least 8 characters</span></div>
        </div>`}
        <div class="field"><span class="label">Role</span>
          <div class="choice-grid">
            <button type="button" class="choice" data-role="admin"><span class="choice-ic" style="background:var(--accent-soft);color:var(--accent-text)">${icon('shield')}</span><span><span class="ttl">Administrator</span><br><span class="dsc">Everything, including settings and the App Store.</span></span></button>
            <button type="button" class="choice" data-role="domain"><span class="choice-ic" style="background:var(--surface-3);color:var(--text-2)">${icon('user')}</span><span><span class="ttl">Domain account</span><br><span class="dsc">Only the domains chosen below (and their subdomains).</span></span></button>
          </div>
        </div>
        <div class="field" data-limits><span class="label">Limits</span>
          <div class="form-grid three">
            <div class="field"><label for="lq">Storage (MB)</label><input id="lq" class="input" name="quotaMB" inputmode="numeric" placeholder="No limit" value="${acc?.quotaMB || ''}"></div>
            <div class="field"><label for="ld">Databases</label><input id="ld" class="input" name="maxDatabases" inputmode="numeric" placeholder="No limit" value="${acc?.maxDatabases || ''}"></div>
            <div class="field"><label for="la">Applications</label><input id="la" class="input" name="maxApps" inputmode="numeric" placeholder="No limit" value="${acc?.maxApps || ''}"></div>
          </div>
          <span class="hint">Storage counts the files of the account’s domains and their MySQL, PostgreSQL and MongoDB databases. Leave empty for no limit.</span>
        </div>
        <div class="field" data-doms><span class="label">Domains</span>
          <div class="card" style="box-shadow:none;max-height:240px;overflow:auto"><div class="card-body tight">
            ${domains.length ? domains.map((d) => `<label class="check list-row" style="justify-content:flex-start"><input type="checkbox" name="dom_${d.id}" ${acc?.domains.includes(d.id) ? 'checked' : ''}><span><span class="t" translate="no">${esc(d.name)}</span>${d.parentId ? '' : ` <span class="d">· ${HD.esc(HD.t('with its subdomains'))}</span>`}</span></label>`).join('') : '<div class="muted" style="padding:12px 0">No domains yet.</div>'}
          </div></div>
        </div>
      </form>`,
      foot: `<button class="btn" data-close>Cancel</button><button class="btn btn-primary" data-ok>${edit ? 'Save' : 'Create account'}</button>`,
      onMount(m, api) {
        const f = m.querySelector('form');
        const setRole = (r) => { role = r; HD.$$('[data-role]', m).forEach((b) => b.classList.toggle('on', b.dataset.role === r)); m.querySelector('[data-doms]').hidden = r === 'admin'; m.querySelector('[data-limits]').hidden = r === 'admin'; };
        m.addEventListener('click', (e) => { const r = e.target.closest('[data-role]'); if (r) setRole(r.dataset.role); if (e.target.closest('[data-gen]')) f.querySelector('[name=password]').value = genPass(); });
        setRole(role);
        m.querySelector('[data-ok]').addEventListener('click', async () => {
          const d = HD.formData(f);
          const doms = domains.filter((x) => d['dom_' + x.id]).map((x) => x.id);
          if (role === 'domain' && !doms.length) return HD.toast('Choose at least one domain', 'error');
          try {
            const limits = role === 'admin' ? {} : { quotaMB: d.quotaMB || null, maxDatabases: d.maxDatabases || null, maxApps: d.maxApps || null };
            if (edit) await HD.api.updateAccount(acc.id, { role, domains: role === 'admin' ? [] : doms, ...limits });
            else await HD.api.createAccount({ username: d.username, password: d.password, role, domains: role === 'admin' ? [] : doms, ...limits });
            api.close(); HD.toast(edit ? 'Account updated' : `Account ${d.username} created`); HD.rerender();
          } catch (ex) { if (/storage/i.test(ex.message)) HD.fieldError(f, 'quotaMB', ex.message); else if (/database limit/i.test(ex.message)) HD.fieldError(f, 'maxDatabases', ex.message); else if (/application limit/i.test(ex.message)) HD.fieldError(f, 'maxApps', ex.message); else if (edit) HD.toast(ex.message, 'error'); else HD.fieldError(f, /password/i.test(ex.message) ? 'password' : 'username', ex.message); }
        });
      },
    });
  }

  function usageCell(u) {
    const x = u.usage; const pct = x.quota ? Math.min(100, (100 * x.used) / x.quota) : null;
    return `<div style="font-size:13px"><b>${HD.fmtBytes(x.used)}</b>${x.quota ? ` <span class="muted">/ ${HD.fmtBytes(x.quota)}</span>` : ` <span class="muted">· ${HD.esc(HD.t('No limit'))}</span>`}</div>
      ${x.quota ? `<div class="meter ${pct >= 90 ? 'danger' : pct >= 75 ? 'warn' : ''}" style="margin-top:4px"><span style="width:${pct}%"></span></div>` : ''}
      <div class="cell-sub">${HD.esc(HD.t('{a} apps · {d} databases', { a: x.counts.apps + (u.maxApps ? '/' + u.maxApps : ''), d: x.counts.databases + (u.maxDatabases ? '/' + u.maxDatabases : '') }))}</div>`;
  }

  HD.pages.accounts = {
    title: 'Accounts', nav: 'accounts', admin: true,
    async render() {
      const list = await HD.api.listAccounts(); const me = HD.api.session();
      return `
      <div class="page-head">
        <div><h1 class="page-title">Accounts</h1><p class="page-sub">Administrators see everything. A domain account sees only its domains.</p></div>
        <div class="page-actions"><button class="btn btn-primary" data-new>${icon('plus', 'i-sm')}Add account</button></div>
      </div>
      <section class="card"><div class="table-wrap"><table class="table">
        <thead><tr><th>Account</th><th>Role</th><th>Access</th><th>Usage</th><th>Last sign-in</th><th>Active</th><th><span class="sr-only">Actions</span></th></tr></thead>
        <tbody>${list.map((u) => `
          <tr>
            <td><div class="row" style="gap:12px"><span class="avatar lg">${esc(HD.initials(u.username))}</span><div><div class="cell-title">${esc(u.username)} ${u.id === me.id ? '<span class="badge b-outline" style="margin-inline-start:4px">You</span>' : ''}</div><div class="cell-sub">Created ${HD.fmtDate(u.createdAt)}</div></div></div></td>
            <td>${u.role === 'admin' ? HD.badge('Administrator', 'accent') : HD.badge('Domain account', '')}</td>
            <td style="max-width:300px">${u.role === 'admin' ? '<span class="muted">All domains</span>' : u.domainNames.map((n) => `<a href="#/domains/${encodeURIComponent(n)}" class="badge b-outline" style="margin:2px 4px 2px 0;text-decoration:none">${esc(n)}</a>`).join('') || '<span class="muted">None</span>'}</td>
            <td style="min-width:150px">${u.role === 'admin' ? '<span class="muted">—</span>' : usageCell(u)}</td>
            <td class="muted nowrap">${u.lastLogin ? HD.timeAgo(u.lastLogin) : 'Never'}</td>
            <td>${HD.switchBtn(u.status === 'active', `data-status="${u.id}" aria-label="Active" ${u.id === me.id ? 'disabled' : ''}`)}</td>
            <td class="actions">
              <button class="icon-btn" data-edit="${u.id}" title="Edit" aria-label="Edit ${esc(u.username)}">${icon('edit', 'i-sm')}</button>
              <button class="icon-btn" data-reset="${u.id}" data-name="${esc(u.username)}" title="New password" aria-label="New password for ${esc(u.username)}">${icon('key', 'i-sm')}</button>
              ${u.id === me.id ? '' : `<button class="icon-btn danger" data-del="${u.id}" data-name="${esc(u.username)}" title="Delete" aria-label="Delete ${esc(u.username)}">${icon('trash', 'i-sm')}</button>`}
            </td>
          </tr>`).join('')}</tbody></table></div></section>`;
    },
    mount(el) {
      el.addEventListener('click', async (e) => {
        const t = e.target;
        if (t.closest('[data-new]')) return accountModal(await HD.api.listDomains());
        const ed = t.closest('[data-edit]'); if (ed) { const [d, l] = await Promise.all([HD.api.listDomains(), HD.api.listAccounts()]); return accountModal(d, l.find((u) => u.id === ed.dataset.edit)); }
        const st = t.closest('[data-status]');
        if (st && !st.disabled) { const on = st.getAttribute('aria-checked') !== 'true'; try { await HD.api.updateAccount(st.dataset.status, { status: on ? 'active' : 'disabled' }); HD.toast(on ? 'Account enabled' : 'Account disabled', 'info'); } catch (ex) { HD.toast(ex.message, 'error'); } HD.rerender(); }
        const rs = t.closest('[data-reset]');
        if (rs && (await HD.confirm({ title: `New password for ${rs.dataset.name}?`, message: 'The old password stops working and the account is signed out everywhere.', confirmText: 'Create new password', danger: false }))) {
          try { const r = await HD.api.resetAccountPassword(rs.dataset.reset); showPassword(rs.dataset.name, r.password); } catch (ex) { HD.toast(ex.message, 'error'); }
        }
        const del = t.closest('[data-del]');
        if (del && (await HD.confirm({ title: `Delete ${del.dataset.name}?`, message: 'They can no longer sign in. Their domains stay.', confirmText: 'Delete account' }))) { try { await HD.api.deleteAccount(del.dataset.del); HD.toast('Account deleted'); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); } }
      });
    },
  };

  /** Show the update job, then wait for the restarted panel and reload the page. */
  async function runUpdateJob(job) {
    const before = (await HD.api.health().catch(() => ({}))).version;
    const done = await HD.jobModal(job, { title: HD.t('Update HostDesk') });
    if (!done || done.status !== 'success') return;
    HD.toast(HD.t('Restarting the panel…'), 'info');
    for (let i = 0; i < 40; i++) {
      await HD.sleep(1500);
      const h = await HD.api.health().catch(() => null);
      if (h && (h.version !== before || i > 6)) { location.reload(); return; }
    }
    location.reload();
  }

  /* ---------- Settings ---------- */
  const SWATCHES = ['#4F46E5', '#2563EB', '#0E7490', '#0F766E', '#15803D', '#B45309', '#BE123C', '#7C3AED', '#334155'];
  let savedRef = null, offTheme = null;
  HD.pages.settings = {
    title: 'Settings', nav: 'settings', admin: true,
    async render() {
      const [s, srv, tzs, upd] = await Promise.all([HD.api.getSettings(), HD.api.server(), HD.api.timezones().catch(() => []), HD.api.updateStatus().catch(() => ({ version: '', previous: null, lastUrl: '' }))]);
      return `
      <div class="page-head"><div><h1 class="page-title">Settings</h1><p class="page-sub">Branding, defaults, time zone and security</p></div><div class="page-actions"><a class="btn" href="#/store">${icon('layers', 'i-sm')}App Store</a></div></div>
      <form class="card" data-form novalidate>
        <section class="settings-sec">
          <div><h2>Branding</h2><p>Shown in the menu, on the sign-in page and in the browser tab.</p></div>
          <div class="stack">
            <div class="field"><label for="pn">Panel name</label><input id="pn" class="input" name="panelName" value="${esc(s.panelName)}" maxlength="32"></div>
            <div class="field"><span class="label">Logo</span>
              <div class="row wrap" style="gap:14px">
                <div class="brand-logo logo-preview" data-logo-prev>${HD.logoHtml()}</div>
                <label class="btn btn-sm" style="cursor:pointer">${icon('upload', 'i-sm')}Upload logo<input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" hidden data-logo></label>
                <button type="button" class="btn btn-sm btn-ghost" data-nologo ${s.logo ? '' : 'hidden'}>Remove</button>
                <span class="hint">Square image. It is resized to 128 px.</span>
              </div>
            </div>
            <div class="field"><span class="label">Accent color</span>
              <div class="swatches">${SWATCHES.map((c) => `<button type="button" class="swatch ${c.toLowerCase() === String(s.accent).toLowerCase() ? 'on' : ''}" style="background:${c}" data-accent="${c}" aria-label="Color ${c}"></button>`).join('')}
                <label class="swatch" style="display:grid;place-items:center;cursor:pointer;background:conic-gradient(red,yellow,lime,aqua,blue,magenta,red)" title="Custom color"><input type="color" value="${esc(s.accent)}" data-custom style="opacity:0;width:1px;height:1px"><span class="sr-only">Custom color</span></label>
              </div>
            </div>
          </div>
        </section>
        <section class="settings-sec">
          <div><h2>Appearance</h2><p>Light, dark, or follow the device.</p></div>
          <div><div class="seg" role="group" aria-label="Theme">${['light', 'dark', 'system'].map((t) => `<button type="button" data-theme-set="${t}" class="${s.theme === t ? 'on' : ''}">${icon(t === 'light' ? 'sun' : t === 'dark' ? 'moon' : 'server', 'i-sm')} ${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div></div>
        </section>
        <section class="settings-sec">
          <div><h2>Language</h2><p>The language of the sign-in page and for accounts that have not chosen one. Everyone can switch with the language button at the top.</p></div>
          <div><div class="seg" role="group" aria-label="Language">${[['en', 'English'], ['ps', 'پښتو']].map(([v, l]) => `<button type="button" data-lang-set="${v}" class="${(s.language || 'en') === v ? 'on' : ''}" translate="no">${l}</button>`).join('')}</div></div>
        </section>
        <section class="settings-sec">
          <div><h2>Defaults</h2><p>Used when you create applications.</p></div>
          <div class="form-grid">
            <div class="field"><label for="ns">First Node.js port</label><input id="ns" class="input mono" name="nodePortStart" inputmode="numeric" value="${s.nodePortStart}"><span class="hint">New Node apps take the next free port from here.</span></div>
            <div class="field"><label for="st">Sign out after</label><select id="st" class="select" name="sessionTimeout">${[[15, '15 minutes'], [30, '30 minutes'], [60, '1 hour'], [240, '4 hours'], [480, '8 hours'], [1440, '1 day']].map(([v, l]) => `<option value="${v}" ${+s.sessionTimeout === v ? 'selected' : ''}>${l} without activity</option>`).join('')}</select></div>
            <div class="field"><label for="dn">Default Node.js</label><select id="dn" class="select" name="defaultNode">${['24', '22', '20', '18'].map((v) => `<option value="${v}" ${v === s.defaultNode ? 'selected' : ''}>${v}${s.runtimes.node.includes(v) ? '' : ' (not installed)'}</option>`).join('')}</select></div>
            <div class="field"><label for="dp">Default PHP</label><select id="dp" class="select" name="defaultPhp">${['8.4', '8.3', '8.2', '8.1', '7.4'].map((v) => `<option value="${v}" ${v === s.defaultPhp ? 'selected' : ''}>${v}${s.runtimes.php.includes(v) ? '' : ' (not installed)'}</option>`).join('')}</select></div>
            <div class="field"><label>Web root</label><input class="input mono" value="${esc(s.wwwRoot)}" readonly><span class="hint">Set in /etc/hostdesk/config.json</span></div>
            <div class="field"><label>Panel port</label><input class="input mono" value="${s.panelPort}" readonly><span class="hint">Set in /etc/hostdesk/config.json</span></div>
          </div>
        </section>
        <div class="card-foot"><button type="button" class="btn" data-revert>Cancel</button><button type="submit" class="btn btn-primary">Save settings</button></div>
      </form>

      <div class="grid g-2 mt" style="align-items:start">
        <div class="stack">
          <form class="card" data-pass novalidate>
            <div class="card-head"><div><div class="card-title">${icon('lock', 'i-sm')}Change your password</div><div class="card-sub">Signed in as ${esc(HD.api.session().username)}</div></div></div>
            <div class="card-body stack">
              <div class="field"><label for="op">Current password</label><input id="op" class="input" type="password" name="old" autocomplete="current-password"></div>
              <div class="form-grid">
                <div class="field"><label for="nw">New password</label><input id="nw" class="input" type="password" name="new" autocomplete="new-password"></div>
                <div class="field"><label for="nw2">Repeat</label><input id="nw2" class="input" type="password" name="new2" autocomplete="new-password"></div>
              </div>
            </div>
            <div class="card-foot"><button class="btn btn-primary" type="submit">Update password</button></div>
          </form>
          <section class="card">
            <div class="card-head"><div><div class="card-title">${icon('clock', 'i-sm')}Server time zone</div><div class="card-sub">Used by cron jobs and the daily backup</div></div></div>
            <div class="card-body row wrap" style="gap:10px">
              <select class="select" data-tz style="flex:1;min-width:220px" aria-label="Time zone">${(tzs.length ? tzs : [srv.timezone]).map((z) => `<option ${z === srv.timezone ? 'selected' : ''}>${esc(z)}</option>`).join('')}</select>
              <button class="btn" data-settz>Apply</button>
            </div>
          </section>
          <section class="card" data-update-card>
            <div class="card-head"><div><div class="card-title">${icon('download', 'i-sm')}Update HostDesk</div><div class="card-sub">${HD.t('Installed version {v}', { v: `<b class="mono">${esc(upd.version)}</b>` })}${upd.previous ? ' · ' + HD.t('previous {v}', { v: `<span class="mono">${esc(upd.previous)}</span>` }) : ''}. ${HD.esc(HD.t('Sites, databases and settings are kept.'))}</div></div></div>
            <div class="card-body stack">
              <div class="field"><label for="uurl">From a link</label>
                <div class="input-group"><input id="uurl" class="input mono" data-uurl placeholder="https://github.com/you/repo/raw/main/hostdesk.zip" value="${esc(upd.lastUrl)}" spellcheck="false" autocapitalize="off"><button type="button" class="btn addon" data-uurl-go style="height:40px;box-shadow:none">${icon('download', 'i-sm')}Update</button></div>
                <span class="hint">A public https link to a HostDesk .zip (for example the “raw” link of the file in your GitHub repository).</span></div>
              <div class="row wrap" style="gap:10px">
                <label class="btn" style="cursor:pointer">${icon('upload', 'i-sm')}Upload a .zip<input type="file" accept=".zip,application/zip" hidden data-uzip></label>
                ${upd.previous ? `<button type="button" class="btn btn-ghost" data-rollback>${icon('restart', 'i-sm')}Go back to ${esc(upd.previous)}</button>` : ''}
              </div>
            </div>
          </section>
          <section class="card">
            <div class="card-head"><div><div class="card-title">${icon('refresh', 'i-sm')}Repair configuration</div><div class="card-sub">Writes the Nginx, PHP-FPM, systemd and cron settings of every site again. Safe to run any time.</div></div></div>
            <div class="card-body"><button class="btn" data-reapply>${icon('wand', 'i-sm')}Re-apply all sites</button></div>
          </section>
        </div>
        <section class="card">
          <div class="card-head"><div class="card-title">${icon('server', 'i-sm')}Server</div></div>
          <div class="card-body tight">
            ${[['Hostname', srv.hostname], ['System', srv.os], ['Kernel', srv.kernel], ['CPU', `${srv.cpu} · ${srv.threads} threads`], ['Memory', HD.fmtBytes(srv.ramTotal)], ['Disk', `${HD.fmtBytes(srv.diskUsed)} of ${HD.fmtBytes(srv.diskTotal)} used`], ['IP addresses', srv.ips.map((x) => `${x.address} (${x.iface})`).join(', ') || '—'], ['Time zone', srv.timezone], ['Uptime', HD.fmtUptime(srv.uptime)], ['Panel', `HostDesk ${srv.panel.version} · Node.js ${srv.panel.node}`]].map(([k, v]) => `<div class="list-row"><span class="muted">${k}</span><span style="text-align:end">${esc(v)}</span></div>`).join('')}
          </div>
        </section>
      </div>`;
    },
    mount(el) {
      const form = el.querySelector('[data-form]');
      savedRef = HD.clone(HD.settings);
      let draft = {};
      offTheme = HD.on('theme', () => { savedRef.theme = HD.settings.theme; HD.$$('[data-theme-set]', el).forEach((b) => b.classList.toggle('on', b.dataset.themeSet === HD.settings.theme)); });
      const preview = () => {
        HD.applyBranding({ ...savedRef, ...draft });
        el.querySelector('[data-logo-prev]').innerHTML = HD.logoHtml();
        el.querySelector('[data-nologo]').hidden = !HD.settings.logo;
        HD.$$('[data-accent]', el).forEach((b) => b.classList.toggle('on', b.dataset.accent.toLowerCase() === String(HD.settings.accent).toLowerCase()));
      };
      form.querySelector('[name=panelName]').addEventListener('input', (e) => { draft.panelName = e.target.value || 'HostDesk'; preview(); });
      el.querySelector('[data-custom]').addEventListener('input', (e) => { draft.accent = e.target.value; preview(); });
      el.querySelector('[data-logo]').addEventListener('change', (e) => {
        const f = e.target.files[0]; if (!f) return;
        if (f.size > 4e6) return HD.toast('Image must be smaller than 4 MB', 'error');
        const img = new Image(); const url = URL.createObjectURL(f);
        img.onload = () => { const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d'); const s = Math.min(img.width, img.height) || 128; x.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 128, 128); draft.logo = c.toDataURL('image/png'); URL.revokeObjectURL(url); preview(); };
        img.onerror = () => HD.toast('This image cannot be read', 'error');
        img.src = url;
      });
      el.addEventListener('click', async (e) => {
        const t = e.target;
        const a = t.closest('[data-accent]'); if (a) { draft.accent = a.dataset.accent; preview(); }
        if (t.closest('[data-nologo]')) { draft.logo = null; preview(); }
        const th = t.closest('[data-theme-set]'); if (th) { draft.theme = th.dataset.themeSet; HD.$$('[data-theme-set]', el).forEach((b) => b.classList.toggle('on', b === th)); preview(); const tb = document.querySelector('[data-theme-toggle]'); if (tb) tb.innerHTML = icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon'); }
        if (t.closest('[data-revert]')) { draft = {}; HD.applyBranding(savedRef); HD.rerender(); }
        const ls = t.closest('[data-lang-set]'); if (ls) { draft.language = ls.dataset.langSet; HD.$$('[data-lang-set]', el).forEach((b) => b.classList.toggle('on', b === ls)); }
        if (t.closest('[data-uurl-go]')) {
          const url = el.querySelector('[data-uurl]').value.trim(); if (!url) return HD.toast(HD.t('Enter a link'), 'error');
          if (!(await HD.confirm({ title: HD.t('Update HostDesk now?'), message: HD.esc(HD.t('The package is downloaded and checked first. Then the panel restarts (a few seconds). Your sites keep running.')), confirmText: HD.t('Update'), danger: false }))) return;
          try { const r = await HD.api.updateFromUrl(url); runUpdateJob(r.job); } catch (ex) { HD.toast(ex.message, 'error'); }
        }
        if (t.closest('[data-rollback]') && (await HD.confirm({ title: HD.t('Go back to the previous version?'), message: HD.esc(HD.t('The panel restarts with the version that was installed before the last update.')), confirmText: HD.t('Go back'), danger: false }))) {
          try { const r = await HD.api.rollback(); runUpdateJob(r.job); } catch (ex) { HD.toast(ex.message, 'error'); }
        }
        if (t.closest('[data-settz]')) { const tz = el.querySelector('[data-tz]').value; try { await HD.api.setTimezone(tz); HD.toast(`Time zone set to ${tz}`); } catch (ex) { HD.toast(ex.message, 'error'); } }
        if (t.closest('[data-reapply]') && (await HD.confirm({ title: 'Re-apply all sites?', message: 'Every site’s Nginx, PHP-FPM, systemd and cron settings are written again and tested. Sites keep running.', confirmText: 'Re-apply', danger: false }))) { try { const r = await HD.api.reapply(); await HD.jobModal(r.job); } catch (ex) { HD.toast(ex.message, 'error'); } }
      });
      el.querySelector('[data-uzip]')?.addEventListener('change', async (e) => {
        const f = e.target.files[0]; if (!f) return;
        if (!(await HD.confirm({ title: HD.t('Update HostDesk now?'), message: HD.esc(HD.t('The package is checked first. Then the panel restarts (a few seconds). Your sites keep running.')), confirmText: HD.t('Update'), danger: false }))) return;
        try { HD.toast(HD.t('Uploading…'), 'info'); const r = await HD.api.updateUpload(f); runUpdateJob(r.job); } catch (ex) { HD.toast(ex.message, 'error'); }
      });
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const d = HD.formData(form);
        const body = { ...draft, panelName: d.panelName || 'HostDesk', nodePortStart: Number(d.nodePortStart), sessionTimeout: Number(d.sessionTimeout), defaultNode: d.defaultNode, defaultPhp: d.defaultPhp };
        if (!('theme' in body)) body.theme = HD.settings.theme;
        try { const s = await HD.api.saveSettings(body); savedRef = { ...savedRef, ...s }; draft = {}; HD.applyBranding(s); HD.toast('Settings saved'); HD.rerender(); }
        catch (ex) { HD.fieldError(form, /port/i.test(ex.message) ? 'nodePortStart' : 'panelName', ex.message); }
      });
      el.querySelector('[data-pass]').addEventListener('submit', async (e) => {
        e.preventDefault(); const f = e.target; const d = HD.formData(f);
        if (d.new !== d.new2) return HD.fieldError(f, 'new2', 'Passwords do not match');
        try { await HD.api.changePassword(d.old, d.new); HD.toast('Password updated'); f.reset(); } catch (ex) { HD.fieldError(f, /current/i.test(ex.message) ? 'old' : 'new', ex.message); }
      });
    },
    unmount() { offTheme && offTheme(); offTheme = null; if (savedRef) HD.applyBranding(savedRef); savedRef = null; const tb = document.querySelector('[data-theme-toggle]'); if (tb) tb.innerHTML = icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon'); },
  };
})();
