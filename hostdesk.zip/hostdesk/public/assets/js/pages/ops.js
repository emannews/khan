/* Routes, Backups, Cron jobs, Activity */
(function () {
  const HD = window.HD; const { esc, icon } = HD;

  /* ---------- Routes ---------- */
  HD.pages.routes = {
    title: 'Routes', nav: 'routes', admin: true,
    async render() {
      const [domains, cfgYaml] = await Promise.all([HD.api.listDomains(), HD.api.routesConfig()]);
      const order = domains.filter((d) => !d.parentId).flatMap((r) => [r, ...domains.filter((d) => d.parentId === r.id)]);
      return `
      <div class="page-head">
        <div><h1 class="page-title">Routes</h1><p class="page-sub">Which local service answers for each hostname</p></div>
        <div class="page-actions"><button class="btn" data-dl>${icon('download', 'i-sm')}Download config.yml</button><button class="btn btn-primary" data-copyyaml>${icon('copy', 'i-sm')}Copy tunnel config</button></div>
      </div>
      <div class="callout" style="margin-bottom:16px">${icon('info', 'i-sm')}<div>${HD.t('PHP and static sites share {addr} — Nginx picks the site by its hostname. Each Node.js app has its own port. In {where}, add each hostname with the service shown here.', { addr: '<b class="mono">localhost:80</b>', where: `<b>${HD.esc(HD.t('Cloudflare Zero Trust → Networks → Tunnels → your tunnel → Public Hostnames'))}</b>` })}</div></div>
      <section class="card">
        ${order.length ? `<div class="table-wrap"><table class="table">
          <thead><tr><th>Hostname</th><th>Application</th><th>Service</th><th>Status</th><th><span class="sr-only">Copy</span></th></tr></thead>
          <tbody>${order.map((d) => `
            <tr>
              <td><div class="row" style="gap:10px">${d.parentId ? `<span style="width:14px"></span>${icon('layers', 'i-sm faint')}` : icon('globe', 'i-sm faint')}<div><a class="cell-title" href="#/domains/${encodeURIComponent(d.name)}">${esc(d.name)}</a>${d.route.aliases.length ? `<div class="cell-sub">also ${d.route.aliases.map(esc).join(', ')}</div>` : `<div class="cell-sub">Subdomain</div>`}</div></div></td>
              <td>${d.app ? `<div class="row">${HD.runtimeBadge(d.app.runtime)}<a href="#/apps/${d.app.id}">${esc(d.app.name)}</a></div>` : `<span class="row">${HD.badge('Static', 'outline')}<a href="#/apps/new?domain=${d.id}" style="font-size:13px">Create app</a></span>`}</td>
              <td class="mono nowrap">${esc(d.route.service)}</td>
              <td>${d.enabled ? HD.badge('On', 'success', true) : HD.badge('Off', '', true)}</td>
              <td class="actions"><button class="btn btn-sm" data-copy="${esc(d.route.service)}">${icon('copy', 'i-xs')}Copy</button></td>
            </tr>`).join('')}</tbody></table></div>` : HD.empty('route', 'No routes yet', 'Add a domain first.')}
      </section>
      <section class="card mt">
        <div class="card-head"><div><div class="card-title">Tunnel config</div><div class="card-sub">${HD.t('Only for a tunnel managed with a local file ({file}). If your tunnel is managed in the Cloudflare dashboard, add the hostnames there instead.', { file: '<span class="mono">/etc/cloudflared/config.yml</span>' })}</div></div><button class="btn btn-sm" data-copyyaml>${icon('copy', 'i-sm')}Copy</button></div>
        <div class="card-body"><pre class="code">${esc(cfgYaml.yaml).replace(/(hostname|service|ingress):/g, '<span class="key">$1</span>:')}</pre></div>
      </section>`;
    },
    mount(el) {
      el.addEventListener('click', async (e) => {
        const c = e.target.closest('[data-copy]'); if (c) HD.copy(c.dataset.copy);
        if (e.target.closest('[data-copyyaml]')) HD.copy((await HD.api.routesConfig()).yaml, 'Tunnel config copied');
        if (e.target.closest('[data-dl]')) HD.download('config.yml', (await HD.api.routesConfig()).yaml, 'text/yaml');
      });
    },
  };

  /* ---------- Backups ---------- */
  HD.pages.backups = {
    title: 'Backups', nav: 'backups',
    async render() {
      const admin = HD.isAdmin();
      const [list, s] = await Promise.all([HD.api.listBackups(), admin ? HD.api.getSettings() : Promise.resolve(null)]);
      const total = list.reduce((t, b) => t + (b.size || 0), 0);
      const typeLabel = { auto: 'Scheduled', manual: 'Manual', safety: 'Safety copy before restore' };
      return `
      <div class="page-head">
        <div><h1 class="page-title">Backups</h1><p class="page-sub">Site folders and database dumps in one .tar.gz, saved on this server</p></div>
        <div class="page-actions"><button class="btn btn-primary" data-new>${icon('archive', 'i-sm')}Create backup</button></div>
      </div>
      <div class="grid ${admin ? 'g-main' : ''}" style="align-items:start">
        <section class="card">
          <div class="card-head"><div><div class="card-title">All backups</div><div class="card-sub">${list.length} backup${list.length === 1 ? '' : 's'} · ${HD.fmtBytes(total)}</div></div></div>
          ${list.length ? `<div class="table-wrap"><table class="table">
            <thead><tr><th>Backup</th><th>Created</th><th>Size</th><th><span class="sr-only">Actions</span></th></tr></thead>
            <tbody>${list.map((b) => `
              <tr>
                <td><div class="row" style="gap:12px"><span class="svc-ic">${icon('archive', 'i-sm')}</span><div><div class="cell-title">${esc(b.label)}</div><div class="cell-sub">${typeLabel[b.type] || b.type}${b.databases ? ` · ${b.databases} database${b.databases > 1 ? 's' : ''}` : ''}${b.missing ? ' · <span style="color:var(--danger)">file missing</span>' : ''}</div></div></div></td>
                <td class="nowrap"><div>${HD.fmtDateTime(b.createdAt)}</div><div class="cell-sub">${HD.timeAgo(b.createdAt)}</div></td>
                <td class="muted nowrap">${HD.fmtBytes(b.size)}</td>
                <td class="actions">
                  ${b.missing ? '' : `<button class="btn btn-sm" data-restore="${b.id}" data-label="${esc(b.label)}">${icon('restart', 'i-xs')}Restore</button><a class="icon-btn" href="${HD.api.backupUrl(b.id)}" download title="Download" aria-label="Download backup">${icon('download', 'i-sm')}</a>`}
                  <button class="icon-btn danger" data-del="${b.id}" title="Delete" aria-label="Delete backup">${icon('trash', 'i-sm')}</button>
                </td>
              </tr>`).join('')}</tbody></table></div>` : HD.empty('archive', 'No backups yet', 'Create your first backup now.')}
        </section>
        ${admin ? `<section class="card">
          <div class="card-head"><div class="card-title">Daily backup</div>${HD.switchBtn(s.backupEnabled, 'data-sched aria-label="Daily backup"')}</div>
          <form class="card-body stack" data-sform novalidate>
            <div class="form-grid">
              <div class="field"><label for="bt">Time (server)</label><input id="bt" class="input" type="time" name="backupTime" value="${esc(s.backupTime)}"></div>
              <div class="field"><label for="bk">Keep</label><select id="bk" class="select" name="backupKeep">${[3, 7, 14, 30].map((n) => `<option value="${n}" ${+s.backupKeep === n ? 'selected' : ''}>${n} days</option>`).join('')}</select></div>
            </div>
            <label class="check"><input type="checkbox" name="backupExcludeNodeModules" ${s.backupExcludeNodeModules ? 'checked' : ''}><span><span class="t">Skip node_modules folders</span><br><span class="d">They are rebuilt with npm install. Saves a lot of space.</span></span></label>
            <div class="callout">${icon('info', 'i-sm')}<div>${s.backupEnabled ? HD.t('Every day at {time} (server time) all domains are backed up. Scheduled backups older than {n} days are removed.', { time: `<b class="mono">${esc(s.backupTime)}</b>`, n: s.backupKeep }) : HD.esc(HD.t('Daily backups are off.'))} ${HD.esc(HD.t('Keep a copy somewhere else too: download one now and then.'))}</div></div>
            <div><button class="btn btn-primary" type="submit">Save</button></div>
          </form>
        </section>` : ''}
      </div>`;
    },
    mount(el) {
      el.querySelector('[data-sform]')?.addEventListener('submit', async (e) => { e.preventDefault(); const d = HD.formData(e.target); try { await HD.api.saveSettings({ backupTime: d.backupTime, backupKeep: +d.backupKeep, backupExcludeNodeModules: d.backupExcludeNodeModules }); HD.toast('Saved'); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); } });
      el.addEventListener('click', async (e) => {
        const t = e.target;
        if (t.closest('[data-sched]')) { const on = t.closest('[data-sched]').getAttribute('aria-checked') !== 'true'; try { await HD.api.saveSettings({ backupEnabled: on }); HD.toast(on ? 'Daily backup on' : 'Daily backup off', 'info'); } catch (ex) { HD.toast(ex.message, 'error'); } HD.rerender(); }
        if (t.closest('[data-new]')) {
          const domains = (await HD.api.listDomains()).filter((d) => !d.parentId || !HD.isAdmin());
          HD.modal({
            title: 'Create backup', desc: 'Copies the site folders and dumps their MySQL, PostgreSQL and MongoDB databases into one archive.',
            body: `<div class="field"><label for="bs">What to back up</label><select id="bs" class="select">${HD.isAdmin() ? '<option value="all">All domains</option>' : ''}${domains.map((d) => `<option value="${d.id}">${esc(d.name)}${d.parentId ? '' : ' (with subdomains)'}</option>`).join('')}</select></div>`,
            foot: `<button class="btn" data-close>Cancel</button><button class="btn btn-primary" data-go>Start backup</button>`,
            onMount(m, api) {
              m.querySelector('[data-go]').addEventListener('click', async () => {
                try { const r = await HD.api.createBackup(m.querySelector('select').value); api.close(); await HD.jobModal(r.job); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); }
              });
            },
          });
        }
        const r = t.closest('[data-restore]');
        if (r && (await HD.confirm({ title: `Restore ${r.dataset.label}?`, message: 'Files in the backup overwrite the current ones, and its databases are imported. A safety backup is made first, so you can go back.', confirmText: 'Restore', danger: true }))) {
          try { const x = await HD.api.restoreBackup(r.dataset.restore); await HD.jobModal(x.job); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); }
        }
        const del = t.closest('[data-del]');
        if (del && (await HD.confirm({ title: 'Delete this backup?', message: 'The archive file is removed from the server.', confirmText: 'Delete' }))) { try { await HD.api.deleteBackup(del.dataset.del); HD.toast('Backup deleted'); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); } }
      });
    },
  };

  /* ---------- Cron ---------- */
  const PRESETS = [['Every 5 minutes', '*/5 * * * *'], ['Every hour', '0 * * * *'], ['Every day at 03:00', '0 3 * * *'], ['Every Monday 09:00', '0 9 * * 1'], ['First day of month', '0 0 1 * *'], ['At reboot', '@reboot']];
  HD.cronText = (expr) => {
    const macros = { '@reboot': 'When the server starts', '@hourly': 'Every hour', '@daily': 'Every day at midnight', '@weekly': 'Every week', '@monthly': 'Every month', '@yearly': 'Every year' };
    if (macros[expr]) return macros[expr];
    const p = expr.trim().split(/\s+/); if (p.length !== 5) return 'Invalid';
    const [mi, h, dom, mo, dow] = p; const pad = (n) => String(n).padStart(2, '0');
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    if (p.every((x) => x === '*')) return 'Every minute';
    if (/^\*\/\d+$/.test(mi) && h === '*' && dom === '*' && mo === '*' && dow === '*') return `Every ${mi.slice(2)} minutes`;
    if (/^\d+$/.test(mi) && h === '*' && dom === '*' && dow === '*') return mi === '0' ? 'Every hour' : `Every hour at :${pad(mi)}`;
    if (/^\d+$/.test(mi) && /^\*\/\d+$/.test(h) && dom === '*' && dow === '*') return `Every ${h.slice(2)} hours`;
    if (/^\d+$/.test(mi) && /^\d+$/.test(h) && dom === '*' && mo === '*' && dow === '*') return `Every day at ${pad(h)}:${pad(mi)}`;
    if (/^\d+$/.test(mi) && /^\d+$/.test(h) && dom === '*' && /^\d$/.test(dow)) return `Every ${days[+dow % 7]} at ${pad(h)}:${pad(mi)}`;
    if (/^\d+$/.test(mi) && /^\d+$/.test(h) && /^\d+$/.test(dom) && mo === '*') return `Monthly on day ${dom} at ${pad(h)}:${pad(mi)}`;
    return 'Custom schedule';
  };
  HD.pages.cron = {
    title: 'Cron jobs', nav: 'cron',
    async render() {
      const jobs = await HD.api.listCron();
      const tz = HD.serverInfo?.timezone;
      return `
      <div class="page-head">
        <div><h1 class="page-title">Cron jobs</h1><p class="page-sub">Commands that run on a schedule, inside a site folder, as that site’s user${tz ? ` · server time zone ${esc(tz)}` : ''}</p></div>
        <div class="page-actions"><button class="btn btn-primary" data-new>${icon('plus', 'i-sm')}Add cron job</button></div>
      </div>
      <section class="card">
        ${jobs.length ? `<div class="table-wrap"><table class="table">
          <thead><tr><th>Job</th><th>Domain</th><th>Schedule</th><th>Last output</th><th>On</th><th><span class="sr-only">Actions</span></th></tr></thead>
          <tbody>${jobs.map((c) => `
            <tr>
              <td><div class="cell-title">${esc(c.name || 'Untitled job')}</div><div class="cell-sub mono truncate" style="max-width:360px">${esc(c.command)}</div></td>
              <td>${c.domain ? `<a href="#/domains/${encodeURIComponent(c.domain)}">${esc(c.domain)}</a>` : '—'}</td>
              <td><div>${esc(HD.cronText(c.schedule))}</div><div class="cell-sub mono">${esc(c.schedule)}</div></td>
              <td class="nowrap">${c.lastRun ? `<button class="link-btn" data-log="${c.id}">${HD.timeAgo(c.lastRun)}</button>` : '<span class="muted">Not yet</span>'}</td>
              <td>${HD.switchBtn(c.enabled, `data-toggle="${c.id}" aria-label="Enable ${esc(c.name)}"`)}</td>
              <td class="actions">
                <button class="btn btn-sm" data-run="${c.id}">${icon('play', 'i-xs')}Run now</button>
                <button class="icon-btn danger" data-del="${c.id}" data-name="${esc(c.name || 'job')}" aria-label="Delete">${icon('trash', 'i-sm')}</button>
              </td>
            </tr>`).join('')}</tbody></table></div>` : HD.empty('clock', 'No cron jobs', 'Schedule a command to run automatically.', `<button class="btn btn-primary" data-new>${icon('plus', 'i-sm')}Add cron job</button>`)}
      </section>`;
    },
    mount(el) {
      el.addEventListener('click', async (e) => {
        const t = e.target;
        const tg = t.closest('[data-toggle]'); if (tg) { const on = tg.getAttribute('aria-checked') !== 'true'; try { await HD.api.updateCron(tg.dataset.toggle, { enabled: on }); HD.toast(on ? 'Job on' : 'Job paused', 'info'); } catch (ex) { HD.toast(ex.message, 'error'); } HD.rerender(); }
        const rn = t.closest('[data-run]'); if (rn) { try { const r = await HD.api.runCron(rn.dataset.run); await HD.jobModal(r.job); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); } }
        const lg = t.closest('[data-log]'); if (lg) { const r = await HD.api.cronLog(lg.dataset.log).catch((ex) => ({ text: ex.message })); HD.modal({ title: 'Last output', size: 'lg', body: `<pre class="code" style="max-height:60vh">${esc(r.text)}</pre>`, foot: '<button class="btn btn-primary" data-close>Close</button>' }); }
        const del = t.closest('[data-del]'); if (del && (await HD.confirm({ title: `Delete ${del.dataset.name}?`, message: 'The job stops running.', confirmText: 'Delete' }))) { try { await HD.api.deleteCron(del.dataset.del); HD.toast('Job deleted'); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); } }
        if (t.closest('[data-new]')) {
          const domains = await HD.api.listDomains();
          if (!domains.length) return HD.toast('Add a domain first', 'error');
          HD.modal({
            title: 'Add cron job', size: 'lg',
            body: `<form class="stack" novalidate>
              <div class="form-grid">
                <div class="field"><label for="cn">Name</label><input id="cn" class="input" name="name" placeholder="Clean old sessions"></div>
                <div class="field"><label for="cd">Domain</label><select id="cd" class="select" name="domainId">${domains.map((d) => `<option value="${d.id}">${esc(d.name)}</option>`).join('')}</select></div>
              </div>
              <div class="field"><label for="cs">Schedule</label>
                <div class="pill-tabs" style="margin-bottom:8px">${PRESETS.map(([l, v]) => `<button type="button" data-preset="${v}">${l}</button>`).join('')}</div>
                <input id="cs" class="input mono" name="schedule" value="0 3 * * *"><span class="hint"><span data-human></span> · <span>minute hour day month weekday</span></span></div>
              <div class="field"><label for="cc">Command</label><input id="cc" class="input mono" name="command" placeholder="node scripts/cleanup.js" spellcheck="false" autocapitalize="off"><span class="hint" data-cwd></span></div>
            </form>`,
            foot: `<button class="btn" data-close>Cancel</button><button class="btn btn-primary" data-ok>Add job</button>`,
            onMount(m, api) {
              const f = m.querySelector('form'), s = f.querySelector('[name=schedule]');
              const upd = () => { m.querySelector('[data-human]').textContent = HD.cronText(s.value); const d = domains.find((x) => x.id === f.querySelector('[name=domainId]').value); m.querySelector('[data-cwd]').innerHTML = HD.t('Runs inside {folder} as {user}.', { folder: `<span class="mono">${esc(d?.folder || '')}</span>`, user: `<span class="mono">${esc(d?.siteUser || '')}</span>` }); HD.$$('[data-preset]', m).forEach((b) => b.classList.toggle('on', b.dataset.preset === s.value.trim())); };
              f.addEventListener('input', upd); f.addEventListener('change', upd); upd();
              m.addEventListener('click', (ev) => { const p = ev.target.closest('[data-preset]'); if (p) { s.value = p.dataset.preset; upd(); } });
              m.querySelector('[data-ok]').addEventListener('click', async () => { try { await HD.api.createCron(HD.formData(f)); api.close(); HD.toast('Cron job added'); HD.rerender(); } catch (ex) { HD.fieldError(f, /command/i.test(ex.message) ? 'command' : /schedule/i.test(ex.message) ? 'schedule' : 'name', ex.message); } });
            },
          });
        }
      });
    },
  };

  /* ---------- Activity ---------- */
  let actUser = '', actQ = '';
  HD.pages.activity = {
    title: 'Activity', nav: 'activity',
    async render() {
      const all = await HD.api.listActivity(1000);
      const users = [...new Set(all.map((a) => a.user))];
      const rows = all.filter((a) => (!actUser || a.user === actUser) && (!actQ || (a.action + ' ' + a.target).toLowerCase().includes(actQ.toLowerCase())));
      const groups = {}; rows.slice(0, 400).forEach((a) => { const k = new Date(a.time).toDateString(); (groups[k] = groups[k] || []).push(a); });
      const label = (k) => { const d = new Date(k), t = new Date(); t.setHours(0, 0, 0, 0); const diff = Math.round((t - d) / 86400000); return diff === 0 ? 'Today' : diff === 1 ? 'Yesterday' : HD.fmtDate(d); };
      return `
      <div class="page-head">
        <div><h1 class="page-title">Activity</h1><p class="page-sub">Who changed what on this server</p></div>
        <div class="page-actions">
          <select class="select" data-user style="width:170px" aria-label="Filter by user"><option value="">All users</option>${users.map((u) => `<option ${u === actUser ? 'selected' : ''}>${esc(u)}</option>`).join('')}</select>
          <div class="input-icon" style="width:230px">${icon('search', 'i-sm')}<input class="input" type="search" placeholder="Search" value="${esc(actQ)}" data-q aria-label="Search activity"></div>
          <button class="btn" data-export>${icon('download', 'i-sm')}CSV</button>
        </div>
      </div>
      <section class="card">
        ${rows.length ? Object.entries(groups).map(([k, list]) => `
          <div style="padding:12px 20px;background:var(--surface-2);border-bottom:1px solid var(--border-2);font-size:12.5px;font-weight:600;color:var(--muted)">${label(k)}</div>
          <div class="card-body tight timeline">${list.map((a) => `
            <div class="tl-item" style="border-bottom:1px solid var(--border-2)"><span class="ic">${icon(a.icon || 'activity', 'i-xs')}</span>
              <div class="grow"><div class="txt"><b translate="no">${esc(a.user)}</b> <span data-act>${esc(a.action)}</span> <b translate="no">${esc(a.target)}</b></div></div>
              <div class="when nowrap" title="${esc(HD.fmtDateTime(a.time))}">${HD.fmtTime(a.time).slice(0, 5)}</div></div>`).join('')}</div>`).join('')
          : HD.empty('activity', 'No activity', actQ || actUser ? 'Nothing matches your filter.' : 'Changes appear here.')}
      </section>`;
    },
    mount(el) {
      el.querySelector('[data-user]').addEventListener('change', (e) => { actUser = e.target.value; HD.rerender(); });
      const qi = el.querySelector('[data-q]');
      qi.addEventListener('input', HD.debounce(async () => { actQ = qi.value; const pos = qi.selectionStart; await HD.rerender(); const n = document.querySelector('[data-q]'); n?.focus(); n?.setSelectionRange(pos, pos); }, 200));
      el.querySelector('[data-export]').addEventListener('click', async () => {
        const all = await HD.api.listActivity(2000);
        HD.download('activity.csv', 'time,user,action,target\n' + all.map((a) => [new Date(a.time).toISOString(), a.user, a.action, a.target].map((v) => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n'), 'text/csv');
      });
    },
  };
})();
