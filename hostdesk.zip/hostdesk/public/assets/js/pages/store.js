/* App Store — runtimes, databases and tools */
(function () {
  const HD = window.HD; const { esc, icon } = HD;
  const ORDER = ['Runtimes', 'Databases', 'Security', 'Web server', 'Tools'];
  const DESC = { Runtimes: 'Node.js and PHP versions for your applications. Several versions can be installed side by side.', Databases: 'Database servers. Each listens only on this machine (127.0.0.1).', Security: 'Protection for the server.', 'Web server': 'Required by the panel.', Tools: 'Useful command-line tools.' };

  HD.pages.store = {
    title: 'App Store', nav: 'store', admin: true,
    async render() {
      const items = await HD.api.store();
      const byCat = {}; items.forEach((it) => (byCat[it.category] = byCat[it.category] || []).push(it));
      const installed = items.filter((i) => i.installed).length;
      const card = (it) => {
        const conflict = it.conflicts && items.find((x) => x.id === it.conflicts && x.installed);
        const busy = !!it.job;
        const st = busy ? HD.badge('Working…', 'accent', true)
          : !it.installed ? HD.badge('Not installed', 'outline')
          : it.service ? (it.serviceState === 'active' ? HD.badge('Running', 'success', true) : HD.badge(it.serviceState === 'failed' ? 'Failed' : 'Stopped', 'warn', true))
          : HD.badge('Installed', 'success', true);
        return `<div class="card store-card">
          <div class="row" style="gap:12px;align-items:flex-start">
            <span class="choice-ic" style="background:${it.group === 'node' ? 'var(--node-soft);color:var(--node)' : it.group === 'php' ? 'var(--php-soft);color:var(--php)' : 'var(--accent-soft);color:var(--accent-text)'}">${icon(it.icon || 'box')}</span>
            <div class="grow"><div class="row-between" style="align-items:flex-start"><div style="font-weight:650">${esc(it.name)}</div>${st}</div>
              <div class="muted" style="font-size:13px;margin-top:2px">${it.installed && it.version ? `Version <span class="mono">${esc(it.version)}</span> · ` : ''}${esc(it.desc)}</div></div>
          </div>
          <div class="row" style="margin-top:auto;padding-top:14px;gap:8px">
            ${busy ? `<button class="btn btn-sm" data-watch="${it.job}" data-name="${esc(it.name)}">${icon('terminal', 'i-sm')}Show progress</button>`
              : !it.installed ? (conflict ? `<span class="hint">Cannot be installed next to ${esc(conflict.name)}</span>` : `<button class="btn btn-sm btn-primary" data-act="install" data-id="${it.id}" data-name="${esc(it.name)}">${icon('download', 'i-sm')}Install</button>`)
              : `${it.updatable ? `<button class="btn btn-sm" data-act="update" data-id="${it.id}" data-name="${esc(it.name)}">${icon('refresh', 'i-sm')}Update</button>` : ''}${it.core ? '<span class="hint">Required</span>' : `<button class="btn btn-sm btn-ghost" data-act="uninstall" data-id="${it.id}" data-name="${esc(it.name)}" style="color:var(--danger)">${icon('trash', 'i-sm')}Remove</button>`}`}
          </div>
        </div>`;
      };
      return `
      <div class="page-head">
        <div><h1 class="page-title">App Store</h1><p class="page-sub">${installed} of ${items.length} installed · everything comes from the official Ubuntu, Node.js, PHP (ondrej) and MongoDB sources</p></div>
        <div class="page-actions"><button class="btn" data-jobs>${icon('terminal', 'i-sm')}Recent tasks</button></div>
      </div>
      ${ORDER.filter((c) => byCat[c]).map((c) => `
        <section style="margin-bottom:28px">
          <div style="margin-bottom:12px"><h2 style="font-size:16px;font-weight:650">${c}</h2><p class="muted" style="margin:2px 0 0;font-size:13px">${DESC[c] || ''}</p></div>
          <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(290px,1fr))">${byCat[c].map(card).join('')}</div>
        </section>`).join('')}`;
    },
    mount(el) {
      const hasRunning = !!el.querySelector('[data-watch]');
      let timer = hasRunning ? setTimeout(() => HD.rerender(), 5000) : null;
      HD.pages.store._timer = timer;
      el.addEventListener('click', async (e) => {
        const t = e.target;
        const w = t.closest('[data-watch]'); if (w) { await HD.jobModal({ id: w.dataset.watch, title: w.dataset.name, status: 'running' }); return HD.rerender(); }
        if (t.closest('[data-jobs]')) {
          const jobs = await HD.api.jobs();
          HD.modal({ title: 'Recent tasks', size: 'lg', body: jobs.length ? `<div class="table-wrap"><table class="table compact"><thead><tr><th>Task</th><th>Started</th><th>Status</th><th></th></tr></thead><tbody>${jobs.map((j) => `<tr><td>${esc(j.title)}</td><td class="muted nowrap">${HD.timeAgo(j.startedAt)}</td><td>${j.status === 'success' ? HD.badge('Finished', 'success') : j.status === 'failed' ? HD.badge('Failed', 'danger') : HD.badge(j.status, 'accent')}</td><td class="actions"><button class="btn btn-sm" data-j="${j.id}">Log</button></td></tr>`).join('')}</tbody></table></div>` : HD.empty('terminal', 'No tasks yet', 'Installs, backups and other long tasks appear here.'),
            onMount(m, api) { m.addEventListener('click', (ev) => { const b = ev.target.closest('[data-j]'); if (b) { const j = jobs.find((x) => x.id === b.dataset.j); api.close(); HD.jobModal(j); } }); } });
        }
        const a = t.closest('[data-act]');
        if (a) {
          const { act, id, name } = a.dataset;
          const msg = { install: `${name} will be downloaded and installed. This can take a few minutes.`, update: `${name} will be updated to the newest release. Applications that use it are restarted.`, uninstall: `${name} will be removed. Data folders of databases are kept on disk.` }[act];
          if (!(await HD.confirm({ title: `${{ install: 'Install', update: 'Update', uninstall: 'Remove' }[act]} ${name}?`, message: msg, confirmText: { install: 'Install', update: 'Update', uninstall: 'Remove' }[act], danger: act === 'uninstall' }))) return;
          try { const r = await HD.api.storeAction(id, act); await HD.jobModal(r.job); } catch (ex) { HD.toast(ex.message, 'error'); }
          HD.rerender();
        }
      });
    },
    unmount() { clearTimeout(HD.pages.store._timer); },
  };
})();
