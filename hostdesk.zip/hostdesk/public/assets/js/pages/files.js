/* File manager */
(function () {
  const HD = window.HD; const { esc, icon } = HD;
  let q = '';
  const LANG = { js: 'JavaScript', mjs: 'JavaScript', cjs: 'JavaScript', ts: 'TypeScript', json: 'JSON', php: 'PHP', html: 'HTML', htm: 'HTML', css: 'CSS', md: 'Markdown', env: 'Env', yml: 'YAML', yaml: 'YAML', sql: 'SQL', sh: 'Shell', txt: 'Text', xml: 'XML', ini: 'INI', conf: 'Config' };
  const ext = (n) => (n.startsWith('.') && !n.slice(1).includes('.') ? n.slice(1) : n.split('.').pop()).toLowerCase();
  const isArchive = (n) => /\.(zip|tar\.gz|tgz|tar)$/i.test(n);
  const fileIcon = (f) => f.type === 'dir' ? icon('folder', 'i-sm fic-dir') : /\.(sqlite3?|db)$/i.test(f.name) ? icon('database', 'i-sm fic-file') : isArchive(f.name) ? icon('zip', 'i-sm fic-file') : /\.(js|ts|php|json|html|css|mjs|cjs|sh|sql|py)$/i.test(f.name) ? icon('fileCode', 'i-sm fic-file') : icon('file', 'i-sm fic-file');

  function askName(title, label, value = '', confirmText = 'Save') {
    return new Promise((resolve) => {
      let done = false;
      HD.modal({
        title, body: `<form class="field" novalidate><label for="nm">${esc(label)}</label><input id="nm" class="input" name="nm" value="${esc(value)}" spellcheck="false" autocomplete="off" autocapitalize="off"></form>`,
        foot: `<button class="btn" data-close>Cancel</button><button class="btn btn-primary" data-ok>${esc(confirmText)}</button>`,
        onClose: () => !done && resolve(null),
        onMount(el, m) {
          const inp = el.querySelector('input'), f = el.querySelector('form');
          setTimeout(() => { const dot = value.lastIndexOf('.'); inp.setSelectionRange(0, dot > 0 ? dot : value.length); }, 40);
          const go = () => { const v = inp.value.trim(); if (!v) return HD.fieldError(f, 'nm', 'Enter a name'); if (/[\/\\]/.test(v)) return HD.fieldError(f, 'nm', 'Name cannot contain / or \\'); done = true; resolve(v); m.close(); };
          el.querySelector('[data-ok]').addEventListener('click', go);
          f.addEventListener('submit', (e) => { e.preventDefault(); go(); });
        },
      });
    });
  }

  async function openEditor(path) {
    let file;
    try { file = await HD.api.readFile(path); } catch (e) { return HD.toast(e.message, 'error'); }
    const name = path.split('/').pop(); let dirty = false, mtime = file.mtime;
    HD.modal({
      title: name, desc: `<span class="mono">${esc(path)}</span>`, size: 'xl',
      body: `<div class="editor"><div class="gutter" aria-hidden="true"></div><textarea spellcheck="false" aria-label="File content" autocapitalize="off" autocomplete="off">${esc(file.content)}</textarea></div>
             <div class="row-between" style="margin-top:10px;font-size:12px;color:var(--muted)"><span data-pos>Line 1, column 1</span><span>${LANG[ext(name)] || 'Plain text'} · UTF-8 · <kbd>Ctrl S</kbd> saves</span></div>`,
      foot: `<button class="btn" data-close>Close</button><button class="btn btn-primary" data-save>${icon('check', 'i-sm')}Save</button>`,
      onMount(el, m) {
        const ta = el.querySelector('textarea'), gut = el.querySelector('.gutter'), pos = el.querySelector('[data-pos]');
        const lines = () => { gut.textContent = Array.from({ length: ta.value.split('\n').length }, (_, i) => i + 1).join('\n'); };
        const caret = () => { const b = ta.value.slice(0, ta.selectionStart).split('\n'); pos.textContent = `Line ${b.length}, column ${b[b.length - 1].length + 1}${dirty ? ' · unsaved' : ''}`; };
        lines();
        ta.addEventListener('input', () => { dirty = true; lines(); caret(); });
        ta.addEventListener('scroll', () => { gut.scrollTop = ta.scrollTop; });
        ta.addEventListener('click', caret); ta.addEventListener('keyup', caret);
        const save = async () => {
          try { const r = await HD.api.writeFile(path, ta.value, mtime); mtime = r.mtime; dirty = false; caret(); HD.toast(`${name} saved`); return true; }
          catch (e) { HD.toast(e.message, 'error'); return false; }
        };
        ta.addEventListener('keydown', (e) => {
          if (e.key === 'Tab') { e.preventDefault(); ta.setRangeText('  ', ta.selectionStart, ta.selectionEnd, 'end'); lines(); dirty = true; }
          if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); }
        });
        el.querySelector('[data-save]').addEventListener('click', async () => { if (await save()) { m.close(); HD.rerender(); } });
        setTimeout(() => ta.focus(), 50);
      },
      onClose: () => { if (dirty) HD.toast('Closed without saving the last changes', 'info'); },
    });
  }

  /**
   * Move or copy items to another folder. The dialog is a small folder browser:
   * pick a domain on the left, open folders, then "Move here" / "Copy here".
   */
  async function transferDialog(paths, mode = 'move') {
    const roots = await HD.api.fileRoots();
    const doms = roots.domains;
    const from = paths[0].slice(0, paths[0].lastIndexOf('/')) || '/';
    let cur = from;
    const names = paths.map((p) => p.split('/').pop());
    const m = HD.modal({
      title: paths.length === 1 ? HD.t('Move or copy {name}', { name: names[0] }) : HD.t('Move or copy {n} items', { n: paths.length }), size: 'lg',
      desc: `<span class="mono">${esc(names.slice(0, 4).join(', '))}${names.length > 4 ? ' …' : ''}</span>`,
      body: `<div class="stack">
        <div class="seg" role="group" aria-label="Action"><button type="button" data-mode="move">${icon('move', 'i-sm')}Move</button><button type="button" data-mode="copy">${icon('copy', 'i-sm')}Copy</button></div>
        <div class="picker">
          <nav class="picker-side">${doms.filter((d) => !d.parentId || !doms.some((x) => x.id === d.parentId)).map((r) => [r, ...doms.filter((d) => d.parentId === r.id)]).flat().map((d) => `<button type="button" data-root="${esc(d.folder)}" class="${d.parentId ? 'sub' : ''}">${icon(d.parentId ? 'layers' : 'globe', 'i-xs')}<span class="truncate" translate="no">${esc(d.name)}</span></button>`).join('')}</nav>
          <div class="picker-main">
            <div class="picker-path"><button type="button" class="icon-btn sm" data-up aria-label="Up one folder">${icon('chevLeft', 'i-sm')}</button><code data-cur></code></div>
            <div class="picker-list" data-list></div>
          </div>
        </div>
      </div>`,
      foot: `<button class="btn" data-close>Cancel</button><button class="btn btn-primary" data-ok></button>`,
      async onMount(el, api) {
        const setMode = (md) => { mode = md; HD.$$('[data-mode]', el).forEach((b) => b.classList.toggle('on', b.dataset.mode === md)); el.querySelector('[data-ok]').innerHTML = icon(md === 'move' ? 'move' : 'copy', 'i-sm') + HD.esc(HD.t(md === 'move' ? 'Move here' : 'Copy here')); };
        const open = async (dir) => {
          const list = el.querySelector('[data-list]');
          list.innerHTML = `<div class="muted" style="padding:14px">${HD.esc(HD.t('Loading…'))}</div>`;
          let r; try { r = await HD.api.listDir(dir); } catch (e) { list.innerHTML = `<div class="callout warn" style="margin:10px">${icon('alert', 'i-sm')}<div>${esc(e.message)}</div></div>`; return; }
          cur = r.path; el.querySelector('[data-cur]').textContent = cur;
          const top = doms.some((d) => d.folder === cur) || (HD.isAdmin() && cur === roots.wwwRoot);
          el.querySelector('[data-up]').disabled = top;
          HD.$$('[data-root]', el).forEach((b) => b.classList.toggle('on', cur === b.dataset.root || cur.startsWith(b.dataset.root + '/')));
          const dirs = r.items.filter((f) => f.type === 'dir');
          list.innerHTML = dirs.length ? dirs.map((f) => {
            const self = paths.includes(f.path);
            return `<button type="button" class="picker-item" data-dir="${esc(f.path)}" ${self ? 'disabled' : ''}>${icon('folder', 'i-sm fic-dir')}<span class="truncate" translate="no">${esc(f.name)}</span>${self ? `<span class="badge b-outline">${HD.esc(HD.t('Selected'))}</span>` : icon('chevRight', 'i-xs faint')}</button>`;
          }).join('') : `<div class="muted" style="padding:14px;font-size:13px">${HD.esc(HD.t('No folders here. Items go into this folder.'))}</div>`;
          el.querySelector('[data-ok]').disabled = mode === 'move' && cur === from;
        };
        el.addEventListener('click', (e) => {
          const md = e.target.closest('[data-mode]'); if (md) { setMode(md.dataset.mode); el.querySelector('[data-ok]').disabled = mode === 'move' && cur === from; }
          const d = e.target.closest('[data-dir]'); if (d && !d.disabled) open(d.dataset.dir);
          const r = e.target.closest('[data-root]'); if (r) open(r.dataset.root);
          if (e.target.closest('[data-up]')) open(cur.slice(0, cur.lastIndexOf('/')) || '/');
        });
        el.querySelector('[data-ok]').addEventListener('click', async (e) => {
          const b = e.currentTarget; b.disabled = true;
          try {
            await (mode === 'move' ? HD.api.move(paths, cur) : HD.api.copy(paths, cur));
            api.close();
            HD.toast(HD.t(mode === 'move' ? '{n} items moved' : '{n} items copied', { n: paths.length }));
            HD.rerender();
          } catch (ex) { HD.toast(ex.message, 'error'); b.disabled = false; }
        });
        setMode(mode); open(from);
      },
    });
    return m;
  }
  HD.transferDialog = transferDialog;

  async function uploadFiles(dir, files) {
    files = Array.from(files); if (!files.length) return;
    const total = files.reduce((s, f) => s + f.size, 0); let doneBytes = 0;
    const m = HD.modal({ title: `Uploading ${files.length} file${files.length > 1 ? 's' : ''}`, desc: `<span class="mono">${esc(dir)}</span>`, body: `<div class="stack-sm"><div class="row-between" style="font-size:13px"><span data-name class="truncate"></span><b data-pct>0%</b></div><div class="meter"><span data-bar style="width:0"></span></div></div>` });
    const set = (name, pct) => { m.el.querySelector('[data-name]').textContent = name; m.el.querySelector('[data-pct]').textContent = Math.round(pct * 100) + '%'; m.el.querySelector('[data-bar]').style.width = pct * 100 + '%'; };
    let ok = 0;
    for (const f of files) {
      try { await HD.api.upload(dir, f, (p) => set(f.name, (doneBytes + p * f.size) / (total || 1))); ok++; }
      catch (e) { HD.toast(`${f.name}: ${e.message}`, 'error'); }
      doneBytes += f.size;
    }
    m.close();
    if (ok) HD.toast(`${ok} file${ok > 1 ? 's' : ''} uploaded`);
    HD.rerender();
  }

  HD.pages.files = {
    title: 'File manager', nav: 'files',
    async render(ctx) {
      const roots = await HD.api.fileRoots();
      const doms = roots.domains;
      let path = ctx.query.path || doms[0]?.folder || roots.wwwRoot;
      if (!doms.length && !HD.isAdmin()) return `<div class="card">${HD.empty('folder', 'No folders', 'You have no domains yet.')}</div>`;
      let listing;
      try { listing = await HD.api.listDir(path); }
      catch (e) { return `<div class="card">${HD.empty('folder', 'Cannot open this folder', e.message, `<a class="btn" href="#/files">Back to files</a>`)}</div>`; }
      path = listing.path;
      const items = listing.items;
      const owner = doms.slice().sort((a, b) => b.folder.length - a.folder.length).find((d) => path === d.folder || path.startsWith(d.folder + '/'));
      const tops = doms.filter((d) => !d.parentId || !doms.some((x) => x.id === d.parentId));
      const shown = items.filter((f) => !q || f.name.toLowerCase().includes(q.toLowerCase()));
      const total = items.reduce((s, f) => s + (f.size || 0), 0);
      const minRoot = HD.isAdmin() ? roots.wwwRoot : owner?.folder || path;
      const segs = path.startsWith(minRoot) ? path.slice(minRoot.length).split('/').filter(Boolean) : [];
      let acc = minRoot;
      const crumbs = [segs.length ? `<button data-go="${esc(minRoot)}">${esc(minRoot)}</button>` : `<span class="cur">${esc(minRoot)}</span>`].concat(segs.map((s, i) => { acc += '/' + s; return i === segs.length - 1 ? `<span class="cur">${esc(s)}</span>` : `<button data-go="${esc(acc)}">${esc(s)}</button>`; }));
      const parent = path !== minRoot ? path.slice(0, path.lastIndexOf('/')) || '/' : null;

      return `
      <div class="page-head">
        <div><h1 class="page-title">File manager</h1><p class="page-sub">Every domain and subdomain has its own folder</p></div>
        <div class="page-actions">
          <button class="btn" data-mkdir>${icon('folderPlus', 'i-sm')}New folder</button>
          <button class="btn" data-mkfile>${icon('filePlus', 'i-sm')}New file</button>
          <label class="btn btn-primary" style="cursor:pointer">${icon('upload', 'i-sm')}Upload<input type="file" multiple hidden data-upload></label>
        </div>
      </div>
      <div class="grid g-side" style="align-items:start">
        <nav class="card ftree" aria-label="Domain folders">
          ${tops.length ? tops.map((r) => {
            const subs = doms.filter((d) => d.parentId === r.id);
            const link = (d) => `<a href="#/files?path=${encodeURIComponent(d.folder)}" class="${owner?.id === d.id ? 'on' : ''}">${icon('folder', 'i-sm')}<span class="truncate">${esc(d.name)}</span></a>`;
            return `<div class="grp">${icon('globe', 'i-xs')}${esc(r.name)}</div>${link(r)}${subs.map(link).join('')}`;
          }).join('') : '<div class="muted" style="padding:12px;font-size:13px">No domains yet.</div>'}
        </nav>
        <section class="card" data-drop>
          <div class="card-head" style="flex-wrap:wrap">
            <div class="row" style="min-width:0;gap:4px">
              ${parent ? `<button class="icon-btn sm" data-go="${esc(parent)}" aria-label="Up one folder" title="Up">${icon('chevLeft', 'i-sm')}</button>` : ''}
              <div class="pathbar">${crumbs.join('<span class="faint">/</span>')}</div>
              <button class="icon-btn sm" data-copy="${esc(path)}" aria-label="Copy path" title="Copy path">${icon('copy', 'i-xs')}</button>
            </div>
            <div class="row">
              ${owner ? `<a class="btn btn-sm btn-ghost" href="#/domains/${encodeURIComponent(owner.name)}">${icon('globe', 'i-sm')}${esc(owner.name)}</a>` : ''}
              <div class="input-icon" style="width:190px">${icon('search', 'i-sm')}<input class="input" style="height:34px" type="search" placeholder="Filter" value="${esc(q)}" data-q aria-label="Filter files"></div>
            </div>
          </div>
          <div class="row-between wrap" data-bulk hidden style="padding:10px 20px;background:var(--accent-soft);border-bottom:1px solid var(--border-2)">
            <span style="font-weight:500" data-selcount></span>
            <div class="row wrap"><button class="btn btn-sm" data-unsel>Clear</button><button class="btn btn-sm" data-movesel>${icon('move', 'i-sm')}Move</button><button class="btn btn-sm" data-copysel>${icon('copy', 'i-sm')}Copy</button><button class="btn btn-sm" data-zipsel>${icon('zip', 'i-sm')}Compress</button><button class="btn btn-sm btn-danger" data-delsel>${icon('trash', 'i-sm')}Delete</button></div>
          </div>
          ${shown.length ? `<div class="table-wrap"><table class="table">
            <thead><tr><th style="width:36px;padding-right:0"><input type="checkbox" data-all aria-label="Select all" style="accent-color:var(--accent)"></th><th>Name</th><th>Size</th><th>Modified</th><th>Mode</th><th><span class="sr-only">Actions</span></th></tr></thead>
            <tbody>${shown.map((f) => `
              <tr draggable="true" data-row="${esc(f.path)}" ${f.type === 'dir' ? `data-dropdir="${esc(f.path)}"` : ''}>
                <td style="padding-right:0"><input type="checkbox" data-sel="${esc(f.path)}" aria-label="Select ${esc(f.name)}" style="accent-color:var(--accent)"></td>
                <td><button class="fname" data-open="${esc(f.path)}" data-type="${f.type}">${fileIcon(f)}<span>${esc(f.name)}</span>${f.link ? '<span class="badge b-outline" style="height:18px">link</span>' : ''}</button></td>
                <td class="muted nowrap">${f.type === 'dir' ? '—' : HD.fmtBytes(f.size)}</td>
                <td class="muted nowrap" title="${esc(HD.fmtDateTime(f.mtime))}">${HD.timeAgo(f.mtime)}</td>
                <td class="mono muted">${esc(f.mode)}</td>
                <td class="actions">
                  ${f.type === 'file' && f.size < 2097152 ? `<button class="icon-btn" data-edit="${esc(f.path)}" title="Edit" aria-label="Edit ${esc(f.name)}">${icon('edit', 'i-sm')}</button>` : ''}
                  ${f.type === 'file' && isArchive(f.name) ? `<button class="icon-btn" data-extract="${esc(f.path)}" title="Extract here" aria-label="Extract ${esc(f.name)}">${icon('zip', 'i-sm')}</button>` : ''}
                  <button class="icon-btn" data-rename="${esc(f.path)}" data-name="${esc(f.name)}" title="Rename" aria-label="Rename ${esc(f.name)}">${icon('text', 'i-sm')}</button>
                  <button class="icon-btn" data-transfer="${esc(f.path)}" title="Move or copy" aria-label="Move or copy ${esc(f.name)}">${icon('move', 'i-sm')}</button>
                  ${f.type === 'file' ? `<a class="icon-btn" href="${HD.api.downloadUrl(f.path)}" download title="Download" aria-label="Download ${esc(f.name)}">${icon('download', 'i-sm')}</a>` : ''}
                  <button class="icon-btn danger" data-delete="${esc(f.path)}" data-name="${esc(f.name)}" title="Delete" aria-label="Delete ${esc(f.name)}">${icon('trash', 'i-sm')}</button>
                </td>
              </tr>`).join('')}</tbody></table></div>`
            : HD.empty('folder', q ? 'No matches' : 'This folder is empty', q ? 'Try another filter.' : 'Upload files or drop them below.')}
          <div class="card-body" style="padding-top:12px">
            <div class="dropzone" data-zone role="button" tabindex="0">${icon('upload', 'i-lg')}<b style="color:var(--text)">Drop files or a .zip here</b><span style="font-size:12.5px"><span>Uploaded into</span> <span class="mono">${esc(path)}</span> · <span>${HD.t('{n} items', { n: items.length })}</span> · ${HD.fmtBytes(total)}</span><span class="hint" style="margin:0">Drag files onto a folder to move them (hold Ctrl to copy).</span></div>
          </div>
        </section>
      </div>`;
    },
    mount(el, ctx) {
      const curDir = async () => (await HD.api.listDir(ctx.query.path || (await HD.api.fileRoots()).domains[0]?.folder)).path;
      const go = (p) => { q = ''; HD.go('/files?path=' + encodeURIComponent(p)); };
      const sel = () => HD.$$('[data-sel]:checked', el).map((c) => c.dataset.sel);
      const syncBulk = () => { const n = sel().length; const b = el.querySelector('[data-bulk]'); if (b) { b.hidden = !n; el.querySelector('[data-selcount]').textContent = `${n} selected`; } };
      el.querySelector('[data-upload]')?.addEventListener('change', async (e) => uploadFiles(await curDir(), e.target.files));
      const qi = el.querySelector('[data-q]');
      qi?.addEventListener('input', HD.debounce(async () => { q = qi.value; const pos = qi.selectionStart; await HD.rerender(); const n = document.querySelector('[data-q]'); n?.focus(); n?.setSelectionRange(pos, pos); }, 200));
      const drop = el.querySelector('[data-drop]'), zone = el.querySelector('[data-zone]');
      const MIME = 'application/x-hostdesk-paths';
      const internal = (e) => Array.from(e.dataTransfer?.types || []).includes(MIME);
      // Drag rows onto a folder (in the list, the path bar or the domain tree) to move them
      el.addEventListener('dragstart', (e) => {
        const row = e.target.closest('[data-row]'); if (!row) return;
        const picked = sel(); const paths = picked.includes(row.dataset.row) ? picked : [row.dataset.row];
        e.dataTransfer.setData(MIME, JSON.stringify(paths)); e.dataTransfer.effectAllowed = 'copyMove';
      });
      const targetOf = (e) => e.target.closest('[data-dropdir], .pathbar [data-go], .ftree a');
      const targetPath = (t) => t.dataset.dropdir || t.dataset.go || decodeURIComponent((t.getAttribute('href') || '').split('path=')[1] || '');
      el.addEventListener('dragover', (e) => { if (!internal(e)) return; const t = targetOf(e); HD.$$('.drop-on', el).forEach((x) => x !== t && x.classList.remove('drop-on')); if (t) { e.preventDefault(); e.dataTransfer.dropEffect = e.ctrlKey || e.altKey ? 'copy' : 'move'; t.classList.add('drop-on'); } });
      el.addEventListener('dragleave', (e) => { const t = targetOf(e); if (t && !t.contains(e.relatedTarget)) t.classList.remove('drop-on'); });
      el.addEventListener('drop', async (e) => {
        if (!internal(e)) return;
        e.preventDefault(); e.stopPropagation();
        const t = targetOf(e); HD.$$('.drop-on', el).forEach((x) => x.classList.remove('drop-on')); zone?.classList.remove('drag');
        if (!t) return;
        const paths = JSON.parse(e.dataTransfer.getData(MIME) || '[]'); const dest = targetPath(t);
        if (!paths.length || !dest || paths.includes(dest)) return;
        const copy = e.ctrlKey || e.altKey;
        try { await (copy ? HD.api.copy(paths, dest) : HD.api.move(paths, dest)); HD.toast(HD.t(copy ? '{n} items copied' : '{n} items moved', { n: paths.length })); HD.rerender(); }
        catch (ex) { HD.toast(ex.message, 'error'); }
      }, true);
      if (drop) {
        ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { if (internal(e)) return; e.preventDefault(); zone.classList.add('drag'); }));
        ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { if (internal(e)) return; e.preventDefault(); if (ev === 'drop' || !drop.contains(e.relatedTarget)) zone.classList.remove('drag'); }));
        drop.addEventListener('drop', async (e) => { if (internal(e) || !e.dataTransfer.files.length) return; uploadFiles(await curDir(), e.dataTransfer.files); });
        zone.addEventListener('click', () => el.querySelector('[data-upload]').click());
        zone.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.querySelector('[data-upload]').click(); } });
      }
      el.addEventListener('change', (e) => {
        if (e.target.matches('[data-all]')) { HD.$$('[data-sel]', el).forEach((c) => (c.checked = e.target.checked)); syncBulk(); }
        if (e.target.matches('[data-sel]')) syncBulk();
      });
      el.addEventListener('click', async (e) => {
        const t = e.target;
        const g = t.closest('[data-go]'); if (g) return go(g.dataset.go);
        const cp = t.closest('[data-copy]'); if (cp) return HD.copy(cp.dataset.copy);
        const o = t.closest('[data-open]');
        if (o) {
          if (o.dataset.type === 'dir') return go(o.dataset.open);
          if (/\.(sqlite3?|db)$/i.test(o.dataset.open)) { const dbs = await HD.api.listDatabases(); const d = dbs.find((x) => x.path === o.dataset.open); if (d) return HD.go('/databases/' + d.id); }
          return openEditor(o.dataset.open);
        }
        const ed = t.closest('[data-edit]'); if (ed) return openEditor(ed.dataset.edit);
        const run = async (fn, okMsg) => { try { await fn(); if (okMsg) HD.toast(okMsg); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); } };
        if (t.closest('[data-mkdir]')) { const n = await askName('New folder', 'Folder name', '', 'Create'); if (n) run(async () => HD.api.mkdir(await curDir(), n), `Folder ${n} created`); }
        if (t.closest('[data-mkfile]')) { const n = await askName('New file', 'File name', 'index.html', 'Create'); if (n) { try { const r = await HD.api.createFile(await curDir(), n); await HD.rerender(); openEditor(r.path); } catch (ex) { HD.toast(ex.message, 'error'); } } }
        const rn = t.closest('[data-rename]'); if (rn) { const n = await askName('Rename', 'New name', rn.dataset.name, 'Rename'); if (n && n !== rn.dataset.name) run(() => HD.api.rename(rn.dataset.rename, n), 'Renamed'); }
        const ex = t.closest('[data-extract]'); if (ex) { ex.disabled = true; HD.toast('Extracting…', 'info'); run(() => HD.api.extract(ex.dataset.extract), 'Extracted'); }
        const del = t.closest('[data-delete]'); if (del && (await HD.confirm({ title: `Delete ${del.dataset.name}?`, message: 'This cannot be undone.', confirmText: 'Delete' }))) run(() => HD.api.remove(del.dataset.delete), `${del.dataset.name} deleted`);
        if (t.closest('[data-unsel]')) { HD.$$('[data-sel],[data-all]', el).forEach((c) => (c.checked = false)); syncBulk(); }
        const tr = t.closest('[data-transfer]'); if (tr) return transferDialog([tr.dataset.transfer], 'move');
        if (t.closest('[data-movesel]')) return transferDialog(sel(), 'move');
        if (t.closest('[data-copysel]')) return transferDialog(sel(), 'copy');
        if (t.closest('[data-zipsel]')) { const s = sel(); const n = await askName('Compress to .zip', 'Archive name', 'archive.zip', 'Compress'); if (n) run(() => HD.api.compress(s, n), 'Archive created'); }
        if (t.closest('[data-delsel]')) { const s = sel(); if (await HD.confirm({ title: `Delete ${s.length} items?`, message: 'This cannot be undone.', confirmText: 'Delete' })) run(() => HD.api.remove(s), `${s.length} items deleted`); }
      });
    },
  };
})();
