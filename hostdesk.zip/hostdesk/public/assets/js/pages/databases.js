/* Databases — SQLite, MySQL/MariaDB, PostgreSQL, MongoDB */
(function () {
  const HD = window.HD; const { esc, icon } = HD;
  const ENG = {
    sqlite: { label: 'SQLite', color: '#0E7490', hint: 'A file inside the site folder. No server needed.', store: null },
    mysql: { label: 'MySQL / MariaDB', color: '#B45309', hint: 'Server database on 127.0.0.1:3306', store: 'mariadb' },
    postgres: { label: 'PostgreSQL', color: '#3E4784', hint: 'Server database on 127.0.0.1:5432', store: 'postgresql' },
    mongodb: { label: 'MongoDB', color: '#15803D', hint: 'Document database on 127.0.0.1:27017', store: 'mongodb' },
  };
  const engBadge = (e) => `<span class="badge" style="background:color-mix(in srgb, ${ENG[e].color} 12%, transparent);color:color-mix(in srgb, ${ENG[e].color} 80%, var(--text))">${esc(ENG[e].label)}</span>`;
  const engIc = (e) => `<span class="svc-ic" style="background:color-mix(in srgb, ${ENG[e].color} 12%, transparent);color:${ENG[e].color}">${icon('database', 'i-sm')}</span>`;
  const isSql = (e) => e !== 'mongodb';

  function credentialsModal(db, title = 'Database created') {
    const c = db.connection || {};
    if (db.engine === 'sqlite') { HD.toast(`${db.name} created`); return HD.go('/databases/' + db.id); }
    const envName = { mysql: 'DATABASE_URL', postgres: 'DATABASE_URL', mongodb: 'MONGODB_URI' }[db.engine];
    HD.modal({
      title, desc: 'Save these details. You can see them again on the database page.', size: 'lg',
      body: `<div class="stack">${[['Host', c.host], ['Port', c.port], ['Database', c.database], ['User', c.user], ['Password', c.password]].map(([k, v]) => `
        <div class="row" style="gap:12px"><span class="muted" style="width:90px;flex:none">${k}</span><div class="copy-row grow"><code>${esc(v)}</code><button class="icon-btn sm" data-cp="${esc(v)}" aria-label="Copy ${k}">${icon('copy', 'i-xs')}</button></div></div>`).join('')}
        <div class="field"><span class="label">For your .env file</span><div class="copy-row"><code>${envName}=${esc(c.url)}</code><button class="icon-btn sm" data-cp="${esc(envName + '=' + c.url)}" aria-label="Copy">${icon('copy', 'i-xs')}</button></div></div></div>`,
      foot: `<button class="btn btn-primary" data-close>Done</button>`,
      onMount(el) { el.addEventListener('click', (e) => { const b = e.target.closest('[data-cp]'); if (b) HD.copy(b.dataset.cp); }); },
      onClose: (reason) => { if (reason !== 'route') HD.go('/databases/' + db.id); },
    });
  }

  HD.openNewDatabase = async (domainId, engine) => {
    const [domains, engines] = await Promise.all([HD.api.listDomains(), HD.api.dbEngines()]);
    if (!domains.length) return HD.toast('Add a domain first', 'error');
    const ready = (id) => { const e = engines.find((x) => x.id === id); return e && e.installed && e.running; };
    let eng = engine && ready(engine) ? engine : 'sqlite';
    HD.modal({
      title: 'New database', size: 'lg',
      body: `<form class="stack" novalidate>
        <div class="choice-grid">${engines.map((e) => `
          <button type="button" class="choice" data-eng="${e.id}" ${e.installed && e.running ? '' : 'disabled style="opacity:.55"'}>
            ${engIc(e.id)}<span><span class="ttl">${esc(ENG[e.id].label)}</span><br><span class="dsc">${!e.installed ? 'Not installed — App Store' : !e.running ? 'Not running' : esc(ENG[e.id].hint)}</span></span>
          </button>`).join('')}</div>
        <div class="form-grid">
          <div class="field"><label for="ndd">Domain</label><select id="ndd" class="select" name="domainId">${domains.map((d) => `<option value="${d.id}" ${d.id === domainId ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select></div>
          <div class="field"><label for="ndn" data-namelabel>Name</label><input id="ndn" class="input" name="name" spellcheck="false" autocomplete="off" autocapitalize="off"><span class="hint mono" data-hint></span></div>
          <div class="field" data-server><label for="ndu">User</label><input id="ndu" class="input" name="dbUser" spellcheck="false" autocomplete="off" autocapitalize="off"><span class="hint">A user that can use only this database</span></div>
          <div class="field" data-server><label for="ndp">Password</label><div class="input-group"><input id="ndp" class="input mono" name="password" autocomplete="new-password" spellcheck="false"><button type="button" class="btn addon" data-gen style="height:40px;box-shadow:none">${icon('wand', 'i-sm')}New</button></div></div>
        </div>
      </form>`,
      foot: `<button class="btn" data-close>Cancel</button><button class="btn btn-primary" data-ok>Create database</button>`,
      onMount(el, m) {
        const f = el.querySelector('form'); let userTouched = false;
        const gen = () => { f.querySelector('[name=password]').value = Array.from(crypto.getRandomValues(new Uint8Array(20))).map((b) => 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 56]).join(''); };
        const upd = () => {
          const d = HD.formData(f); const dom = domains.find((x) => x.id === d.domainId);
          HD.$$('[data-eng]', el).forEach((b) => b.classList.toggle('on', b.dataset.eng === eng));
          HD.$$('[data-server]', el).forEach((x) => (x.hidden = eng === 'sqlite'));
          el.querySelector('[data-namelabel]').textContent = eng === 'sqlite' ? 'File name' : 'Database name';
          el.querySelector('[data-hint]').textContent = eng === 'sqlite' ? `${dom?.folder}/data/${(d.name || 'app').replace(/\.sqlite$/, '')}.sqlite` : 'Letters, numbers and _ · start with a letter';
          if (!userTouched && eng !== 'sqlite') f.querySelector('[name=dbUser]').value = (d.name || '').slice(0, 32);
        };
        f.querySelector('[name=dbUser]').addEventListener('input', () => (userTouched = true));
        el.addEventListener('click', (e) => { const b = e.target.closest('[data-eng]'); if (b && !b.disabled) { eng = b.dataset.eng; upd(); } if (e.target.closest('[data-gen]')) gen(); });
        f.addEventListener('input', upd); f.addEventListener('change', upd);
        gen(); upd(); setTimeout(() => f.querySelector('[name=name]').focus(), 30);
        const go = async () => {
          const d = HD.formData(f); if (!d.name) return HD.fieldError(f, 'name', 'Enter a name');
          const btn = el.querySelector('[data-ok]'); btn.disabled = true; btn.textContent = 'Creating…';
          try { const db = await HD.api.createDatabase({ engine: eng, domainId: d.domainId, name: d.name, dbUser: d.dbUser, password: d.password }); m.close(); credentialsModal(db); }
          catch (ex) { btn.disabled = false; btn.textContent = 'Create database'; HD.fieldError(f, /user/i.test(ex.message) ? 'dbUser' : /password/i.test(ex.message) ? 'password' : 'name', ex.message); }
        };
        el.querySelector('[data-ok]').addEventListener('click', go);
        f.addEventListener('submit', (e) => { e.preventDefault(); go(); });
      },
    });
  };

  /* ---------- List ---------- */
  let engFilter = 'all';
  HD.pages.databases = {
    title: 'Databases', nav: 'databases',
    async render() {
      const [dbs, engines] = await Promise.all([HD.api.listDatabases(), HD.api.dbEngines()]);
      const admin = HD.isAdmin();
      const rows = dbs.filter((d) => engFilter === 'all' || d.engine === engFilter);
      return `
      <div class="page-head">
        <div><h1 class="page-title">Databases</h1><p class="page-sub">${dbs.length} database${dbs.length === 1 ? '' : 's'} · SQLite, MySQL / MariaDB, PostgreSQL and MongoDB</p></div>
        <div class="page-actions"><button class="btn" data-scan>${icon('refresh', 'i-sm')}Find SQLite files</button><button class="btn btn-primary" data-new>${icon('plus', 'i-sm')}New database</button></div>
      </div>
      <section class="grid g-4">${engines.map((e) => {
        const n = dbs.filter((d) => d.engine === e.id).length;
        const status = !e.installed ? HD.badge('Not installed', '') : e.running ? HD.badge('Running', 'success', true) : HD.badge('Stopped', 'warn', true);
        return `<div class="card stat" style="gap:10px">
          <div class="stat-top">${engIc(e.id)}${status}</div>
          <div><div style="font-weight:650">${esc(ENG[e.id].label)}</div><div class="muted" style="font-size:12.5px">${e.installed ? `${e.version ? 'Version ' + esc(e.version) + ' · ' : ''}${n} database${n === 1 ? '' : 's'}` : esc(ENG[e.id].hint)}</div></div>
          ${!e.installed ? (admin ? `<a class="btn btn-sm" href="#/store">${icon('download', 'i-sm')}Install</a>` : '') : e.running ? `<button class="btn btn-sm" data-newin="${e.id}">${icon('plus', 'i-sm')}New</button>` : admin ? `<a class="btn btn-sm" href="#/dashboard">Start it from Services</a>` : ''}
        </div>`;
      }).join('')}</section>
      <div class="pill-tabs mt-lg" style="margin-bottom:16px">${['all', 'sqlite', 'mysql', 'postgres', 'mongodb'].map((k) => `<button class="${engFilter === k ? 'on' : ''}" data-f="${k}">${k === 'all' ? 'All' : ENG[k].label} <span style="opacity:.7">${k === 'all' ? dbs.length : dbs.filter((d) => d.engine === k).length}</span></button>`).join('')}</div>
      <section class="card">
        ${rows.length ? `<div class="table-wrap"><table class="table">
          <thead><tr><th>Database</th><th>Type</th><th>Domain</th><th>User</th><th>Size</th><th><span class="sr-only">Actions</span></th></tr></thead>
          <tbody>${rows.map((d) => `
            <tr>
              <td><div class="row" style="gap:12px">${engIc(d.engine)}<div style="min-width:0"><a class="cell-title" href="#/databases/${d.id}">${esc(d.name)}</a>${d.path ? `<div class="cell-sub mono truncate" style="max-width:340px">${esc(d.path)}</div>` : ''}</div></div></td>
              <td>${engBadge(d.engine)}</td>
              <td>${d.domain ? `<a href="#/domains/${encodeURIComponent(d.domain)}">${esc(d.domain)}</a>` : '<span class="muted">—</span>'}</td>
              <td class="mono">${d.user ? esc(d.user) : '<span class="muted">—</span>'}</td>
              <td class="muted nowrap">${d.size != null ? HD.fmtBytes(d.size) : '—'}</td>
              <td class="actions">
                <a class="icon-btn" href="#/databases/${d.id}" title="Open" aria-label="Open ${esc(d.name)}">${icon('eye', 'i-sm')}</a>
                <a class="icon-btn" href="${HD.api.dbExportUrl(d.id)}" download title="Export" aria-label="Export ${esc(d.name)}">${icon('download', 'i-sm')}</a>
                <button class="icon-btn danger" data-del="${d.id}" data-name="${esc(d.name)}" title="Delete" aria-label="Delete ${esc(d.name)}">${icon('trash', 'i-sm')}</button>
              </td>
            </tr>`).join('')}</tbody></table></div>`
          : HD.empty('database', 'No databases here', 'Create one. SQLite files inside your domain folders are found automatically.', `<button class="btn btn-primary" data-new>${icon('plus', 'i-sm')}New database</button>`)}
      </section>`;
    },
    mount(el) {
      el.addEventListener('click', async (e) => {
        const t = e.target;
        if (t.closest('[data-new]')) HD.openNewDatabase();
        const ni = t.closest('[data-newin]'); if (ni) HD.openNewDatabase(null, ni.dataset.newin);
        const f = t.closest('[data-f]'); if (f) { engFilter = f.dataset.f; HD.rerender(); }
        if (t.closest('[data-scan]')) { try { const r = await HD.api.scanDatabases(); HD.toast(`Found ${r.filter((d) => d.engine === 'sqlite').length} SQLite files`, 'info'); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); } }
        const del = t.closest('[data-del]');
        if (del && (await HD.confirm({ title: `Delete ${del.dataset.name}?`, message: 'The database and all its data are removed. Export it first if you need the data.', confirmText: 'Delete database' }))) {
          try { await HD.api.deleteDatabase(del.dataset.del); HD.toast('Database deleted'); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); }
        }
      });
    },
  };

  /* ---------- Browser ---------- */
  const lastQuery = {};
  HD.pages.database = {
    title: 'Database', nav: 'databases',
    async render(ctx) {
      let db;
      try { db = await HD.api.getDatabase(ctx.params.id); }
      catch (e) { return `<nav class="crumbs"><a href="#/databases">Databases</a></nav><div class="card">${HD.empty('database', 'Cannot open this database', e.message, `<a class="btn" href="#/databases">Back to databases</a>`)}</div>`; }
      const sql = isSql(db.engine);
      const table = ctx.query.table && db.tables.some((t) => t.name === ctx.query.table) ? ctx.query.table : db.tables[0]?.name;
      const view = ctx.query.view || 'data';
      const page = Math.max(0, +(ctx.query.page || 0)), per = 50;
      const link = (p) => `#/databases/${db.id}?${new URLSearchParams({ table: table || '', view, ...p })}`;
      const unit = sql ? 'table' : 'collection';
      let main = '';
      if (view === 'query') {
        main = sql ? `<div class="card-body stack">
            <div class="field"><label for="sql">SQL</label><textarea id="sql" class="textarea mono" rows="6" data-sql spellcheck="false">${esc(lastQuery[db.id] || (table ? `SELECT * FROM ${db.engine === 'mysql' ? '`' + table + '`' : db.engine === 'postgres' ? table.split('.').map((x) => '"' + x + '"').join('.') : '"' + table + '"'} LIMIT 50;` : ''))}</textarea><span class="hint">Runs ${db.engine === 'sqlite' ? 'on the file directly' : `as user ${esc(db.user)}`}. <kbd>Ctrl Enter</kbd> runs it.</span></div>
            <div class="row-between"><span></span><button class="btn btn-primary" data-run>${icon('play', 'i-sm')}Run query</button></div>
            <div data-result></div></div>`
          : `<div class="card-body stack">
            <div class="form-grid">
              <div class="field"><label for="mc">Collection</label><select id="mc" class="select" data-mc>${db.tables.map((t) => `<option ${t.name === table ? 'selected' : ''}>${esc(t.name)}</option>`).join('')}</select></div>
              <div class="field"><label for="ml">Limit</label><input id="ml" class="input" data-ml value="50" inputmode="numeric"></div>
              <div class="field"><label for="mf">Filter (JSON)</label><input id="mf" class="input mono" data-mf value="{}" spellcheck="false"></div>
              <div class="field"><label for="ms">Sort (JSON)</label><input id="ms" class="input mono" data-ms value='{ "_id": -1 }' spellcheck="false"></div>
            </div>
            <div class="row-between"><span class="hint">Example filter: { "status": "active" }</span><button class="btn btn-primary" data-run ${db.tables.length ? '' : 'disabled'}>${icon('play', 'i-sm')}Find</button></div>
            <div data-result></div></div>`;
      } else if (!db.tables.length) main = HD.empty('database', `No ${unit}s yet`, sql ? 'Create tables with the Query tab or from your application.' : 'Collections appear when your application writes data.');
      else if (view === 'data') {
        let r; try { r = await HD.api.tableRows(db.id, table, page * per, per); } catch (e) { r = { cols: [], rows: [], total: 0, error: e.message }; }
        const pages = Math.max(1, Math.ceil(r.total / per));
        main = r.error ? `<div class="card-body"><div class="callout warn">${icon('alert', 'i-sm')}<div>${esc(r.error)}</div></div></div>` : r.rows.length ? `<div class="table-wrap"><table class="table compact"><thead><tr>${r.cols.map((c) => `<th class="mono">${esc(c)}</th>`).join('')}</tr></thead>
          <tbody>${r.rows.map((row) => `<tr>${row.map((v) => `<td class="nowrap ${v === null ? 'faint' : ''}" style="max-width:340px;overflow:hidden;text-overflow:ellipsis" title="${esc(v)}">${v === null ? 'NULL' : esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
          <div class="card-foot" style="justify-content:space-between"><span class="muted" style="font-size:13px">${HD.fmtNum(page * per + 1)}–${HD.fmtNum(Math.min(r.total, page * per + per))} of ${HD.fmtNum(r.total)}</span>
          <div class="row"><a class="btn btn-sm" ${page <= 0 ? 'aria-disabled="true" style="pointer-events:none;opacity:.5"' : `href="${link({ page: page - 1 })}"`}>${icon('chevLeft', 'i-sm')}Previous</a><a class="btn btn-sm" ${page >= pages - 1 ? 'aria-disabled="true" style="pointer-events:none;opacity:.5"' : `href="${link({ page: page + 1 })}"`}>Next${icon('chevRight', 'i-sm')}</a></div></div>`
          : HD.empty('layers', 'Empty', `This ${unit} has no rows.`);
      } else {
        let s; try { s = await HD.api.tableSchema(db.id, table); } catch (e) { s = { columns: [], create: '', error: e.message }; }
        main = `<div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>${sql ? 'Column' : 'Field'}</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr></thead>
          <tbody>${s.columns.map((c, i) => `<tr><td class="muted">${i + 1}</td><td class="mono cell-title">${esc(c.name)}</td><td class="mono">${esc(c.type)}</td><td>${c.nullable ? 'Yes' : 'No'}</td><td>${c.key ? HD.badge(c.key, 'accent') : ''}</td><td class="mono muted">${c.default == null ? '' : esc(c.default)}</td></tr>`).join('')}</tbody></table></div>
          ${s.create ? `<div class="card-body"><div class="label" style="margin-bottom:8px">Create statement</div><pre class="code">${esc(s.create)}</pre></div>` : ''}${!sql ? '<div class="card-body hint">Fields are read from the first 50 documents.</div>' : ''}`;
      }
      const c = db.connection || {};
      return `
      <nav class="crumbs"><a href="#/databases">Databases</a>${db.domain ? `<span class="sep">/</span><a href="#/domains/${encodeURIComponent(db.domain)}">${esc(db.domain)}</a>` : ''}<span class="sep">/</span><span style="color:var(--text)">${esc(db.name)}</span></nav>
      <div class="page-head">
        <div class="row" style="gap:14px"><span class="svc-ic" style="width:48px;height:48px;border-radius:12px;background:color-mix(in srgb, ${ENG[db.engine].color} 12%, transparent);color:${ENG[db.engine].color}">${icon('database', 'i-lg')}</span>
          <div><div class="row wrap" style="gap:10px"><h1 class="page-title">${esc(db.name)}</h1>${engBadge(db.engine)}</div><p class="page-sub" style="margin-top:2px">${db.tables.length} ${unit}${db.tables.length === 1 ? '' : 's'} · ${db.size != null ? HD.fmtBytes(db.size) : 'size unknown'}</p></div></div>
        <div class="page-actions">
          <a class="btn" href="${HD.api.dbExportUrl(db.id)}" download>${icon('download', 'i-sm')}Export</a>
          ${db.engine !== 'sqlite' ? `<button class="btn" data-reset>${icon('key', 'i-sm')}New password</button>` : ''}
          <button class="btn btn-danger" data-del>${icon('trash', 'i-sm')}Delete</button>
        </div>
      </div>
      ${db.engine === 'sqlite' ? `<div class="copy-row" style="margin-bottom:16px">${icon('file', 'i-sm fic-file')}<code>${esc(c.file)}</code><button class="icon-btn sm" data-cp="${esc(c.file)}" aria-label="Copy path">${icon('copy', 'i-xs')}</button></div>` : `
      <section class="card" style="margin-bottom:16px"><div class="card-body" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px 20px">
        ${[['Host', c.host], ['Port', c.port], ['Database', c.database], ['User', c.user]].map(([k, v]) => `<div><div class="muted" style="font-size:12px">${k}</div><div class="row" style="gap:4px"><span class="mono" style="font-weight:600">${esc(v)}</span><button class="icon-btn sm" data-cp="${esc(v)}" aria-label="Copy ${k}">${icon('copy', 'i-xs')}</button></div></div>`).join('')}
        <div><div class="muted" style="font-size:12px">Password</div><div class="row" style="gap:4px"><span class="mono" style="font-weight:600" data-pw>••••••••••</span><button class="icon-btn sm" data-reveal aria-label="Show password">${icon('eye', 'i-xs')}</button><button class="icon-btn sm" data-cp="${esc(c.password)}" aria-label="Copy password">${icon('copy', 'i-xs')}</button></div></div>
        <div style="grid-column:1/-1"><div class="copy-row"><code>${db.engine === 'mongodb' ? 'MONGODB_URI' : 'DATABASE_URL'}=${esc(c.url).replace(esc(c.password), '••••••••')}</code><button class="icon-btn sm" data-cp="${esc((db.engine === 'mongodb' ? 'MONGODB_URI=' : 'DATABASE_URL=') + c.url)}" aria-label="Copy connection string">${icon('copy', 'i-xs')}</button></div></div>
      </div></section>`}
      <div class="grid g-side" style="align-items:start">
        <nav class="card tlist" style="padding:8px" aria-label="${unit}s">
          <div class="label" style="padding:8px 12px">${sql ? 'Tables' : 'Collections'} · ${db.tables.length}</div>
          ${db.tables.map((x) => `<a href="#/databases/${db.id}?${new URLSearchParams({ table: x.name, view: view === 'query' ? 'data' : view })}" class="${x.name === table && view !== 'query' ? 'on' : ''}" title="${esc(x.name)}"><span class="truncate">${esc(x.name)}</span><span class="n">${x.rows != null ? HD.fmtNum(x.rows) : ''}</span></a>`).join('') || '<div class="muted" style="padding:8px 12px;font-size:13px">None yet</div>'}
        </nav>
        <section class="card" style="overflow:hidden">
          <div class="card-head" style="padding-top:0;padding-bottom:0;min-height:52px">
            <nav class="tabs" style="margin:0;border:none">
              <a href="${link({ view: 'data' })}" class="${view === 'data' ? 'on' : ''}">${icon('layers', 'i-sm')}Data</a>
              <a href="${link({ view: 'schema' })}" class="${view === 'schema' ? 'on' : ''}">${icon('code', 'i-sm')}Structure</a>
              <a href="${link({ view: 'query' })}" class="${view === 'query' ? 'on' : ''}">${icon('terminal', 'i-sm')}${sql ? 'SQL' : 'Find'}</a>
            </nav>
            ${table && view !== 'query' ? `<span class="mono muted truncate" style="font-size:12.5px">${esc(table)}</span>` : ''}
          </div>
          ${main}
        </section>
      </div>`;
    },
    mount(el, ctx) {
      const id = ctx.params.id;
      const ta = el.querySelector('[data-sql]');
      const show = (r) => {
        const out = el.querySelector('[data-result]');
        out.innerHTML = r.cols && r.cols.length
          ? `<div class="row-between" style="margin-bottom:8px"><span class="label">${r.rows.length} rows${r.truncated ? ' (first 1000)' : ''}${r.message ? ' · ' + esc(r.message) : ''}</span><span class="muted" style="font-size:12.5px">${r.ms} ms</span></div><div class="table-wrap card" style="box-shadow:none"><table class="table compact"><thead><tr>${r.cols.map((c) => `<th class="mono">${esc(c)}</th>`).join('')}</tr></thead><tbody>${r.rows.map((row) => `<tr>${row.map((v) => `<td class="nowrap" style="max-width:340px;overflow:hidden;text-overflow:ellipsis" title="${esc(v)}">${v === null ? '<span class="faint">NULL</span>' : esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`
          : `<div class="callout">${icon('checkCircle', 'i-sm')}<div>${esc(r.message || 'Done')} · ${r.ms} ms</div></div>`;
      };
      const run = async () => {
        const out = el.querySelector('[data-result]'); out.innerHTML = '<div class="muted">Running…</div>';
        try {
          if (ta) { lastQuery[id] = ta.value; show(await HD.api.runQuery(id, { sql: ta.value })); }
          else show(await HD.api.runQuery(id, { collection: el.querySelector('[data-mc]').value, filter: el.querySelector('[data-mf]').value, sort: el.querySelector('[data-ms]').value, limit: el.querySelector('[data-ml]').value }));
        } catch (ex) { out.innerHTML = `<div class="callout warn">${icon('alert', 'i-sm')}<div class="mono" style="white-space:pre-wrap">${esc(ex.message)}</div></div>`; }
      };
      ta?.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); run(); } });
      el.addEventListener('click', async (e) => {
        const t = e.target;
        if (t.closest('[data-run]')) run();
        const cp = t.closest('[data-cp]'); if (cp) HD.copy(cp.dataset.cp);
        if (t.closest('[data-reveal]')) { const db = await HD.api.getDatabase(id); const p = el.querySelector('[data-pw]'); p.textContent = p.textContent.startsWith('•') ? db.connection.password : '••••••••••'; }
        if (t.closest('[data-reset]') && (await HD.confirm({ title: 'Create a new password?', message: 'The old password stops working. Update your application’s settings with the new one.', confirmText: 'New password', danger: false }))) {
          try { const r = await HD.api.resetDbPassword(id); const db = await HD.api.getDatabase(id); credentialsModal({ ...db, connection: r.connection }, 'New password'); } catch (ex) { HD.toast(ex.message, 'error'); }
        }
        if (t.closest('[data-del]')) {
          const db = await HD.api.getDatabase(id).catch(() => null);
          if (await HD.confirm({ title: `Delete ${db ? db.name : 'database'}?`, message: 'All data in it is removed. Export it first if you need it.', confirmText: 'Delete database' })) {
            try { await HD.api.deleteDatabase(id); HD.toast('Database deleted'); HD.go('/databases'); } catch (ex) { HD.toast(ex.message, 'error'); }
          }
        }
      });
    },
  };
})();
