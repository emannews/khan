/* Applications — list, create wizard and detail */
(function () {
  const HD = window.HD; const { esc, icon } = HD;
  const stateBadge = (a) => { const s = a.live.state; return HD.badge({ running: 'Running', starting: 'Starting', error: 'Crashed', stopped: 'Stopped' }[s] || s, s === 'running' ? 'success' : s === 'error' ? 'danger' : s === 'starting' ? 'accent' : '', true); };
  const words = { start: 'started', stop: 'stopped', restart: 'restarted' };

  async function doAction(id, action, btn) {
    if (btn) btn.disabled = true;
    try {
      const r = await HD.api.appAction(id, action);
      if (r.job) await HD.jobModal(r.job);
      else HD.toast(`${r.name} ${words[action]}`);
    } catch (e) { HD.toast(e.message, 'error'); }
    HD.rerender();
  }

  /* ---------- List ---------- */
  let listFilter = 'all';
  HD.pages.apps = {
    title: 'Applications', nav: 'apps',
    async render() {
      const [apps, meta] = await Promise.all([HD.api.listApps(), HD.api.appsMeta()]);
      const f = { all: () => true, node: (a) => a.runtime === 'node', php: (a) => a.runtime === 'php', running: (a) => a.live.state === 'running', stopped: (a) => a.live.state !== 'running' };
      const rows = apps.filter(f[listFilter]);
      const n = (k) => apps.filter(f[k]).length;
      const pill = (k, label) => `<button class="${listFilter === k ? 'on' : ''}" data-filter="${k}">${label} <span style="opacity:.7">${n(k)}</span></button>`;
      const noRuntime = !meta.node.length && !meta.php.length;
      return `
      <div class="page-head">
        <div><h1 class="page-title">Applications</h1><p class="page-sub">PHP sites are served by Nginx on port 80 · each Node.js app gets its own port, starting at ${meta.defaults.nodePortStart}</p></div>
        <div class="page-actions"><a class="btn btn-primary" href="#/apps/new">${icon('plus', 'i-sm')}Create application</a></div>
      </div>
      ${noRuntime ? `<div class="callout warn" style="margin-bottom:16px">${icon('alert', 'i-sm')}<div>No Node.js or PHP is installed yet. ${HD.isAdmin() ? '<a href="#/store">Open the App Store</a> to install one.' : 'Ask an administrator to install one.'}</div></div>` : ''}
      <div class="pill-tabs" style="margin-bottom:16px" role="group" aria-label="Filter">${pill('all', 'All')}${pill('node', 'Node.js')}${pill('php', 'PHP')}${pill('running', 'Running')}${pill('stopped', 'Stopped')}</div>
      <section class="card">
        ${rows.length ? `<div class="table-wrap"><table class="table">
          <thead><tr><th>Application</th><th>Runtime</th><th>Route</th><th>Status</th><th>CPU · Memory</th><th>Since</th><th><span class="sr-only">Actions</span></th></tr></thead>
          <tbody>${rows.map((a) => `
            <tr>
              <td><a class="cell-title" href="#/apps/${a.id}">${esc(a.name)}</a><div class="cell-sub"><a href="#/domains/${encodeURIComponent(a.domain)}" style="color:inherit">${esc(a.domain)}</a></div></td>
              <td>${HD.runtimeBadge(a.runtime, a.version)}</td>
              <td class="mono nowrap">${esc(a.route.service.replace('http://', ''))}</td>
              <td>${stateBadge(a)}</td>
              <td class="muted nowrap">${a.live.state === 'running' ? HD.appResText(a) : '—'}</td>
              <td class="muted nowrap">${a.live.since ? HD.timeAgo(a.live.since) : '—'}</td>
              <td class="actions">
                ${a.live.state === 'running'
                  ? `<button class="icon-btn" data-act="restart" data-id="${a.id}" title="Restart" aria-label="Restart ${esc(a.name)}">${icon('restart', 'i-sm')}</button><button class="icon-btn" data-act="stop" data-id="${a.id}" title="Stop" aria-label="Stop ${esc(a.name)}">${icon('stop', 'i-sm')}</button>`
                  : `<button class="icon-btn" data-act="start" data-id="${a.id}" title="Start" aria-label="Start ${esc(a.name)}">${icon('play', 'i-sm')}</button>`}
                <a class="icon-btn" href="#/apps/${a.id}/logs" title="Logs" aria-label="Logs of ${esc(a.name)}">${icon('terminal', 'i-sm')}</a>
              </td>
            </tr>`).join('')}</tbody></table></div>`
          : HD.empty('box', listFilter === 'all' ? 'No applications yet' : 'Nothing here', listFilter === 'all' ? 'Add a domain, upload your project, then create its application.' : 'No application matches this filter.', listFilter === 'all' ? `<a class="btn btn-primary" href="#/apps/new">${icon('plus', 'i-sm')}Create application</a>` : '')}
      </section>

      <section class="card mt">
        <div class="card-head"><div><div class="card-title">Port map</div><div class="card-sub">Ports used by applications on this server</div></div><span class="muted" style="font-size:13px">Next free: <b class="mono" style="color:var(--text)">${meta.nextPort}</b></span></div>
        <div class="card-body">
          <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px">
            <div class="flow-node"><span class="v">:80</span><span class="k">Nginx · PHP and static sites</span></div>
            ${meta.ports.map((p) => `<a class="flow-node" href="#/apps/${p.id}" style="text-decoration:none;color:inherit"><span class="v">:${p.port}</span><span class="k">${esc(p.app)}</span></a>`).join('')}
            <a class="flow-node target" href="#/apps/new" style="text-decoration:none;border-style:dashed"><span class="v">:${meta.nextPort}</span><span class="k">Free · next Node.js app</span></a>
          </div>
        </div>
      </section>`;
    },
    mount(el) {
      el.addEventListener('click', (e) => {
        const f = e.target.closest('[data-filter]'); if (f) { listFilter = f.dataset.filter; HD.rerender(); }
        const a = e.target.closest('[data-act]'); if (a) doAction(a.dataset.id, a.dataset.act, a);
      });
    },
  };

  /* ---------- Create wizard ---------- */
  HD.pages.appNew = {
    title: 'Create application', nav: 'apps',
    async render() {
      return `
      <nav class="crumbs"><a href="#/apps">Applications</a><span class="sep">/</span><span style="color:var(--text)">Create</span></nav>
      <div class="page-head"><div><h1 class="page-title">Create application</h1><p class="page-sub">Connect an uploaded folder to a domain and run it with Node.js or PHP.</p></div></div>
      <div class="grid g-main" style="align-items:start">
        <div class="card"><div class="card-body" data-wiz style="padding:24px"><div class="muted">Loading…</div></div></div>
        <aside class="card">
          <div class="card-head"><div class="card-title">${icon('info', 'i-sm')}What happens</div></div>
          <div class="card-body tight timeline">
            <div class="tl-item"><span class="ic">${icon('folder', 'i-xs')}</span><div class="txt"><b>Your folder is linked</b><div class="when">Files stay where you uploaded them.</div></div></div>
            <div class="tl-item"><span class="ic">${icon('node', 'i-xs')}</span><div class="txt"><b>Node.js</b> runs as a system service on its own port<div class="when">It restarts after a crash or a reboot.</div></div></div>
            <div class="tl-item"><span class="ic">${icon('php', 'i-xs')}</span><div class="txt"><b>PHP</b> runs in its own PHP-FPM pool, served by Nginx on port 80<div class="when">Nginx picks the site by its hostname.</div></div></div>
            <div class="tl-item"><span class="ic">${icon('route', 'i-xs')}</span><div class="txt"><b>The route is ready</b><div class="when">Add hostname → service in your Cloudflare Tunnel.</div></div></div>
          </div>
        </aside>
      </div>`;
    },
    async mount(el, ctx) {
      const [domains, meta] = await Promise.all([HD.api.listDomains(), HD.api.appsMeta()]);
      const free = domains.filter((d) => !d.app);
      const W = { step: 1, domainId: free.some((d) => d.id === ctx.query.domain) ? ctx.query.domain : null, folder: null, runtime: null, name: '', version: '', startMode: 'file', startFile: '', port: meta.nextPort, publicDir: '.', installDeps: true, autoRestart: true };
      const box = el.querySelector('[data-wiz]');
      let items = [], folderOptions = [];
      const dom = () => domains.find((x) => x.id === W.domainId);

      async function loadFolders() {
        const d = dom();
        const sub = (await HD.api.listDir(d.folder).catch(() => ({ items: [] }))).items;
        folderOptions = [d.folder, ...sub.filter((x) => x.type === 'dir' && !['node_modules', 'vendor', 'data', '.git', 'logs'].includes(x.name)).map((x) => x.path)];
        if (!folderOptions.includes(W.folder)) W.folder = d.folder;
        items = (await HD.api.listDir(W.folder).catch(() => ({ items: [] }))).items;
      }
      const names = () => items.map((f) => f.name);
      const detect = () => {
        const n = names();
        if (n.includes('package.json') || n.some((x) => /\.(c|m)?js$/.test(x))) return 'node';
        if (n.includes('composer.json') || n.some((x) => x.endsWith('.php')) || items.some((x) => x.type === 'dir' && x.name === 'public')) return 'php';
        return null;
      };
      const jsFiles = () => items.filter((f) => f.type === 'file' && /\.(c|m)?js$/.test(f.name)).map((f) => f.name);
      const dirs = () => items.filter((f) => f.type === 'dir' && !['node_modules', 'vendor', '.git'].includes(f.name)).map((f) => f.name);
      const steps = () => `<div class="steps">${['Domain', 'Folder', 'Runtime', 'Review'].map((s, i) => `<div class="step ${W.step === i + 1 ? 'on' : W.step > i + 1 ? 'done' : ''}"><span class="bar"></span>${i + 1} · ${s}</div>`).join('')}</div>`;
      const nav = (back, label = 'Continue', disabled = false) => `<div class="row-between mt-lg"><div>${back ? `<button class="btn" data-back>${icon('chevLeft', 'i-sm')}Back</button>` : ''}</div><button class="btn btn-primary" data-next ${disabled ? 'disabled' : ''}>${label}${label === 'Continue' ? icon('chevRight', 'i-sm') : ''}</button></div>`;

      function draw() {
        const d = dom(); let html = steps();
        if (W.step === 1) {
          html += `<h2 style="font-size:16px;font-weight:600">Choose a domain</h2><p class="muted" style="margin:4px 0 16px">Only domains without an application are listed.</p>`;
          html += free.length ? `<div class="choice-grid">${free.map((x) => `
            <button type="button" class="choice ${W.domainId === x.id ? 'on' : ''}" data-domain="${x.id}">
              <span class="choice-ic" style="background:var(--accent-soft);color:var(--accent-text)">${icon(x.parentId ? 'layers' : 'globe')}</span>
              <span style="min-width:0"><span class="ttl">${esc(x.name)}</span><br><span class="dsc mono">${esc(x.folder)}</span></span>
            </button>`).join('')}</div>` : HD.empty('globe', 'Every domain already has an application', 'Add a new domain or subdomain first.', HD.isAdmin() ? `<button class="btn btn-primary" data-adddomain>${icon('plus', 'i-sm')}Add domain</button>` : '');
          html += nav(false, 'Continue', !W.domainId);
        }
        if (W.step === 2) {
          const det = detect();
          html += `<h2 style="font-size:16px;font-weight:600">Choose the project folder</h2><p class="muted" style="margin:4px 0 16px">The folder you uploaded for <b style="color:var(--text)">${esc(d.name)}</b>.</p>
          <div class="grid g-2" style="align-items:start">
            <div class="stack-sm">${folderOptions.map((p) => `<button type="button" class="choice ${W.folder === p ? 'on' : ''}" data-folder="${esc(p)}" style="padding:12px 14px;align-items:center">${icon('folder', 'fic-dir')}<span class="mono" style="font-size:12.5px;overflow-wrap:anywhere">${esc(p)}</span></button>`).join('')}</div>
            <div class="card" style="box-shadow:none">
              <div class="card-head" style="min-height:0;padding:12px 16px"><span style="font-weight:600;font-size:13px">Contents</span>${det ? HD.badge(det === 'node' ? 'Looks like Node.js' : 'Looks like PHP', det) : ''}</div>
              ${items.length ? `<div class="card-body tight" style="max-height:280px;overflow:auto">${items.map((f) => `<div class="list-row" style="padding:8px 0"><span class="row">${icon(f.type === 'dir' ? 'folder' : 'file', 'i-sm ' + (f.type === 'dir' ? 'fic-dir' : 'fic-file'))}${esc(f.name)}</span><span class="muted" style="font-size:12px">${f.type === 'dir' ? '' : HD.fmtBytes(f.size)}</span></div>`).join('')}</div>`
                : `<div class="empty" style="padding:28px 16px"><h3>This folder is empty</h3><div style="font-size:13px">Upload your project first.</div></div>`}
              <div class="card-foot" style="justify-content:flex-start"><a class="btn btn-sm" href="#/files?path=${encodeURIComponent(W.folder)}">${icon('upload', 'i-sm')}Upload files</a></div>
            </div>
          </div>`;
          html += nav(true, 'Continue', !items.length);
        }
        if (W.step === 3) {
          const det = detect();
          if (!W.runtime) W.runtime = det === 'php' && meta.php.length ? 'php' : meta.node.length ? 'node' : meta.php.length ? 'php' : 'node';
          const node = W.runtime === 'node';
          const versions = node ? meta.node.map((v) => v.major) : meta.php;
          if (!versions.includes(W.version)) W.version = versions.includes(node ? meta.defaults.node : meta.defaults.php) ? (node ? meta.defaults.node : meta.defaults.php) : versions[0] || '';
          if (!W.name) { const base = d.parentId ? d.name.split('.')[0] : d.name.split('.')[0] + '-site'; W.name = base.toLowerCase().replace(/[^a-z0-9_-]/g, '-'); }
          if (node && !W.startFile) W.startFile = W.startMode === 'npm' ? 'start' : jsFiles().includes('server.js') ? 'server.js' : jsFiles().includes('index.js') ? 'index.js' : jsFiles().includes('app.js') ? 'app.js' : jsFiles()[0] || 'server.js';
          if (!node && W.publicDir === '.' && dirs().includes('public')) W.publicDir = 'public';
          const hasPkg = names().includes('package.json'), hasComposer = names().includes('composer.json');
          const missing = !versions.length;
          html += `<h2 style="font-size:16px;font-weight:600">Runtime and settings</h2><p class="muted" style="margin:4px 0 16px">How this application runs.</p>
          <div class="choice-grid">
            <button type="button" class="choice ${node ? 'on' : ''}" data-rt="node"><span class="choice-ic" style="background:var(--node-soft);color:var(--node)">${icon('node')}</span><span><span class="ttl">Node.js</span> ${det === 'node' ? HD.badge('Detected', 'accent') : ''}<br><span class="dsc">${meta.node.length ? 'Own port, kept running by systemd.' : 'Not installed yet'}</span></span></button>
            <button type="button" class="choice ${!node ? 'on' : ''}" data-rt="php"><span class="choice-ic" style="background:var(--php-soft);color:var(--php)">${icon('php')}</span><span><span class="ttl">PHP</span> ${det === 'php' ? HD.badge('Detected', 'accent') : ''}<br><span class="dsc">${meta.php.length ? 'Served by Nginx and PHP-FPM on port 80.' : 'Not installed yet'}</span></span></button>
          </div>
          ${missing ? `<div class="callout warn mt">${icon('alert', 'i-sm')}<div>${node ? 'Node.js' : 'PHP'} is not installed. ${HD.isAdmin() ? '<a href="#/store">Install it from the App Store</a>, then come back.' : 'Ask an administrator to install it.'}</div></div>` : `
          <form class="form-grid mt-lg" data-cfg novalidate>
            <div class="field"><label for="an">Application name</label><input id="an" class="input" name="name" value="${esc(W.name)}" spellcheck="false" autocapitalize="off"><span class="hint">Lowercase letters, numbers, - or _</span></div>
            <div class="field"><label for="av">${node ? 'Node.js' : 'PHP'} version</label><select id="av" class="select" name="version">${(node ? meta.node.map((v) => [v.major, `${v.major} (${v.version || ''})`]) : meta.php.map((v) => [v, v])).map(([v, l]) => `<option value="${v}" ${v === W.version ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></div>
            ${node ? `
              <div class="field full"><span class="label">How to start</span>
                <div class="seg" role="group"><button type="button" data-mode="file" class="${W.startMode === 'file' ? 'on' : ''}">Start file</button><button type="button" data-mode="npm" class="${W.startMode === 'npm' ? 'on' : ''}">npm script</button></div></div>
              <div class="field"><label for="as">${W.startMode === 'npm' ? 'npm script name' : 'Start file'}</label>${W.startMode === 'file' && jsFiles().length ? `<select id="as" class="select mono" name="startFile">${jsFiles().map((f) => `<option ${f === W.startFile ? 'selected' : ''}>${esc(f)}</option>`).join('')}</select>` : `<input id="as" class="input mono" name="startFile" value="${esc(W.startFile)}" spellcheck="false">`}<span class="hint">${W.startMode === 'npm' ? 'Runs npm run &lt;name&gt;, e.g. start' : 'Runs node &lt;file&gt;'}</span></div>
              <div class="field"><label for="ap">Port</label><input id="ap" class="input mono" name="port" inputmode="numeric" value="${W.port}"><span class="hint">Next free is ${meta.nextPort}. The app must listen on <span class="mono">process.env.PORT</span>.</span></div>
              <div class="full stack-sm">
                <label class="check"><input type="checkbox" name="installDeps" ${W.installDeps && hasPkg ? 'checked' : ''} ${hasPkg ? '' : 'disabled'}><span><span class="t">Run npm install first</span>${hasPkg ? '' : '<br><span class="d">No package.json in this folder</span>'}</span></label>
                <label class="check"><input type="checkbox" name="autoRestart" ${W.autoRestart ? 'checked' : ''}><span><span class="t">Keep running</span><br><span class="d">Restart after a crash or a server reboot.</span></span></label>
              </div>` : `
              <div class="field"><label for="apd">Public folder</label><select id="apd" class="select mono" name="publicDir">${['.', ...dirs()].map((x) => `<option value="${esc(x)}" ${x === W.publicDir ? 'selected' : ''}>${x === '.' ? '(project folder)' : esc(x)}</option>`).join('')}</select><span class="hint">The folder that holds index.php.</span></div>
              <div class="field"><label>Port</label><input class="input mono" value="80" readonly><span class="hint">Shared by all PHP sites.</span></div>
              <div class="full"><label class="check"><input type="checkbox" name="installDeps" ${hasComposer && meta.composer ? 'checked' : ''} ${hasComposer && meta.composer ? '' : 'disabled'}><span><span class="t">Run composer install first</span>${!hasComposer ? '<br><span class="d">No composer.json in this folder</span>' : !meta.composer ? '<br><span class="d">Composer is not installed (App Store)</span>' : ''}</span></label></div>`}
          </form>`}`;
          html += nav(true, 'Continue', missing);
        }
        if (W.step === 4) {
          const node = W.runtime === 'node';
          const service = node ? `http://localhost:${W.port}` : 'http://localhost:80';
          html += `<h2 style="font-size:16px;font-weight:600">Review</h2><p class="muted" style="margin:4px 0 16px">Check everything, then create and start.</p>
          <div class="review">${[['Domain', esc(d.name)], ['Folder', `<span class="mono">${esc(W.folder)}</span>`], ['Runtime', HD.runtimeBadge(W.runtime, W.version)], ['Name', esc(W.name)],
            node ? [W.startMode === 'npm' ? 'npm script' : 'Start file', `<span class="mono">${esc(W.startFile)}</span>`] : ['Public folder', `<span class="mono">${esc(W.publicDir)}</span>`],
            ['Port', `<span class="mono">${node ? W.port : '80 (shared)'}</span>`], ['Before start', W.installDeps ? (node ? 'npm install' : 'composer install') : '—'], ['Keep running', !node || W.autoRestart ? 'Yes' : 'No']]
            .map(([k, v]) => `<div class="list-row"><span class="muted">${k}</span><span>${v}</span></div>`).join('')}</div>
          <div class="callout mt">${icon('route', 'i-sm')}<div style="min-width:0;flex:1"><b>Cloudflare Tunnel route</b><div class="copy-row" style="margin-top:8px;background:var(--surface)"><code>${esc(d.name)} → ${esc(service)}</code><button class="icon-btn sm" data-copy="${esc(service)}" aria-label="Copy service URL">${icon('copy', 'i-xs')}</button></div><div style="margin-top:6px">In Cloudflare Zero Trust → your tunnel → Public Hostnames, add this hostname with this service.</div></div></div>`;
          html += nav(true, 'Create and start');
        }
        if (W.step === 5) {
          const a = W.created; const service = a.runtime === 'node' ? `http://localhost:${a.port}` : 'http://localhost:80';
          html = `<div class="empty" style="padding:24px 0 8px">
            <div class="empty-ic" style="background:var(--success-soft);color:var(--success)">${icon('check', 'i-lg')}</div>
            <h3 style="font-size:18px">${esc(a.name)} is ready</h3>
            <div>It is connected to <b style="color:var(--text)">${esc(d.name)}</b>.</div>
            <div class="copy-row" style="margin-top:14px;width:100%;max-width:460px;text-align:left"><code>${esc(d.name)} → ${esc(service)}</code><button class="icon-btn sm" data-copy="${esc(service)}" aria-label="Copy service URL">${icon('copy', 'i-xs')}</button></div>
            <div class="row" style="margin-top:16px"><a class="btn" href="#/domains/${encodeURIComponent(d.name)}">Go to domain</a><a class="btn btn-primary" href="#/apps/${a.id}">Open application</a></div>
          </div>`;
        }
        box.innerHTML = html;
      }

      const readCfg = () => { const f = box.querySelector('[data-cfg]'); if (f) { const v = HD.formData(f); Object.assign(W, v); if (!f.querySelector('[name=installDeps]')?.checked) W.installDeps = false; } };
      box.addEventListener('click', async (e) => {
        const t = e.target;
        const dm = t.closest('[data-domain]'); if (dm) { W.domainId = dm.dataset.domain; W.folder = null; W.name = ''; draw(); }
        const fo = t.closest('[data-folder]'); if (fo) { W.folder = fo.dataset.folder; W.startFile = ''; items = (await HD.api.listDir(W.folder).catch(() => ({ items: [] }))).items; draw(); }
        const rt = t.closest('[data-rt]'); if (rt) { readCfg(); if (W.runtime !== rt.dataset.rt) { W.runtime = rt.dataset.rt; W.version = ''; W.installDeps = true; } draw(); }
        const md = t.closest('[data-mode]'); if (md) { readCfg(); W.startMode = md.dataset.mode; W.startFile = ''; draw(); }
        const cp = t.closest('[data-copy]'); if (cp) HD.copy(cp.dataset.copy);
        if (t.closest('[data-adddomain]')) HD.openAddDomain();
        if (t.closest('[data-back]')) { readCfg(); W.step--; draw(); }
        const nx = t.closest('[data-next]');
        if (nx && !nx.disabled) {
          if (W.step === 1) { await loadFolders(); W.step = 2; return draw(); }
          if (W.step === 3) {
            readCfg(); const f = box.querySelector('[data-cfg]');
            if (!/^[a-z0-9][a-z0-9_-]{1,39}$/.test(W.name)) return HD.fieldError(f, 'name', 'Use lowercase letters, numbers, - or _ (2–40)');
            if (W.runtime === 'node') {
              const p = Number(W.port); if (!(p >= 1024 && p <= 65535)) return HD.fieldError(f, 'port', 'Port must be between 1024 and 65535');
              if (meta.ports.some((x) => x.port === p)) return HD.fieldError(f, 'port', `Port ${p} is used by ${meta.ports.find((x) => x.port === p).app}`);
              if (!W.startFile) return HD.fieldError(f, 'startFile', 'Required');
            }
          }
          if (W.step === 4) {
            nx.disabled = true; nx.textContent = 'Creating…';
            try {
              const data = { domainId: W.domainId, name: W.name, runtime: W.runtime, version: W.version, folder: W.folder, installDeps: !!W.installDeps, autoRestart: W.runtime === 'php' ? true : !!W.autoRestart };
              if (W.runtime === 'node') Object.assign(data, { startMode: W.startMode, startFile: W.startFile, port: Number(W.port) });
              else data.publicDir = W.publicDir;
              const r = await HD.api.createApp(data);
              W.created = r.app; HD.refreshCounts();
              if (r.job) await HD.jobModal(r.job, { title: `Starting ${r.app.name}` });
              W.step = 5; return draw();
            } catch (ex) { HD.toast(ex.message, 'error'); nx.disabled = false; nx.textContent = 'Create and start'; return; }
          }
          W.step++; draw();
        }
      });
      if (W.domainId) { await loadFolders(); W.step = 2; }
      draw();
    },
  };

  /* ---------- Detail ---------- */
  let logTimer = null;
  HD.pages.app = {
    title: 'Application', nav: 'apps',
    async render(ctx) {
      const [a, meta] = await Promise.all([HD.api.getApp(ctx.params.id), HD.api.appsMeta()]);
      const tab = ctx.params.tab || 'overview';
      const base = '#/apps/' + a.id;
      const T = (k, label) => `<a href="${base}${k === 'overview' ? '' : '/' + k}" class="${tab === k ? 'on' : ''}">${label}</a>`;
      const node = a.runtime === 'node', running = a.live.state === 'running';
      let body = '';

      if (tab === 'overview') {
        const logs = await HD.api.appLogs(a.id, 30).catch(() => ({ text: '' }));
        body = `
        <div class="grid g-4">
          <div class="card stat"><div class="stat-top"><span class="stat-label">Status</span>${stateBadge(a)}</div><div class="stat-value" style="font-size:20px">${{ running: 'Running', starting: 'Starting', error: 'Crashed', stopped: 'Stopped' }[a.live.state]}</div><div class="stat-foot">${a.live.since ? 'Since ' + HD.timeAgo(a.live.since) : '—'}</div></div>
          <div class="card stat"><div class="stat-top"><span class="stat-label">CPU</span><span class="stat-ic">${icon('cpu', 'i-sm')}</span></div><div class="stat-value">${running && a.live.cpu != null ? a.live.cpu : '—'}<small>${running && a.live.cpu != null ? '%' : ''}</small></div><div class="stat-foot">${node ? 'of one core' : 'Shared PHP-FPM pool'}</div></div>
          <div class="card stat"><div class="stat-top"><span class="stat-label">Memory</span><span class="stat-ic">${icon('memory', 'i-sm')}</span></div><div class="stat-value">${running && a.live.mem != null ? a.live.mem : '—'}<small>${running && a.live.mem != null ? ' MB' : ''}</small></div><div class="stat-foot">${node ? 'Current use' : '—'}</div></div>
          <div class="card stat"><div class="stat-top"><span class="stat-label">Restarts</span><span class="stat-ic">${icon('restart', 'i-sm')}</span></div><div class="stat-value">${a.live.restarts}</div><div class="stat-foot">${a.autoRestart ? 'Auto restart on' : 'Auto restart off'}</div></div>
        </div>
        <div class="grid g-main mt">
          <div class="stack">
            <section class="card"><div class="card-head"><div class="card-title">Details</div><a class="btn btn-sm" href="${base}/settings">${icon('edit', 'i-sm')}Edit</a></div>
              <div class="card-body"><dl class="kv">
                <div><dt>Domain</dt><dd><a href="#/domains/${encodeURIComponent(a.domain)}">${esc(a.domain)}</a></dd></div>
                <div><dt>Runtime</dt><dd>${node ? 'Node.js' : 'PHP'} ${esc(a.version)}</dd></div>
                <div><dt>Folder</dt><dd class="mono">${esc(a.folder)}</dd></div>
                <div><dt>${node ? (a.startMode === 'npm' ? 'npm script' : 'Start file') : 'Public folder'}</dt><dd class="mono">${esc(node ? a.startFile : a.publicDir)}</dd></div>
                <div><dt>Port</dt><dd class="mono">${node ? a.port : '80 (shared)'}</dd></div>
                <div><dt>Created</dt><dd>${HD.fmtDate(a.createdAt)}</dd></div>
              </dl></div></section>
            <section class="card"><div class="card-head"><div class="card-title">Recent log</div><a class="btn btn-sm" href="${base}/logs">${icon('terminal', 'i-sm')}Open log</a></div>
              <div class="card-body"><pre class="code" style="max-height:260px">${esc((logs.text || 'No log yet.').split('\n').slice(-14).join('\n'))}</pre></div></section>
          </div>
          <div class="stack">
            <section class="card"><div class="card-head"><div class="card-title">Route</div></div>
              <div class="card-body"><div class="flow">
                <div class="flow-node"><span class="k">Public address</span><span class="v">https://${esc(a.domain)}</span></div>
                <div class="flow-arrow">${icon('chevDown', 'i-sm')}</div>
                <div class="flow-node target"><span class="k">Service</span><span class="v">${esc(a.route.service)}</span></div>
              </div><button class="btn btn-sm btn-block mt" data-copy="${esc(a.route.service)}">${icon('copy', 'i-sm')}Copy service URL</button></div></section>
            <section class="card"><div class="card-head"><div class="card-title">Quick actions</div></div>
              <div class="card-body stack-sm">
                <a class="btn btn-block" href="#/files?path=${encodeURIComponent(a.folder)}" style="justify-content:flex-start">${icon('folder', 'i-sm')}Open project folder</a>
                <button class="btn btn-block" data-act="install" style="justify-content:flex-start">${icon('download', 'i-sm')}Run ${node ? 'npm' : 'composer'} install</button>
                <a class="btn btn-block" href="${base}/env" style="justify-content:flex-start">${icon('key', 'i-sm')}Environment variables</a>
                <a class="btn btn-block" href="#/domains/${encodeURIComponent(a.domain)}/databases" style="justify-content:flex-start">${icon('database', 'i-sm')}Databases</a>
              </div></section>
          </div>
        </div>`;
      }
      if (tab === 'logs') {
        const logs = await HD.api.appLogs(a.id, 400).catch((e) => ({ text: e.message }));
        body = `<section class="card">
          <div class="card-head"><div><div class="card-title">Log</div><div class="card-sub">${node ? 'systemd journal (last 400 lines)' : 'Nginx and PHP logs for this site'}</div></div>
            <div class="row wrap"><label class="check" style="align-items:center;font-size:13px"><input type="checkbox" data-auto checked>Auto refresh</label><button class="btn btn-sm" data-refresh>${icon('refresh', 'i-sm')}Refresh</button><button class="btn btn-sm" data-dl>${icon('download', 'i-sm')}Download</button></div></div>
          <div class="card-body"><pre class="code log-box" style="height:520px" data-log>${esc(logs.text)}</pre></div></section>`;
      }
      if (tab === 'env') body = `
        <section class="card" style="max-width:900px">
          <div class="card-head"><div><div class="card-title">Environment variables</div><div class="card-sub">${node ? 'Saved privately (root only). The app restarts when you save.' : 'Passed to PHP-FPM. Applied when you save.'}${node ? ' PORT is set by the panel.' : ''}</div></div></div>
          <div class="card-body stack-sm" data-env>
            <div class="env-row" style="font-size:12px;font-weight:600;color:var(--muted)"><span>Name</span><span>Value</span><span style="width:32px"></span></div>
            ${(a.env.length ? a.env : [{ key: '', value: '' }]).map(envRow).join('')}
          </div>
          <div class="card-foot" style="justify-content:space-between"><button class="btn btn-sm" data-addenv>${icon('plus', 'i-sm')}Add variable</button><button class="btn btn-primary btn-sm" data-saveenv>Save${node ? ' and restart' : ''}</button></div>
        </section>`;
      if (tab === 'settings') {
        const versions = node ? meta.node.map((v) => v.major) : meta.php;
        body = `
        <div class="card">
          <form data-settings novalidate>
            <section class="settings-sec"><div><h2>General</h2><p>Runtime version and how the application starts. Saving applies the change right away.</p></div>
              <div class="form-grid">
                <div class="field"><label>Name</label><input class="input" value="${esc(a.name)}" readonly><span class="hint">The name cannot be changed.</span></div>
                <div class="field"><label for="sv">Version</label><select id="sv" class="select" name="version">${(versions.includes(a.version) ? versions : [a.version, ...versions]).map((v) => `<option ${v === a.version ? 'selected' : ''}>${v}</option>`).join('')}</select></div>
                ${node ? `
                <div class="field"><label for="sm">Start with</label><select id="sm" class="select" name="startMode"><option value="file" ${a.startMode !== 'npm' ? 'selected' : ''}>Start file (node file.js)</option><option value="npm" ${a.startMode === 'npm' ? 'selected' : ''}>npm script (npm run name)</option></select></div>
                <div class="field"><label for="ss">Start file or script</label><input id="ss" class="input mono" name="startFile" value="${esc(a.startFile)}" spellcheck="false"></div>
                <div class="field"><label for="sp">Port</label><input id="sp" class="input mono" name="port" value="${a.port}" inputmode="numeric"></div>
                <div class="field"><label>&nbsp;</label><label class="check" style="margin-top:8px"><input type="checkbox" name="autoRestart" ${a.autoRestart ? 'checked' : ''}><span class="t">Keep running (restart after crash or reboot)</span></label></div>` : `
                <div class="field"><label for="spd">Public folder</label><input id="spd" class="input mono" name="publicDir" value="${esc(a.publicDir)}" spellcheck="false"><span class="hint">Relative to ${esc(a.folder)}</span></div>`}
                <div class="full"><button class="btn btn-primary" type="submit">Save changes</button></div>
              </div>
            </section>
          </form>
          <section class="settings-sec"><div><h2 style="color:var(--danger)">Delete application</h2><p>Stops it and removes it from the panel. The domain then serves its folder as static files. Files and databases are kept.</p></div>
            <div><button class="btn btn-danger" data-del>${icon('trash', 'i-sm')}Delete ${esc(a.name)}</button></div></section>
        </div>`;
      }

      return `
      <nav class="crumbs"><a href="#/apps">Applications</a><span class="sep">/</span><span style="color:var(--text)">${esc(a.name)}</span></nav>
      <div class="page-head">
        <div class="row" style="gap:14px">
          <span class="choice-ic" style="width:48px;height:48px;border-radius:12px;background:${node ? 'var(--node-soft);color:var(--node)' : 'var(--php-soft);color:var(--php)'}">${icon(node ? 'node' : 'php', 'i-lg')}</span>
          <div><div class="row wrap" style="gap:10px"><h1 class="page-title">${esc(a.name)}</h1>${HD.runtimeBadge(a.runtime, a.version)}${stateBadge(a)}</div>
          <p class="page-sub" style="margin-top:2px"><a href="#/domains/${encodeURIComponent(a.domain)}" style="color:inherit">${esc(a.domain)}</a> · ${esc(a.route.service)}</p></div>
        </div>
        <div class="page-actions">
          ${running ? `<button class="btn" data-act="restart">${icon('restart', 'i-sm')}Restart</button><button class="btn" data-act="stop">${icon('stop', 'i-sm')}Stop</button>` : `<button class="btn btn-primary" data-act="start">${icon('play', 'i-sm')}Start</button>`}
          <a class="btn" href="https://${esc(a.domain)}" target="_blank" rel="noopener">Open site ${icon('external', 'i-sm')}</a>
        </div>
      </div>
      <nav class="tabs" aria-label="Application sections">${T('overview', 'Overview')}${T('logs', 'Logs')}${T('env', 'Environment')}${T('settings', 'Settings')}</nav>
      ${body}`;
    },
    mount(el, ctx) {
      const id = ctx.params.id;
      const logEl = el.querySelector('[data-log]');
      const refresh = async () => {
        if (!logEl) return;
        const r = await HD.api.appLogs(id, 400).catch(() => null); if (!r) return;
        const near = logEl.scrollHeight - logEl.scrollTop - logEl.clientHeight < 80;
        logEl.textContent = r.text; if (near) logEl.scrollTop = logEl.scrollHeight;
      };
      if (logEl) { logEl.scrollTop = logEl.scrollHeight; logTimer = setInterval(() => { if (el.querySelector('[data-auto]')?.checked && !document.hidden) refresh(); }, 5000); }
      el.addEventListener('click', async (e) => {
        const t = e.target;
        const act = t.closest('[data-act]'); if (act) return doAction(id, act.dataset.act, act);
        const cp = t.closest('[data-copy]'); if (cp) return HD.copy(cp.dataset.copy);
        if (t.closest('[data-refresh]')) refresh();
        if (t.closest('[data-dl]')) { const a = await HD.api.getApp(id); HD.download(`${a.name}.log`, logEl.textContent); }
        if (t.closest('[data-addenv]')) { el.querySelector('[data-env]').insertAdjacentHTML('beforeend', envRow({ key: '', value: '' })); el.querySelector('[data-env] .env-row:last-child input').focus(); }
        const rm = t.closest('[data-rmenv]'); if (rm) rm.closest('.env-row').remove();
        if (t.closest('[data-saveenv]')) {
          const env = HD.$$('[data-env] .env-row', el).map((r) => ({ key: r.querySelector('[data-k]')?.value.trim(), value: r.querySelector('[data-v]')?.value ?? '' })).filter((v) => v.key);
          const btn = t.closest('[data-saveenv]'); btn.disabled = true;
          try { await HD.api.updateApp(id, { env }); HD.toast('Variables saved'); HD.rerender(); } catch (ex) { HD.toast(ex.message, 'error'); btn.disabled = false; }
        }
        if (t.closest('[data-del]')) {
          const a = await HD.api.getApp(id);
          if (await HD.confirm({ title: `Delete ${a.name}?`, message: 'The application stops and is removed from the panel. Files and databases stay.', confirmText: 'Delete application' })) {
            try { await HD.api.deleteApp(id); HD.toast(`${a.name} deleted`); HD.refreshCounts(); HD.go('/apps'); } catch (ex) { HD.toast(ex.message, 'error'); }
          }
        }
      });
      el.querySelector('[data-settings]')?.addEventListener('submit', async (e) => {
        e.preventDefault(); const f = e.target; const d = HD.formData(f);
        if (d.port != null) d.port = Number(d.port);
        const btn = f.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'Saving…';
        try { await HD.api.updateApp(id, d); HD.toast('Settings saved'); HD.rerender(); }
        catch (ex) { btn.disabled = false; btn.textContent = 'Save changes'; HD.fieldError(f, /port/i.test(ex.message) ? 'port' : /start/i.test(ex.message) ? 'startFile' : /public/i.test(ex.message) ? 'publicDir' : 'version', ex.message); }
      });
      el.querySelector('[data-env]')?.addEventListener('input', (e) => { if (e.target.matches('[data-k]')) e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9_]/g, '_'); });
    },
    unmount() { clearInterval(logTimer); logTimer = null; },
  };

  function envRow(v) {
    return `<div class="env-row"><input class="input mono" data-k value="${esc(v.key)}" placeholder="NAME" aria-label="Name"><input class="input mono" data-v value="${esc(v.value)}" placeholder="value" aria-label="Value" spellcheck="false"><button class="icon-btn sm danger" data-rmenv aria-label="Remove">${icon('trash', 'i-sm')}</button></div>`;
  }
})();
