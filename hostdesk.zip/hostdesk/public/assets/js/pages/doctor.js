/* Troubleshoot — find common problems and fix them with one click */
(function () {
  const HD = window.HD; const { esc, icon } = HD;
  const GROUPS = [['web', 'Web server', 'server'], ['services', 'Services', 'layers'], ['apps', 'Applications', 'box'], ['system', 'System', 'cpu']];
  const ST = { ok: ['checkCircle', 'success'], warn: ['alert', 'warn'], error: ['alert', 'danger'] };

  async function showLog(unit, title) {
    let r; try { r = await HD.api.doctorLogs(unit, 200); } catch (e) { return HD.toast(e.message, 'error'); }
    HD.modal({ title, size: 'xl', body: `<pre class="code" style="height:60vh" data-l>${esc(r.text)}</pre>`, foot: `<button class="btn" data-dl>${icon('download', 'i-sm')}Download</button><button class="btn btn-primary" data-close>Close</button>`,
      onMount(el) { const p = el.querySelector('[data-l]'); p.scrollTop = p.scrollHeight; el.querySelector('[data-dl]').addEventListener('click', () => HD.download(unit.replace(/[^\w.-]/g, '_') + '.log', r.text)); } });
  }

  HD.pages.doctor = {
    title: 'Troubleshoot', nav: 'doctor', admin: true,
    async render() {
      const list = await HD.api.doctor();
      const bad = list.filter((c) => c.status !== 'ok');
      const errors = bad.filter((c) => c.status === 'error').length;
      return `
      <div class="page-head">
        <div><h1 class="page-title">Troubleshoot</h1><p class="page-sub">Checks the parts that most often break, and fixes them safely. SSH and the Cloudflare Tunnel are never stopped or restarted.</p></div>
        <div class="page-actions"><button class="btn" data-panel-log>${icon('terminal', 'i-sm')}Panel log</button><button class="btn btn-primary" data-recheck>${icon('refresh', 'i-sm')}Check again</button></div>
      </div>
      <div class="doctor-summary ${errors ? 'bad' : bad.length ? 'warn' : 'good'}">
        <span class="ds-ic">${icon(bad.length ? 'alert' : 'checkCircle', 'i-lg')}</span>
        <div><b>${bad.length ? HD.t('{n} things need attention', { n: bad.length }) : HD.t('Everything looks good')}</b>
        <div>${bad.length ? HD.esc(HD.t('Use the button next to each problem. Every fix is shown with its log.')) : HD.esc(HD.t('{n} checks passed.', { n: list.length }))}</div></div>
      </div>
      ${GROUPS.map(([g, label, ic]) => {
        const items = list.filter((c) => c.group === g); if (!items.length) return '';
        const issues = items.filter((c) => c.status !== 'ok').length;
        return `<section class="card mt">
          <div class="card-head"><div class="card-title">${icon(ic, 'i-sm')}${label}</div>${issues ? HD.badge(HD.t('{n} to fix', { n: issues }), 'warn', true) : HD.badge('OK', 'success', true)}</div>
          <div class="card-body tight">${items.sort((a, b) => (a.status === 'ok') - (b.status === 'ok')).map((c) => `
            <div class="check-row ${c.status}">
              <span class="check-ic ${ST[c.status][1]}">${icon(ST[c.status][0], 'i-sm')}</span>
              <div class="grow" style="min-width:0"><div class="title">${esc(c.title)}</div><div class="sub pre">${esc(c.detail || '')}</div></div>
              <div class="row wrap check-actions">
                ${c.logs ? `<button class="btn btn-sm btn-ghost" data-log="${esc(c.logs)}" data-title="${esc(c.title)}">${icon('terminal', 'i-sm')}Log</button>` : ''}
                ${c.link ? `<a class="btn btn-sm btn-ghost" href="${esc(c.link)}">Open</a>` : ''}
                ${c.fix ? `<button class="btn btn-sm btn-primary" data-fix="${esc(c.fix.id)}" data-label="${esc(c.fix.label)}">${icon('wand', 'i-sm')}${esc(c.fix.label)}</button>` : ''}
              </div>
            </div>`).join('')}</div>
        </section>`;
      }).join('')}`;
    },
    mount(el) {
      el.addEventListener('click', async (e) => {
        const t = e.target;
        if (t.closest('[data-recheck]')) { HD.toast(HD.t('Checking…'), 'info'); return HD.rerender(); }
        if (t.closest('[data-panel-log]')) return showLog('hostdesk', HD.t('Panel log'));
        const lg = t.closest('[data-log]'); if (lg) return showLog(lg.dataset.log, lg.dataset.title);
        const fx = t.closest('[data-fix]');
        if (fx) {
          fx.disabled = true;
          try {
            const r = await HD.api.doctorFix(fx.dataset.fix);
            if (r.job) await HD.jobModal(r.job, { title: HD.t(fx.dataset.label) });
            else HD.toast(HD.t('Done'));
          } catch (ex) { HD.toast(ex.message, 'error'); }
          HD.rerender();
        }
      });
    },
  };
})();
