/* Sign in */
(function () {
  const HD = window.HD; const { esc, icon } = HD;

  HD.pages.login = {
    title: 'Sign in',
    async render() {
      const s = HD.settings;
      return `
      <div class="auth">
        <section class="auth-side">
          <div class="row" style="gap:12px">
            <div class="brand-logo" data-brand-logo>${HD.logoHtml()}</div>
            <div><div class="brand-name" data-brand-name>${esc(s.panelName || 'HostDesk')}</div><div class="brand-sub">${esc(s.hostname || 'Server panel')}</div></div>
          </div>
          <div style="display:flex;flex-direction:column;gap:28px">
            <h1 style="font-size:32px;line-height:1.2;font-weight:650;letter-spacing:-.02em;color:#fff;max-width:440px">Your server, organised in one place.</h1>
            <div class="auth-points">
              <div><span class="ic">${icon('globe')}</span><p style="margin:0"><b>Domains and subdomains</b><span>Each one gets its own folder, application, databases and optional account.</span></p></div>
              <div><span class="ic">${icon('box')}</span><p style="margin:0"><b>Node.js and PHP applications</b><span>They keep running, and restart after a crash or a reboot.</span></p></div>
              <div><span class="ic">${icon('database')}</span><p style="margin:0"><b>Databases, files and backups</b><span>SQLite, MySQL, PostgreSQL and MongoDB, managed from the browser.</span></p></div>
            </div>
          </div>
          <div style="font-size:12.5px;color:#8089A0">HostDesk server panel</div>
        </section>
        <section class="auth-main">
          <form class="auth-card" novalidate>
            <div class="brand-logo" style="width:44px;height:44px;border-radius:12px;font-size:19px" data-brand-logo>${HD.logoHtml()}</div>
            <div>
              <h2 style="font-size:24px;font-weight:650;letter-spacing:-.015em">Sign in</h2>
              <p class="muted" style="margin:6px 0 0">to <span data-brand-name>${esc(s.panelName || 'HostDesk')}</span></p>
            </div>
            <div class="field"><label for="u">Username</label><input id="u" class="input" name="username" autocomplete="username" autocapitalize="off" spellcheck="false"></div>
            <div class="field">
              <label for="p">Password</label>
              <div style="position:relative">
                <input id="p" class="input" name="password" type="password" autocomplete="current-password" style="padding-right:44px">
                <button type="button" class="icon-btn sm" data-reveal aria-label="Show password" style="position:absolute;right:4px;top:4px">${icon('eye', 'i-sm')}</button>
              </div>
            </div>
            <label class="check"><input type="checkbox" name="remember" checked><span class="t" style="font-weight:400">Keep me signed in on this device</span></label>
            <div class="callout warn" data-err hidden>${icon('alert', 'i-sm')}<div data-msg></div></div>
            <button class="btn btn-primary btn-lg btn-block" type="submit">Sign in</button>
            <div class="auth-note">Forgot the password? On the server run <span class="mono">sudo hostdesk passwd admin</span></div>
          </form>
        </section>
      </div>`;
    },
    mount(root) {
      const form = root.querySelector('form'); const err = root.querySelector('[data-err]');
      root.querySelector('#u').focus();
      root.querySelector('[data-reveal]').addEventListener('click', () => { const p = root.querySelector('#p'); p.type = p.type === 'password' ? 'text' : 'password'; });
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const { username, password, remember } = HD.formData(form);
        if (!username || !password) { err.hidden = false; err.querySelector('[data-msg]').textContent = 'Enter your username and password'; return; }
        const btn = form.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'Signing in…';
        try { await HD.api.login(username, password, remember); location.hash = '#/dashboard'; }
        catch (ex) { err.hidden = false; err.querySelector('[data-msg]').textContent = ex.message; btn.disabled = false; btn.textContent = 'Sign in'; root.querySelector('#p').select(); }
      });
    },
  };
})();
