# HostDesk — server panel

A clean, self-hosted control panel for one Linux server. Built for Ubuntu 24.04 (22.04 also works) behind a Cloudflare Tunnel.

- **Domains and subdomains** — each one gets its own folder, its own Linux user, an Nginx site and an optional panel account. Expand a domain to see its subdomains. Turn sites on/off, delete them (optionally with files and databases).
- **Applications** — Node.js (runs as a systemd service on its own port, restarts after crashes and reboots) and PHP (its own PHP-FPM pool, served by Nginx on port 80). Static sites work with no app at all.
- **Databases** — SQLite (files found automatically), MySQL / MariaDB, PostgreSQL and MongoDB: create with a private user, browse tables, see structure, run queries, export, change passwords.
- **App Store** — install, update and remove Node.js 18/20/22/24, PHP 7.4–8.4, Composer, MariaDB, MySQL, PostgreSQL, MongoDB 8, Redis, Fail2ban, Git, SQLite CLI. Every install shows its live log.
- **File manager** — upload (drag and drop, big files), edit code, rename, delete, zip / unzip, download.
- **Routes** — the `hostname → http://localhost:port` list for your Cloudflare Tunnel, with copy buttons and a ready `config.yml`.
- **Backups** (daily schedule + manual, with database dumps, restore, download), **Cron jobs**, **Activity log**, **Accounts**, **Security** (UFW rules, Fail2ban, SSH status), **Settings** (name, logo, color, dark mode, time zone).

No npm packages: the server uses only Node.js built-ins, so there is nothing to break on updates.

---

## Install

On the server, as a user with sudo:

```bash
unzip hostdesk.zip
cd hostdesk
sudo bash install.sh
```

If **aaPanel** is on the server, remove it first (SSH and Cloudflare Tunnel are not touched; old site files are kept in `/root`):

```bash
sudo bash remove-aapanel.sh
```

The installer:

1. checks the system (Ubuntu version, free space, nothing else on port 80);
2. installs Nginx and a few tools from Ubuntu, and Node.js 22 from nodejs.org (checksum verified);
3. copies the panel to `/opt/hostdesk/app` and starts the `hostdesk` service on port **7800**;
4. creates the `admin` account and **prints its password** — write it down;
5. if UFW is on, allows port 7800 **from your local network only**.

Open `http://<server-ip>:7800` from a computer on the same network.

**Update:** extract the new version and run `sudo bash install.sh` again. Data, sites and settings are kept.

## Open the panel from anywhere (Cloudflare Tunnel)

In Cloudflare Zero Trust → Networks → Tunnels → your tunnel → **Public Hostnames**, add:

| Subdomain | Service |
|---|---|
| `panel.yourdomain.com` | `http://localhost:7800` |

Then protect it under Zero Trust → Access → Applications (for example: allow only your email).

## Hosting a site

1. **Domains → Add domain** (or a subdomain, e.g. `host.takal.net`).
2. **File manager** → upload your project into that domain's folder (or upload a .zip and extract it).
3. **Applications → Create application** → pick the domain, the folder, Node.js or PHP. A Node.js app gets the next free port (4001, 4002 …) and must listen on `process.env.PORT`.
4. **Routes** shows what to add in Cloudflare Tunnel:
   - PHP and static sites → `http://localhost:80`
   - each Node.js app → `http://localhost:<its port>`

## Where things are

| What | Where |
|---|---|
| Sites | `/var/www/<domain>/www` and `/var/www/<domain>/<subdomain>` |
| Panel | `/opt/hostdesk/app` · service `hostdesk` · config `/etc/hostdesk/config.json` |
| Panel data | `/var/lib/hostdesk` (state, activity, jobs) |
| Backups | `/var/backups/hostdesk` |
| Runtimes | `/opt/hostdesk/runtimes/node/<version>` · PHP from `ppa:ondrej/php` |
| Nginx sites | `/etc/nginx/sites-available/hostdesk-<domain>.conf` |
| Node app services | `hostdesk-app-<name>.service` |
| PHP pools | `/etc/php/<version>/fpm/pool.d/hostdesk-<name>.conf` |
| Logs | `/var/log/nginx/hostdesk/`, `/var/log/hostdesk/`, `journalctl -u hostdesk-app-<name>` |

Files the panel manages start with `# Managed by HostDesk`. If something looks wrong, **Settings → Re-apply all sites** writes them again.

## Command line

```bash
sudo hostdesk passwd admin        # new password for admin (or create an admin)
hostdesk info                     # panel address
sudo hostdesk status              # service status
journalctl -u hostdesk -f         # panel log
```

## Safety

- Every Nginx and PHP-FPM change is tested first and rolled back if the test fails.
- Each site runs as its own Linux user, so sites cannot read each other's files.
- Databases get their own user with access to that database only. MongoDB is installed with authentication on.
- Passwords are hashed with scrypt; sessions are HttpOnly, SameSite=Strict cookies; failed sign-ins are rate limited.
- Commands never go through a shell with user input; SQL goes through stdin, passwords through files or environment variables.

## Remove

```bash
sudo bash /opt/hostdesk/app/uninstall.sh          # panel only; sites keep running
sudo bash /opt/hostdesk/app/uninstall.sh --purge  # also the panel's own data
```

## Development

```bash
npm run dev     # HOSTDESK_DEV=1 — uses /tmp/hostdesk-dev, never runs system commands
```
Dev sign-in: `admin` / `admin1234`.

---

### لنډ لارښود (پښتو)

1. ZIP سرور ته پورته کړئ، بیا: `unzip hostdesk.zip && cd hostdesk && sudo bash install.sh`
2. د نصب په پای کې د **admin** پاسورډ ښکاري، هغه ولیکئ.
3. په خپل کور شبکه کې `http://<server-ip>:7800` خلاص کړئ.
4. **App Store** ته لاړ شئ، Node.js او/یا PHP نصب کړئ. Fail2ban هم ښه دی.
5. ډومین جوړ کړئ ← فایلونه اپلوډ کړئ ← اپلکېشن جوړ کړئ.
6. **Routes** پاڼه ښيي چې Cloudflare Tunnel کې کوم hostname کوم `localhost:port` ته ورکړئ.
7. د پینل لپاره هم په Tunnel کې `panel.takal.net → http://localhost:7800` ورزیات کړئ او Cloudflare Access پرې ولګوئ.
