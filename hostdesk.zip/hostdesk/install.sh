#!/usr/bin/env bash
# =============================================================
#  HostDesk — install or update
#  Ubuntu 22.04 / 24.04.  Run from the extracted folder:
#      sudo bash install.sh
#  Running it again updates HostDesk and keeps all data.
# =============================================================
set -Eeuo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE=/opt/hostdesk
APP=$BASE/app
NODE_MAJOR=22
NODE_DIR=$BASE/runtimes/node/$NODE_MAJOR
PORT="${HOSTDESK_PORT:-7800}"

b=$'\e[1m'; g=$'\e[32m'; y=$'\e[33m'; r=$'\e[31m'; n=$'\e[0m'
say()  { echo "${g}==>${n} ${b}$*${n}"; }
warn() { echo "${y}!!${n}  $*"; }
die()  { echo "${r}xx${n}  $*" >&2; exit 1; }
trap 'die "Installation stopped at line $LINENO. Nothing was removed; fix the problem above and run it again."' ERR

[[ $EUID -eq 0 ]] || die "Please run as root:  sudo bash install.sh"
[[ -f "$SRC/server/index.js" && -f "$SRC/public/index.html" ]] || die "Run this script from the extracted HostDesk folder."

. /etc/os-release
if [[ "${ID:-}" != "ubuntu" ]] || [[ "${VERSION_ID:-}" != "24.04" && "${VERSION_ID:-}" != "22.04" ]]; then
  [[ "${HOSTDESK_FORCE:-0}" == "1" ]] || die "HostDesk supports Ubuntu 22.04 and 24.04 (found: ${PRETTY_NAME:-unknown}). Set HOSTDESK_FORCE=1 to try anyway."
  warn "Unsupported system ${PRETTY_NAME:-}; continuing because HOSTDESK_FORCE=1"
fi

UPDATE=0; [[ -f /etc/hostdesk/config.json && -d $APP ]] && UPDATE=1
if [[ $UPDATE == 1 ]]; then
  PORT="$(grep -oE '"port"[[:space:]]*:[[:space:]]*[0-9]+' /etc/hostdesk/config.json | grep -oE '[0-9]+$' || echo 7800)"
  say "Updating HostDesk (data and sites are kept)"
else
  say "Installing HostDesk"
fi

# ---------- Pre-flight checks ----------
if [[ -d /www/server/panel || -f /etc/init.d/bt ]]; then
  die "aaPanel is installed on this server. Remove it first:  sudo bash remove-aapanel.sh  — then run this installer again."
fi
port_owner() { ss -ltnpH "sport = :$1" 2>/dev/null | grep -oE 'pid=[0-9]+' | head -n1 | cut -d= -f2; }
PID80="$(port_owner 80 || true)"
if [[ -n "$PID80" ]]; then
  EXE="$(readlink -f /proc/$PID80/exe 2>/dev/null || true)"
  [[ "$EXE" == "/usr/sbin/nginx" ]] || die "Port 80 is used by $EXE (pid $PID80). HostDesk needs the system Nginx on port 80. Stop that program first."
fi
if [[ $UPDATE == 0 ]]; then
  PIDP="$(port_owner "$PORT" || true)"
  [[ -z "$PIDP" ]] || die "Port $PORT is already in use. Choose another:  sudo HOSTDESK_PORT=7900 bash install.sh"
fi
FREE_MB=$(df -Pm / | awk 'NR==2{print $4}')
(( FREE_MB > 2048 )) || die "Less than 2 GB free on / — free some space first."

# ---------- Packages ----------
say "Installing base packages (nginx, tools)"
export DEBIAN_FRONTEND=noninteractive
APT=(apt-get -y -q -o Dpkg::Lock::Timeout=600 -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold)
apt-get update -q
"${APT[@]}" install nginx curl ca-certificates gnupg unzip zip tar xz-utils acl rsync logrotate iproute2 software-properties-common sqlite3 cron
systemctl enable --now nginx cron >/dev/null

# ---------- Node.js runtime for the panel ----------
if [[ ! -x $NODE_DIR/bin/node ]]; then
  say "Downloading Node.js $NODE_MAJOR (official build, checksum verified)"
  case "$(uname -m)" in x86_64) A=x64 ;; aarch64) A=arm64 ;; *) die "Unsupported CPU: $(uname -m)" ;; esac
  TMP="$(mktemp -d)"
  ( cd "$TMP"
    curl -fsSLO "https://nodejs.org/dist/latest-v${NODE_MAJOR}.x/SHASUMS256.txt"
    FILE="$(grep -oE "node-v[0-9.]+-linux-${A}\.tar\.xz" SHASUMS256.txt | head -n1)"
    [[ -n "$FILE" ]] || exit 1
    curl -fsSLO "https://nodejs.org/dist/latest-v${NODE_MAJOR}.x/$FILE"
    grep " $FILE\$" SHASUMS256.txt | sha256sum -c - >/dev/null
    mkdir -p "$NODE_DIR"
    tar -xJf "$FILE" -C "$NODE_DIR" --strip-components=1 --no-same-owner )
  rm -rf "$TMP"
  chmod -R a+rX $BASE/runtimes
fi
echo "    Node.js $($NODE_DIR/bin/node -v)"

# ---------- Files and folders ----------
say "Copying HostDesk to $APP"
install -d -m 755 $BASE $APP
rsync -a --delete --exclude '.git' "$SRC/server" "$SRC/public" "$SRC/package.json" "$APP/"
cp -f "$SRC/install.sh" "$SRC/uninstall.sh" "$SRC/remove-aapanel.sh" "$SRC/README.md" "$APP/" 2>/dev/null || true
chown -R root:root $APP && chmod -R go-w $APP

install -d -m 700 /etc/hostdesk /etc/hostdesk/env /etc/hostdesk/secrets /var/lib/hostdesk /var/backups/hostdesk
install -d -m 755 /var/www /var/log/hostdesk /var/log/hostdesk/sites /var/log/hostdesk/cron /var/log/nginx/hostdesk
install -d -m 711 /var/lib/hostdesk-home
if [[ ! -f /etc/hostdesk/config.json ]]; then
  cat > /etc/hostdesk/config.json <<JSON
{
  "host": "0.0.0.0",
  "port": $PORT,
  "wwwRoot": "/var/www"
}
JSON
  chmod 600 /etc/hostdesk/config.json
fi

# ---------- Log rotation ----------
cat > /etc/logrotate.d/hostdesk <<'ROT'
/var/log/nginx/hostdesk/*.log {
    daily
    rotate 14
    missingok
    notifempty
    compress
    delaycompress
    sharedscripts
    postrotate
        [ -s /run/nginx.pid ] && kill -USR1 "$(cat /run/nginx.pid)" || true
    endscript
}
/var/log/hostdesk/sites/*/*.log /var/log/hostdesk/cron/*.log {
    weekly
    rotate 8
    missingok
    notifempty
    compress
    delaycompress
    copytruncate
}
ROT

# ---------- Command-line helper ----------
cat > /usr/local/bin/hostdesk <<CLI
#!/bin/sh
exec $NODE_DIR/bin/node $APP/server/cli.js "\$@"
CLI
chmod 755 /usr/local/bin/hostdesk

# ---------- Service ----------
cat > /etc/systemd/system/hostdesk.service <<UNIT
[Unit]
Description=HostDesk server panel
After=network-online.target nginx.service
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$APP
ExecStart=$NODE_DIR/bin/node $APP/server/index.js
Environment=NODE_ENV=production
Environment=NODE_NO_WARNINGS=1
Restart=always
RestartSec=3
LimitNOFILE=65535
TimeoutStopSec=15

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload

# ---------- First administrator ----------
ADMIN_MSG=""
if ! /usr/local/bin/hostdesk has-admin >/dev/null 2>&1; then
  say "Creating the administrator account"
  ADMIN_MSG="$(HOSTDESK_DEV= /usr/local/bin/hostdesk passwd admin)"
fi

# ---------- Firewall: allow the panel from the local network only ----------
if command -v ufw >/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then
  LAN="$(ip -o -4 route show scope link 2>/dev/null | awk '{print $1}' | grep -E '^(10|172|192\.168)\.' | head -n1 || true)"
  if [[ -n "$LAN" ]] && ! ufw status | grep -qE "^$PORT/tcp .*$LAN"; then
    ufw allow from "$LAN" to any port "$PORT" proto tcp comment 'HostDesk panel (local network)' >/dev/null && echo "    Firewall: port $PORT allowed from $LAN"
  fi
fi

# ---------- Start ----------
systemctl enable hostdesk >/dev/null 2>&1
systemctl restart hostdesk
say "Waiting for the panel to start"
for i in $(seq 1 30); do
  curl -fsS "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1 && break
  sleep 1
  [[ $i == 30 ]] && { journalctl -u hostdesk -n 30 --no-pager; die "The panel did not start. The log is above."; }
done

IP="$(ip -o -4 route get 1.1.1.1 2>/dev/null | grep -oE 'src [0-9.]+' | cut -d' ' -f2 || true)"
echo
echo "${g}${b}HostDesk is running.${n}"
echo
echo "  Open:      ${b}http://${IP:-<server-ip>}:$PORT${n}   (from your local network)"
if [[ -n "$ADMIN_MSG" ]]; then
  echo
  echo "$ADMIN_MSG" | sed 's/^/  /'
  echo "  ${y}Write this password down. Change it after signing in (Settings).${n}"
fi
echo
echo "  Next steps"
echo "   1. Sign in, open the App Store and install Node.js and/or PHP."
echo "   2. Optional: open the panel from anywhere — add a Public Hostname in your Cloudflare"
echo "      Tunnel (for example panel.yourdomain.com → http://localhost:$PORT) and protect it"
echo "      with Cloudflare Access."
echo "   3. Recommended: install Fail2ban from the App Store, and check Security for old open ports."
echo
echo "  Help:  hostdesk info   ·   hostdesk passwd admin   ·   journalctl -u hostdesk -f"
